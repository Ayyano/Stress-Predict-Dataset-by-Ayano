const { contextBridge, ipcRenderer } = require("electron");

contextBridge.exposeInMainWorld("neuroPulseDesktop", {
  isDesktopApp: true,
  platform: process.platform,
  savePdfBytes: (byteArray, defaultFileName) =>
    ipcRenderer.invoke("neuropulse:save-pdf", byteArray, defaultFileName),
});
