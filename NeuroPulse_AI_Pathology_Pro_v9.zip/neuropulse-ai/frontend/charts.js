/**
 * NeuroPulse AI — Therapeutic Sanctuary v8 Canvas Visualizations
 * Soft Sage · Muted Teal · Gentle Lavender · Dusty Blue · Soft Clay
 */

window.NeuroCharts = (() => {
  function getPalette() {
    const dark = document.body.classList.contains("theme-evening");
    return {
      text: dark ? "#F2F4F2" : "#232B29",
      muted: dark ? "#93A09C" : "#788580",
      grid: dark ? "rgba(210, 224, 219, 0.12)" : "rgba(71, 120, 103, 0.14)",
      sage: dark ? "#76B29C" : "#477867",
      teal: dark ? "#6FAAB2" : "#3B7A83",
      lavender: dark ? "#A89BC9" : "#7A6E9B",
      dustyBlue: dark ? "#89A8C4" : "#5B7894",
      clay: dark ? "#DF8270" : "#B85D4B",
      refBar: dark ? "rgba(198, 208, 205, 0.34)" : "rgba(120, 133, 128, 0.28)",
      track: dark ? "rgba(255, 255, 255, 0.06)" : "rgba(71, 120, 103, 0.1)",
    };
  }

  function startWelcomeAnimation(canvasId) {
    const canvas = document.getElementById(canvasId);
    if (!canvas) return;
    const ctx = canvas.getContext("2d");
    const W = canvas.width;
    const H = canvas.height;

    const motes = Array.from({ length: 24 }, (_, i) => ({
      x: 40 + ((i * 83) % (W - 80)),
      y: 30 + ((i * 59) % (H - 120)),
      vx: Math.sin(i * 1.7) * 0.2,
      vy: -0.15 - (i % 3) * 0.05,
      r: 2.2 + (i % 3) * 1.1,
      hue: i % 3,
    }));

    let t = 0;

    function ecgWave(x) {
      const p = ((x % 1) + 1) % 1;
      if (p > 0.10 && p < 0.16) return 0.15 * Math.sin(((p - 0.10) / 0.06) * Math.PI);
      if (p >= 0.22 && p < 0.25) return -0.14 * ((p - 0.22) / 0.03);
      if (p >= 0.25 && p < 0.29) return 0.92 * Math.sin(((p - 0.25) / 0.04) * Math.PI);
      if (p >= 0.29 && p < 0.33) return -0.24 * Math.sin(((p - 0.29) / 0.04) * Math.PI);
      if (p >= 0.42 && p < 0.56) return 0.25 * Math.sin(((p - 0.42) / 0.14) * Math.PI);
      return 0;
    }

    function frame() {
      const pal = getPalette();
      ctx.clearRect(0, 0, W, H);

      const cx = W / 2;
      const cy = H * 0.42;
      const breath = 0.5 + 0.5 * Math.sin(t * 0.85);
      const baseR = 52 + breath * 26;

      for (let ring = 3; ring >= 1; ring--) {
        const rr = baseR + ring * 23;
        const grad = ctx.createRadialGradient(cx, cy, rr * 0.2, cx, cy, rr);
        grad.addColorStop(0, ring === 1 ? "rgba(71, 120, 103, 0.22)" : "rgba(122, 110, 155, 0.12)");
        grad.addColorStop(1, "rgba(71, 120, 103, 0)");
        ctx.fillStyle = grad;
        ctx.beginPath();
        ctx.arc(cx, cy, rr, 0, Math.PI * 2);
        ctx.fill();
      }

      ctx.strokeStyle = pal.sage;
      ctx.globalAlpha = 0.42 + breath * 0.26;
      ctx.lineWidth = 2;
      ctx.beginPath();
      ctx.arc(cx, cy, baseR, 0, Math.PI * 2);
      ctx.stroke();
      ctx.globalAlpha = 1;

      ctx.fillStyle = pal.text;
      ctx.font = "600 13px -apple-system, sans-serif";
      ctx.textAlign = "center";
      ctx.fillText(Math.cos(t * 0.85) >= 0 ? "Breathe In..." : "Breathe Out...", cx, cy + 4);

      motes.forEach((m) => {
        m.x += m.vx;
        m.y += m.vy;
        if (m.y < 16) { m.y = H - 105; m.x = 30 + Math.random() * (W - 60); }
        if (m.x < 16 || m.x > W - 16) m.vx *= -1;
      });

      motes.forEach((m, idx) => {
        ctx.fillStyle = m.hue === 0 ? pal.sage : (m.hue === 1 ? pal.teal : pal.lavender);
        ctx.globalAlpha = 0.38 + 0.28 * Math.sin(t * 1.8 + idx);
        ctx.beginPath();
        ctx.arc(m.x, m.y, m.r, 0, Math.PI * 2);
        ctx.fill();
      });
      ctx.globalAlpha = 1;

      const baseY = H - 60;
      const wGrad = ctx.createLinearGradient(0, baseY, W, baseY);
      wGrad.addColorStop(0, "rgba(71, 120, 103, 0.16)");
      wGrad.addColorStop(0.5, pal.teal);
      wGrad.addColorStop(1, pal.lavender);

      ctx.strokeStyle = wGrad;
      ctx.lineWidth = 2.5;
      ctx.lineCap = "round";
      ctx.beginPath();
      for (let x = 0; x <= W; x += 2) {
        const ph = x / 195 - t * 0.38;
        const y = baseY - ecgWave(ph) * 38;
        if (x === 0) ctx.moveTo(x, y); else ctx.lineTo(x, y);
      }
      ctx.stroke();

      ctx.strokeStyle = pal.sage;
      ctx.globalAlpha = 0.34;
      ctx.lineWidth = 1.5;
      ctx.beginPath();
      for (let x = 0; x <= W; x += 3) {
        const y = baseY + 24 + Math.sin(x * 0.022 - t * 1.1) * 6.5;
        if (x === 0) ctx.moveTo(x, y); else ctx.lineTo(x, y);
      }
      ctx.stroke();
      ctx.globalAlpha = 1;

      t += 0.013;
      requestAnimationFrame(frame);
    }
    requestAnimationFrame(frame);
  }

  function roundTopRect(ctx, x, y, w, h, r) {
    const rad = Math.min(r, w / 2, h);
    ctx.beginPath();
    ctx.moveTo(x, y + h);
    ctx.lineTo(x, y + rad);
    ctx.quadraticCurveTo(x, y, x + rad, y);
    ctx.lineTo(x + w - rad, y);
    ctx.quadraticCurveTo(x + w, y, x + w, y + rad);
    ctx.lineTo(x + w, y + h);
    ctx.closePath();
    ctx.fill();
  }

  function drawGroupedBar(canvasId, labels, pVals, cVals, _unit, tone = "sage") {
    const canvas = document.getElementById(canvasId);
    if (!canvas) return;
    const ctx = canvas.getContext("2d");
    const pal = getPalette();
    const W = canvas.width;
    const H = canvas.height;
    ctx.clearRect(0, 0, W, H);

    const primaryColor = tone === "teal" ? pal.teal : pal.sage;
    const padL = 46, padR = 18, padT = 32, padB = 40;
    const chartW = W - padL - padR;
    const chartH = H - padT - padB;
    const maxVal = Math.max(...pVals, ...cVals, 10) * 1.18;

    ctx.font = "11px -apple-system, sans-serif";
    ctx.fillStyle = pal.muted;
    ctx.strokeStyle = pal.grid;
    ctx.lineWidth = 1;
    for (let i = 0; i <= 4; i++) {
      const y = padT + (chartH * i) / 4;
      const v = maxVal * (1 - i / 4);
      ctx.beginPath(); ctx.moveTo(padL, y); ctx.lineTo(W - padR, y); ctx.stroke();
      ctx.textAlign = "right";
      ctx.fillText(v.toFixed(0), padL - 8, y + 4);
    }

    ctx.textAlign = "left";
    ctx.fillStyle = primaryColor;
    ctx.fillRect(padL, 8, 12, 10);
    ctx.fillStyle = pal.text;
    ctx.fillText("Your Value", padL + 17, 17);

    ctx.fillStyle = pal.refBar;
    ctx.fillRect(padL + 98, 8, 12, 10);
    ctx.fillStyle = pal.muted;
    ctx.fillText("Normal Reference", padL + 115, 17);

    const groupW = chartW / labels.length;
    const barW = Math.min(34, groupW * 0.28);

    labels.forEach((lbl, idx) => {
      const cx = padL + idx * groupW + groupW / 2;
      const h1 = (pVals[idx] / maxVal) * chartH;
      const h2 = (cVals[idx] / maxVal) * chartH;

      ctx.fillStyle = primaryColor;
      roundTopRect(ctx, cx - barW - 3, padT + chartH - h1, barW, h1, 8);

      ctx.fillStyle = pal.refBar;
      roundTopRect(ctx, cx + 3, padT + chartH - h2, barW, h2, 8);

      ctx.textAlign = "center";
      ctx.fillStyle = pal.text;
      ctx.font = "bold 11px -apple-system, sans-serif";
      ctx.fillText(pVals[idx].toFixed(1), cx - barW / 2 - 3, padT + chartH - h1 - 6);

      ctx.fillStyle = pal.muted;
      ctx.font = "10px -apple-system, sans-serif";
      ctx.fillText(cVals[idx].toFixed(1), cx + barW / 2 + 3, padT + chartH - h2 - 6);

      ctx.fillStyle = pal.text;
      ctx.font = "11px -apple-system, sans-serif";
      ctx.fillText(lbl, cx, H - 14);
    });
  }

  function drawRadar(canvasId, radarData, isStressed) {
    const canvas = document.getElementById(canvasId);
    if (!canvas) return;
    const ctx = canvas.getContext("2d");
    const pal = getPalette();
    const W = canvas.width;
    const H = canvas.height;
    ctx.clearRect(0, 0, W, H);

    const cx = W / 2;
    const cy = H / 2 + 6;
    const radius = Math.min(W, H) * 0.34;
    const labels = ["Cardio Δ", "Resp. Δ", "EDA", "Thermal", "PSS", "STAI-S"];
    const n = labels.length;

    ctx.strokeStyle = pal.grid;
    ctx.lineWidth = 1;
    [0.25, 0.5, 0.75, 1.0].forEach((r) => {
      ctx.beginPath();
      for (let i = 0; i <= n; i++) {
        const ang = (Math.PI * 2 * (i % n)) / n - Math.PI / 2;
        const x = cx + Math.cos(ang) * radius * r;
        const y = cy + Math.sin(ang) * radius * r;
        if (i === 0) ctx.moveTo(x, y); else ctx.lineTo(x, y);
      }
      ctx.stroke();
    });

    ctx.font = "bold 11px -apple-system, sans-serif";
    ctx.fillStyle = pal.text;
    labels.forEach((lbl, i) => {
      const ang = (Math.PI * 2 * i) / n - Math.PI / 2;
      ctx.beginPath(); ctx.moveTo(cx, cy); ctx.lineTo(cx + Math.cos(ang) * radius, cy + Math.sin(ang) * radius); ctx.stroke();
      ctx.textAlign = "center";
      ctx.fillText(lbl, cx + Math.cos(ang) * (radius + 25), cy + Math.sin(ang) * (radius + 18) + 4);
    });

    function plotPoly(vals, stroke, fill, dashed = false) {
      ctx.save();
      if (dashed) ctx.setLineDash([4, 4]);
      ctx.strokeStyle = stroke;
      ctx.fillStyle = fill;
      ctx.lineWidth = 2.2;
      ctx.beginPath();
      vals.forEach((v, i) => {
        const ang = (Math.PI * 2 * i) / n - Math.PI / 2;
        const r = (Math.max(0, Math.min(100, v)) / 100) * radius;
        const x = cx + Math.cos(ang) * r;
        const y = cy + Math.sin(ang) * r;
        if (i === 0) ctx.moveTo(x, y); else ctx.lineTo(x, y);
      });
      ctx.closePath();
      ctx.fill();
      ctx.stroke();
      ctx.restore();
    }

    plotPoly([40, 40, 35, 35, 33, 30], pal.sage, "rgba(71, 120, 103, 0.12)", true);
    const pStroke = isStressed ? pal.clay : pal.teal;
    const pFill = isStressed ? "rgba(184, 93, 75, 0.22)" : "rgba(59, 122, 131, 0.22)";
    plotPoly(radarData.participant, pStroke, pFill, false);
  }

  function drawModelConsensus(canvasId, preds) {
    const canvas = document.getElementById(canvasId);
    if (!canvas) return;
    const ctx = canvas.getContext("2d");
    const pal = getPalette();
    const W = canvas.width;
    const H = canvas.height;
    ctx.clearRect(0, 0, W, H);

    const items = preds.slice(0, 6);
    const padL = 175, padR = 54, padT = 18, padB = 22;
    const chartW = W - padL - padR;
    const rowH = (H - padT - padB) / Math.max(items.length, 1);

    const x50 = padL + chartW * 0.5;
    ctx.save();
    ctx.setLineDash([4, 4]);
    ctx.strokeStyle = pal.muted;
    ctx.beginPath(); ctx.moveTo(x50, padT); ctx.lineTo(x50, H - padB); ctx.stroke();
    ctx.restore();

    items.forEach((item, idx) => {
      const y = padT + idx * rowH + rowH * 0.22;
      const bh = Math.min(18, rowH * 0.54);
      const bw = (item.stress_probability / 100) * chartW;

      ctx.fillStyle = pal.text;
      ctx.font = "11px -apple-system, sans-serif";
      ctx.textAlign = "right";
      ctx.fillText(item.model.replace("Proposed ", ""), padL - 10, y + bh * 0.78);

      ctx.fillStyle = pal.track;
      ctx.fillRect(padL, y, chartW, bh);

      ctx.fillStyle = item.stress_probability >= 50 ? pal.clay : pal.sage;
      ctx.fillRect(padL, y, bw, bh);

      ctx.fillStyle = pal.text;
      ctx.font = "bold 11px -apple-system, sans-serif";
      ctx.textAlign = "left";
      ctx.fillText(`${item.stress_probability.toFixed(1)}%`, padL + bw + 8, y + bh * 0.78);
    });
  }

  return { startWelcomeAnimation, drawGroupedBar, drawRadar, drawModelConsensus };
})();
