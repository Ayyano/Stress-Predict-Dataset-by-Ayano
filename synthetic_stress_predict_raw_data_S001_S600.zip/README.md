# Synthetic Stress-Predict Dataset (S001–S600)

> **Disclaimer:** All physiological signals, questionnaire scores, and participant records in this repository are **synthetically generated** for prototyping, pipeline testing, and educational use. They are **not** real clinical patient data.

## Structure
- `Processed_data/synthetic_stress_predict_600_participants.csv`: 600 synthetic participants (`S001`–`S600`) across 6 age/gender cohorts (100 Men, 100 Women, 100 Boys, 100 Girls, 100 Senior Citizens 60–85 yrs, 100 Kids 6–12 yrs) using the 17-column schema.
- `Raw_data/S001` to `Raw_data/S600`: Per-participant Empatica E4-style folders containing `ACC.csv`, `BVP.csv`, `EDA.csv`, `HR.csv`, `IBI.csv`, `TEMP.csv`, `tags_<ID>.csv`, and `info.txt`, calibrated to each participant's baseline and stress vitals.

## Reference Format
Folder and Empatica E4 CSV structure is modeled after the open-access [Stress-Predict-Dataset](https://github.com/italha-d/Stress-Predict-Dataset) (Iqbal et al., *Sensors*, 2022).
