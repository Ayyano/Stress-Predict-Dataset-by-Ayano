"""
NeuroPulse AI — Research-Grade Multi-Page PDF Clinical Report Generator.
Uses ReportLab + Matplotlib (Agg backend) to produce a crisp, publication-grade
report inspired by Attachment 2's dark-navy & teal clinical dossier aesthetic.
"""

from __future__ import annotations

import io
from typing import Any, Dict, List

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
from reportlab.lib import colors
from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import ParagraphStyle, getSampleStyleSheet
from reportlab.lib.units import mm
from reportlab.platypus import (
    Image as RLImage,
    KeepTogether,
    PageBreak,
    Paragraph,
    SimpleDocTemplate,
    Spacer,
    Table,
    TableStyle,
)

# Color Palette (Dark Navy + Teal + Slate + Alert Crimson)
NAVY = colors.HexColor("#0B132B")
NAVY_MID = colors.HexColor("#1C2541")
TEAL = colors.HexColor("#0F766E")
CYAN = colors.HexColor("#0284C7")
CRIMSON = colors.HexColor("#BE123C")
AMBER = colors.HexColor("#B45309")
SLATE = colors.HexColor("#334155")
MUTED = colors.HexColor("#64748B")
BG_SOFT = colors.HexColor("#F8FAFC")
BG_TEAL = colors.HexColor("#F0FDFA")
BG_RED = colors.HexColor("#FFF1F2")
BORDER = colors.HexColor("#CBD5E1")


def _esc(text: Any) -> str:
    s = str(text)
    s = s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")
    # Keep standard Latin-1 safe glyphs for Helvetica
    for k, v in {
        "μ": "u",
        "µ": "u",
        "Δ": "Delta ",
        "°": " deg ",
        "—": " - ",
        "–": "-",
        "→": "->",
        "•": "*",
    }.items():
        s = s.replace(k, v)
    return s


def _make_hr_reactivity_chart(result: Dict[str, Any]) -> io.BytesIO:
    m = result["measured_values"]
    coh = result["cohort_comparison"]["normal_baselines"]

    labels = ["Resting\nHR", "Stroop\nTest", "Interview\nTask", "Hypervent.\nPhase"]
    p_vals = [m["hr"], m["stroop_hr"], m["interview_hr"], m["hypervent_hr"]]
    c_vals = [
        coh.get("HR", 72.0),
        coh.get("Stroop HR (bpm)", 78.5),
        coh.get("Interview HR (bpm)", 83.5),
        coh.get("Hyperventilation HR (bpm)", 81.0),
    ]

    x = np.arange(len(labels))
    w = 0.35

    fig, ax = plt.subplots(figsize=(5.2, 3.2), dpi=200)
    fig.patch.set_facecolor("#FFFFFF")
    ax.set_facecolor("#F8FAFC")

    b1 = ax.bar(x - w / 2, p_vals, w, label="Participant", color="#0284C7", edgecolor="#0B132B", linewidth=0.5)
    b2 = ax.bar(x + w / 2, c_vals, w, label="Cohort Normal", color="#94A3B8", edgecolor="#475569", linewidth=0.5)

    for bar in b1:
        h = bar.get_height()
        ax.text(bar.get_x() + bar.get_width() / 2, h + 1.5, f"{h:.0f}", ha="center", va="bottom", fontsize=7.5, fontweight="bold", color="#0B132B")
    for bar in b2:
        h = bar.get_height()
        ax.text(bar.get_x() + bar.get_width() / 2, h + 1.5, f"{h:.0f}", ha="center", va="bottom", fontsize=7.0, color="#475569")

    ax.set_title("Heart Rate Reactivity vs. Cohort Baseline", fontsize=9.5, fontweight="bold", color="#0B132B", pad=10)
    ax.set_ylabel("Beats Per Minute (bpm)", fontsize=8, color="#334155")
    ax.set_xticks(x)
    ax.set_xticklabels(labels, fontsize=7.8, color="#1E293B")
    ax.set_ylim(0, max(max(p_vals), max(c_vals)) + 18)
    ax.grid(axis="y", linestyle="--", alpha=0.45)
    ax.spines["top"].set_visible(False)
    ax.spines["right"].set_visible(False)
    ax.legend(frameon=False, fontsize=7.5, loc="upper left")
    plt.tight_layout()

    buf = io.BytesIO()
    fig.savefig(buf, format="png", dpi=200)
    plt.close(fig)
    buf.seek(0)
    return buf


def _make_radar_chart(result: Dict[str, Any]) -> io.BytesIO:
    radar = result["cohort_comparison"]["radar_profile"]
    labels = ["Cardio\nReact.", "Resp.\nShift", "EDA\nArousal", "Thermal\nDrop", "PSS\nStress", "STAI-S\nAnxiety"]
    p_vals = radar["participant"]
    c_vals = radar["normal_cohort"]

    angles = np.linspace(0, 2 * np.pi, len(labels), endpoint=False).tolist()
    p_plot = p_vals + [p_vals[0]]
    c_plot = c_vals + [c_vals[0]]
    angles_plot = angles + [angles[0]]

    fig = plt.figure(figsize=(4.8, 3.2), dpi=200)
    fig.patch.set_facecolor("#FFFFFF")
    ax = fig.add_subplot(111, polar=True)
    ax.set_facecolor("#F8FAFC")

    ax.plot(angles_plot, c_plot, color="#64748B", linewidth=1.4, linestyle="--", label="Cohort Normal")
    ax.fill(angles_plot, c_plot, color="#94A3B8", alpha=0.18)

    stress_col = "#BE123C" if result["backend_predictions"]["is_stressed"] else "#0F766E"
    ax.plot(angles_plot, p_plot, color=stress_col, linewidth=2.0, label="Participant")
    ax.fill(angles_plot, p_plot, color=stress_col, alpha=0.25)

    ax.set_xticks(angles)
    ax.set_xticklabels(labels, fontsize=7.2, color="#1E293B", fontweight="bold")
    ax.set_ylim(0, 100)
    ax.set_yticks([25, 50, 75, 100])
    ax.set_yticklabels(["25", "50", "75", "100"], fontsize=6.5, color="#64748B")
    ax.set_title("Autonomic & Psychometric Profile (0-100)", fontsize=9.0, fontweight="bold", color="#0B132B", pad=16)
    ax.legend(loc="upper center", bbox_to_anchor=(0.5, -0.14), ncol=2, frameon=False, fontsize=7.2)
    plt.tight_layout()

    buf = io.BytesIO()
    fig.savefig(buf, format="png", dpi=200)
    plt.close(fig)
    buf.seek(0)
    return buf


def _make_rr_and_psych_chart(result: Dict[str, Any]) -> io.BytesIO:
    m = result["measured_values"]
    coh = result["cohort_comparison"]["normal_baselines"]

    fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(9.6, 2.9), dpi=200)
    fig.patch.set_facecolor("#FFFFFF")

    # Left: Respiratory Rate comparison
    ax1.set_facecolor("#F8FAFC")
    r_labels = ["Resting RR", "Stress RR"]
    rp = [m["rr"], m["stress_rr"]]
    rc = [coh.get("RR", 15.2), coh.get("Stress Resp Rate (brpm)", 18.8)]
    x = np.arange(2)
    w = 0.34
    ax1.bar(x - w / 2, rp, w, color="#0F766E", label="Participant")
    ax1.bar(x + w / 2, rc, w, color="#94A3B8", label="Cohort Normal")
    for i, v in enumerate(rp):
        ax1.text(i - w / 2, v + 0.6, f"{v:.1f}", ha="center", fontsize=8, fontweight="bold", color="#0F766E")
    for i, v in enumerate(rc):
        ax1.text(i + w / 2, v + 0.6, f"{v:.1f}", ha="center", fontsize=7.5, color="#475569")
    ax1.set_title("A. Respiratory Rate Shift (brpm)", fontsize=9.2, fontweight="bold", color="#0B132B")
    ax1.set_xticks(x)
    ax1.set_xticklabels(r_labels, fontsize=8.2)
    ax1.set_ylim(0, max(max(rp), max(rc)) + 6)
    ax1.grid(axis="y", linestyle="--", alpha=0.4)
    ax1.spines["top"].set_visible(False)
    ax1.spines["right"].set_visible(False)
    ax1.legend(frameon=False, fontsize=7.5)

    # Right: Psychometric Scales normalized to % of scale max
    ax2.set_facecolor("#F8FAFC")
    p_labels = ["PSS\n(0-40)", "STAI-State\n(20-80)", "STAI-Trait\n(20-80)"]
    p_raw = [m["pss_score"], m["stai_state"], m["stai_trait"]]
    c_raw = [
        coh.get("PSS Score (0-40)", 12.0),
        coh.get("STAI-State (20-80)", 32.0),
        coh.get("STAI-Trait (20-80)", 34.0),
    ]
    x2 = np.arange(3)
    ax2.bar(x2 - w / 2, p_raw, w, color="#6366F1", label="Participant")
    ax2.bar(x2 + w / 2, c_raw, w, color="#94A3B8", label="Cohort Normal")
    for i, v in enumerate(p_raw):
        ax2.text(i - w / 2, v + 1.5, f"{v:.0f}", ha="center", fontsize=8, fontweight="bold", color="#4338CA")
    for i, v in enumerate(c_raw):
        ax2.text(i + w / 2, v + 1.5, f"{v:.0f}", ha="center", fontsize=7.5, color="#475569")
    ax2.set_title("B. Psychometric Scores vs. Cohort Normal", fontsize=9.2, fontweight="bold", color="#0B132B")
    ax2.set_xticks(x2)
    ax2.set_xticklabels(p_labels, fontsize=8.2)
    ax2.set_ylim(0, 92)
    ax2.grid(axis="y", linestyle="--", alpha=0.4)
    ax2.spines["top"].set_visible(False)
    ax2.spines["right"].set_visible(False)
    ax2.legend(frameon=False, fontsize=7.5)

    plt.tight_layout()
    buf = io.BytesIO()
    fig.savefig(buf, format="png", dpi=200)
    plt.close(fig)
    buf.seek(0)
    return buf


def _make_model_and_importance_chart(result: Dict[str, Any]) -> io.BytesIO:
    preds = result["backend_predictions"]["per_model_predictions"]
    feats = result["backend_predictions"]["top_feature_importances"][:8]

    fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(9.6, 3.1), dpi=200)
    fig.patch.set_facecolor("#FFFFFF")

    # Left: Model Consensus
    ax1.set_facecolor("#F8FAFC")
    m_names = [p["model"].replace("Proposed ", "") for p in preds]
    m_probs = [p["stress_probability"] for p in preds]
    bar_cols = ["#BE123C" if v >= 50 else "#0F766E" for v in m_probs]
    y_pos = np.arange(len(m_names))
    ax1.barh(y_pos, m_probs, color=bar_cols, alpha=0.9, height=0.6)
    ax1.axvline(50, color="#475569", linestyle="--", linewidth=1.0)
    ax1.set_yticks(y_pos)
    ax1.set_yticklabels(m_names, fontsize=7.2)
    ax1.invert_yaxis()
    ax1.set_xlim(0, 112)
    ax1.set_xlabel("Stress Probability (%)", fontsize=7.8)
    ax1.set_title("A. Backend Model Consensus", fontsize=9.2, fontweight="bold", color="#0B132B")
    for i, v in enumerate(m_probs):
        ax1.text(v + 1.5, i, f"{v:.1f}%", va="center", fontsize=7.2, fontweight="bold", color="#1E293B")
    ax1.spines["top"].set_visible(False)
    ax1.spines["right"].set_visible(False)

    # Right: Top Engineered Feature Importances
    ax2.set_facecolor("#F8FAFC")
    f_names = [f["feature"].replace("μ", "u").replace("°", "deg") for f in feats]
    f_vals = [f["importance"] * 100 for f in feats]
    y2 = np.arange(len(f_names))
    ax2.barh(y2, f_vals, color="#0284C7", alpha=0.9, height=0.6)
    ax2.set_yticks(y2)
    ax2.set_yticklabels(f_names, fontsize=7.2)
    ax2.invert_yaxis()
    ax2.set_xlabel("Relative Weight (%)", fontsize=7.8)
    ax2.set_title("B. Top Discriminative Features", fontsize=9.2, fontweight="bold", color="#0B132B")
    for i, v in enumerate(f_vals):
        ax2.text(v + 0.3, i, f"{v:.1f}%", va="center", fontsize=7.0, color="#1E293B")
    ax2.spines["top"].set_visible(False)
    ax2.spines["right"].set_visible(False)

    plt.tight_layout()
    buf = io.BytesIO()
    fig.savefig(buf, format="png", dpi=200)
    plt.close(fig)
    buf.seek(0)
    return buf


def _page_footer(canvas, doc):
    canvas.saveState()
    canvas.setStrokeColor(BORDER)
    canvas.setLineWidth(0.5)
    canvas.line(15 * mm, 13 * mm, A4[0] - 15 * mm, 13 * mm)
    canvas.setFont("Helvetica", 7.2)
    canvas.setFillColor(MUTED)
    canvas.drawString(
        15 * mm,
        8.5 * mm,
        "NeuroPulse AI - Autonomous Stress Monitoring System (ASMS) | Local Research Report (Non-Diagnostic)",
    )
    canvas.drawRightString(A4[0] - 15 * mm, 8.5 * mm, f"Page {doc.page}")
    canvas.restoreState()


def generate_clinical_pdf_bytes(result: Dict[str, Any]) -> bytes:
    """Build the complete multi-page research-grade PDF report and return bytes."""
    buf = io.BytesIO()
    doc = SimpleDocTemplate(
        buf,
        pagesize=A4,
        leftMargin=15 * mm,
        rightMargin=15 * mm,
        topMargin=14 * mm,
        bottomMargin=18 * mm,
        title="NeuroPulse AI - Autonomous Stress Monitoring Report",
        author="NeuroPulse AI Local Engine",
    )

    styles = getSampleStyleSheet()
    s_banner_t = ParagraphStyle("BT", parent=styles["Heading1"], fontName="Helvetica-Bold", fontSize=15, leading=19, textColor=colors.white, spaceAfter=2)
    s_banner_s = ParagraphStyle("BS", parent=styles["Normal"], fontName="Helvetica", fontSize=8.5, leading=11.5, textColor=colors.HexColor("#CBD5E1"))
    s_h2 = ParagraphStyle("H2", parent=styles["Heading2"], fontName="Helvetica-Bold", fontSize=11.2, leading=14, textColor=NAVY, spaceBefore=10, spaceAfter=5)
    s_body = ParagraphStyle("BODY", parent=styles["Normal"], fontName="Helvetica", fontSize=8.8, leading=12.6, textColor=SLATE, spaceAfter=4)
    s_bul = ParagraphStyle("BUL", parent=s_body, leftIndent=10, firstLineIndent=-6, spaceAfter=3.5)
    s_cell = ParagraphStyle("CELL", parent=styles["Normal"], fontName="Helvetica", fontSize=7.8, leading=10.2, textColor=SLATE)
    s_cell_b = ParagraphStyle("CELLB", parent=s_cell, fontName="Helvetica-Bold", textColor=NAVY)
    s_hdr = ParagraphStyle("HDR", parent=s_cell, fontName="Helvetica-Bold", textColor=colors.white)
    s_kpi_val = ParagraphStyle("KV", parent=styles["Heading2"], fontName="Helvetica-Bold", fontSize=13.5, leading=16, alignment=1, textColor=NAVY, spaceAfter=1)
    s_kpi_lbl = ParagraphStyle("KL", parent=s_cell, fontSize=7.2, alignment=1, textColor=MUTED)
    s_disc = ParagraphStyle("DISC", parent=s_cell, fontSize=7.6, leading=10.5, textColor=MUTED)

    meta = result["meta"]
    m = result["measured_values"]
    d = result["derived_calculations"]
    p = result["backend_predictions"]
    coh = result["cohort_comparison"]
    obs = result["interpretive_observations"]

    is_stressed = p["is_stressed"]
    verdict_bg = CRIMSON if is_stressed else TEAL
    verdict_soft = BG_RED if is_stressed else BG_TEAL

    w_full = A4[0] - 30 * mm  # ~510 pt

    story: List[Any] = []

    # ==================== PAGE 1: EXECUTIVE CLINICAL DOSSIER ====================
    banner = Table(
        [
            [
                Paragraph("NEUROPULSE AI  |  CLINICAL STRESS ASSESSMENT REPORT", s_banner_t),
            ],
            [
                Paragraph(
                    f"Autonomous Stress Monitoring System (ASMS)  |  Generated: {_esc(meta['timestamp'])}  |  Session Token: {_esc(meta['anon_id'])}",
                    s_banner_s,
                )
            ],
        ],
        colWidths=[w_full],
    )
    banner.setStyle(
        TableStyle(
            [
                ("BACKGROUND", (0, 0), (-1, -1), NAVY),
                ("LINEBELOW", (0, -1), (-1, -1), 3.0, verdict_bg),
                ("LEFTPADDING", (0, 0), (-1, -1), 12),
                ("RIGHTPADDING", (0, 0), (-1, -1), 12),
                ("TOPPADDING", (0, 0), (0, 0), 11),
                ("BOTTOMPADDING", (0, -1), (-1, -1), 9),
            ]
        )
    )
    story.append(banner)
    story.append(Spacer(1, 6))

    # Participant Identity + Verdict Strip
    verdict_style = ParagraphStyle("VS", parent=s_cell_b, fontSize=9.5, alignment=1, textColor=colors.white)
    id_strip = Table(
        [
            [
                Paragraph(f"<b>Participant:</b> {_esc(m['participant_name'])}<br/><b>Age / Gender:</b> {m['age']:.0f} yrs / {_esc(m['gender'])}", s_cell),
                Paragraph(f"<b>Demographic Cohort:</b> {_esc(meta['cohort'])}<br/><b>Primary Engine:</b> {_esc(meta['primary_model'])}", s_cell),
                Paragraph(f"<b>{_esc(p['verdict'])}</b><br/>{p['stress_probability']:.1f}% ({_esc(p['triage_severity'])})", verdict_style),
            ]
        ],
        colWidths=[w_full * 0.35, w_full * 0.35, w_full * 0.30],
    )
    id_strip.setStyle(
        TableStyle(
            [
                ("BACKGROUND", (0, 0), (1, 0), BG_SOFT),
                ("BACKGROUND", (2, 0), (2, 0), verdict_bg),
                ("BOX", (0, 0), (-1, -1), 0.6, BORDER),
                ("VALIGN", (0, 0), (-1, -1), "MIDDLE"),
                ("PADDING", (0, 0), (-1, -1), 7),
            ]
        )
    )
    story.append(id_strip)
    story.append(Spacer(1, 7))

    # 4 KPI Cards
    kpi_data = [
        [
            Paragraph(f"<b>{p['stress_probability']:.1f}%</b>", s_kpi_val),
            Paragraph(f"<b>{d['mean_task_hr_delta']:+.1f} bpm</b>", s_kpi_val),
            Paragraph(f"<b>{m['mean_eda']:.2f} uS / {m['skin_temp']:.1f} C</b>", s_kpi_val),
            Paragraph(f"<b>{m['pss_score']:.0f} / {m['stai_state']:.0f}</b>", s_kpi_val),
        ],
        [
            Paragraph("Backend ML Probability<br/>(Wearable-Only: %.1f%%)" % p["wearable_only_probability"], s_kpi_lbl),
            Paragraph(f"Mean Task Delta HR<br/>(Peak: {_esc(d['peak_stressor_task'])})", s_kpi_lbl),
            Paragraph("Mean EDA / Skin Temp<br/>(Sympathetic Arousal)", s_kpi_lbl),
            Paragraph("PSS (0-40) / STAI-State<br/>(Psychometric Profile)", s_kpi_lbl),
        ],
    ]
    kpi_table = Table(kpi_data, colWidths=[w_full / 4.0] * 4)
    kpi_table.setStyle(
        TableStyle(
            [
                ("BACKGROUND", (0, 0), (-1, -1), verdict_soft),
                ("BOX", (0, 0), (-1, -1), 0.7, BORDER),
                ("INNERGRID", (0, 0), (-1, -1), 0.5, BORDER),
                ("TOPPADDING", (0, 0), (-1, 0), 7),
                ("BOTTOMPADDING", (0, 1), (-1, 1), 6),
                ("VALIGN", (0, 0), (-1, -1), "MIDDLE"),
            ]
        )
    )
    story.append(kpi_table)
    story.append(Spacer(1, 8))

    # Side-by-side HR Reactivity + Autonomic Radar Charts
    story.append(Paragraph("1. Autonomic Reactivity & Psychometric Overview", s_h2))
    hr_img = RLImage(_make_hr_reactivity_chart(result), width=w_full * 0.51, height=158)
    radar_img = RLImage(_make_radar_chart(result), width=w_full * 0.47, height=158)
    chart_row = Table([[hr_img, radar_img]], colWidths=[w_full * 0.52, w_full * 0.48])
    chart_row.setStyle(TableStyle([("VALIGN", (0, 0), (-1, -1), "MIDDLE"), ("PADDING", (0, 0), (-1, -1), 2)]))
    story.append(chart_row)
    story.append(Spacer(1, 6))

    # Executive Summary Observations
    story.append(Paragraph("2. Executive Analytical Summary (Interpretive Observations)", s_h2))
    for pt in obs["summary_points"]:
        story.append(Paragraph(f"*  {_esc(pt)}", s_bul))

    story.append(PageBreak())

    # ==================== PAGE 2: BIOMETRIC MATRIX & RESPIRATORY/PSYCH ANALYSIS ====================
    story.append(Paragraph("3. Clinical Biometric Matrix (Measured Values vs. Cohort Baselines)", s_h2))
    story.append(
        Paragraph(
            f"All 14 participant parameters are compared against the normal reference baseline for the "
            f"<b>{_esc(meta['cohort'])}</b> demographic cohort derived from the local 600-participant dataset.",
            s_body,
        )
    )

    matrix_rows = [
        [
            Paragraph("Parameter", s_hdr),
            Paragraph("Measured Value", s_hdr),
            Paragraph("Cohort Normal", s_hdr),
            Paragraph("Deviation / Delta", s_hdr),
            Paragraph("Status", s_hdr),
        ]
    ]
    for row in coh["biometric_matrix"]:
        matrix_rows.append(
            [
                Paragraph(_esc(row["parameter"]), s_cell_b),
                Paragraph(_esc(row["measured"]), s_cell),
                Paragraph(_esc(row["baseline"]), s_cell),
                Paragraph(_esc(row["deviation"]), s_cell),
                Paragraph(_esc(row["status"]), s_cell_b),
            ]
        )

    m_table = Table(
        matrix_rows,
        colWidths=[w_full * 0.27, w_full * 0.16, w_full * 0.15, w_full * 0.24, w_full * 0.18],
        repeatRows=1,
    )
    m_cmds = [
        ("BACKGROUND", (0, 0), (-1, 0), NAVY),
        ("GRID", (0, 0), (-1, -1), 0.4, BORDER),
        ("VALIGN", (0, 0), (-1, -1), "MIDDLE"),
        ("PADDING", (0, 0), (-1, -1), 4.5),
    ]
    for idx in range(1, len(matrix_rows)):
        bg = colors.white if idx % 2 == 1 else BG_SOFT
        m_cmds.append(("BACKGROUND", (0, idx), (-1, idx), bg))
    m_table.setStyle(TableStyle(m_cmds))
    story.append(m_table)
    story.append(Spacer(1, 10))

    story.append(Paragraph("4. Respiratory & Psychometric Deep Dive", s_h2))
    rr_psych_img = RLImage(_make_rr_and_psych_chart(result), width=w_full, height=156)
    story.append(rr_psych_img)
    story.append(Spacer(1, 6))

    # Derived Feature Snapshot Table
    story.append(Paragraph("5. Derived Physiological Calculations (Personalized Baseline-Delta Engine)", s_h2))
    der_rows = [
        [Paragraph("Derived Metric", s_hdr), Paragraph("Computed Value", s_hdr), Paragraph("Derived Metric", s_hdr), Paragraph("Computed Value", s_hdr)],
        [Paragraph("Delta Stroop HR", s_cell_b), Paragraph(f"{d['delta_stroop_hr']:+.2f} bpm ({d['pct_stroop_hr']:+.1f}%)", s_cell),
         Paragraph("Delta Respiratory Rate", s_cell_b), Paragraph(f"{d['delta_rr']:+.2f} brpm ({d['pct_rr']:+.1f}%)", s_cell)],
        [Paragraph("Delta Interview HR", s_cell_b), Paragraph(f"{d['delta_interview_hr']:+.2f} bpm ({d['pct_interview_hr']:+.1f}%)", s_cell),
         Paragraph("HR x RR Delta Product", s_cell_b), Paragraph(f"{d['hr_rr_delta_product']:.2f}", s_cell)],
        [Paragraph("Delta Hyperventilation HR", s_cell_b), Paragraph(f"{d['delta_hypervent_hr']:+.2f} bpm ({d['pct_hypervent_hr']:+.1f}%)", s_cell),
         Paragraph("EDA / Skin Temp Ratio", s_cell_b), Paragraph(f"{d['eda_temp_ratio']:.4f} uS/C", s_cell)],
        [Paragraph("Max Task HR Delta", s_cell_b), Paragraph(f"{d['max_task_hr_delta']:+.2f} bpm ({_esc(d['peak_stressor_task'])})", s_cell),
         Paragraph("HR Reserve Utilization / STAI Delta", s_cell_b), Paragraph(f"{d['hr_reserve_util_pct']:.1f}% / {d['stai_delta']:+.0f} pts", s_cell)],
    ]
    d_table = Table(der_rows, colWidths=[w_full * 0.25, w_full * 0.25, w_full * 0.25, w_full * 0.25])
    d_table.setStyle(
        TableStyle(
            [
                ("BACKGROUND", (0, 0), (-1, 0), NAVY_MID),
                ("GRID", (0, 0), (-1, -1), 0.4, BORDER),
                ("BACKGROUND", (0, 1), (-1, 1), colors.white),
                ("BACKGROUND", (0, 2), (-1, 2), BG_SOFT),
                ("BACKGROUND", (0, 3), (-1, 3), colors.white),
                ("BACKGROUND", (0, 4), (-1, 4), BG_SOFT),
                ("PADDING", (0, 0), (-1, -1), 4.5),
            ]
        )
    )
    story.append(d_table)

    story.append(PageBreak())

    # ==================== PAGE 3: ML ENSEMBLE, RECOMMENDATIONS & METHODOLOGY ====================
    story.append(Paragraph("6. Backend Machine Learning Consensus & Feature Contributions", s_h2))
    ml_img = RLImage(_make_model_and_importance_chart(result), width=w_full, height=166)
    story.append(ml_img)
    story.append(Spacer(1, 6))

    # Actionable Recommendations
    story.append(Paragraph("7. Research-Oriented Action Plan & Follow-Up Guidance", s_h2))
    rec_rows = [[Paragraph("Focus Area", s_hdr), Paragraph("Priority", s_hdr), Paragraph("Recommended Protocol / Observation", s_hdr)]]
    for rec in obs["recommendations"]:
        rec_rows.append(
            [
                Paragraph(_esc(rec["category"]), s_cell_b),
                Paragraph(_esc(rec["priority"]), s_cell_b),
                Paragraph(_esc(rec["detail"]), s_cell),
            ]
        )
    rec_table = Table(rec_rows, colWidths=[w_full * 0.24, w_full * 0.14, w_full * 0.62], repeatRows=1)
    rec_cmds = [
        ("BACKGROUND", (0, 0), (-1, 0), TEAL),
        ("GRID", (0, 0), (-1, -1), 0.4, BORDER),
        ("VALIGN", (0, 0), (-1, -1), "TOP"),
        ("PADDING", (0, 0), (-1, -1), 5),
    ]
    for idx in range(1, len(rec_rows)):
        rec_cmds.append(("BACKGROUND", (0, idx), (-1, idx), colors.white if idx % 2 == 1 else BG_SOFT))
    rec_table.setStyle(TableStyle(rec_cmds))
    story.append(rec_table)
    story.append(Spacer(1, 8))

    # Autonomous Pipeline Audit
    story.append(Paragraph("8. Local Autonomous Pipeline Audit & Methodology", s_h2))
    crew_rows = [[Paragraph("Pipeline Stage", s_hdr), Paragraph("Status", s_hdr), Paragraph("Execution Summary", s_hdr)]]
    for c in obs["crew_audit"]:
        crew_rows.append([Paragraph(_esc(c["agent"]), s_cell_b), Paragraph(_esc(c["status"]), s_cell_b), Paragraph(_esc(c["detail"]), s_cell)])
    crew_table = Table(crew_rows, colWidths=[w_full * 0.30, w_full * 0.13, w_full * 0.57], repeatRows=1)
    crew_table.setStyle(
        TableStyle(
            [
                ("BACKGROUND", (0, 0), (-1, 0), NAVY_MID),
                ("GRID", (0, 0), (-1, -1), 0.4, BORDER),
                ("ROWBACKGROUNDS", (0, 1), (-1, -1), [colors.white, BG_SOFT]),
                ("PADDING", (0, 0), (-1, -1), 4.5),
            ]
        )
    )
    story.append(crew_table)
    story.append(Spacer(1, 10))

    # Research Disclaimer Box
    disc_box = Table(
        [[Paragraph(f"<b>DATA PROVENANCE &amp; RESEARCH DISCLAIMER:</b> {_esc(obs['disclaimer'])} "
                    f"This report distinguishes measured participant inputs, personalized baseline-delta calculations, "
                    f"local ML predictions ({_esc(meta['feature_count_full'])} multimodal features; engine mode: {_esc(meta['engine_mode'])}), "
                    f"and interpretive observations.", s_disc)]],
        colWidths=[w_full],
    )
    disc_box.setStyle(
        TableStyle(
            [
                ("BACKGROUND", (0, 0), (-1, -1), BG_SOFT),
                ("BOX", (0, 0), (-1, -1), 0.7, BORDER),
                ("LINEBEFORE", (0, 0), (0, -1), 3.0, CYAN),
                ("PADDING", (0, 0), (-1, -1), 8),
            ]
        )
    )
    story.append(KeepTogether([disc_box]))

    doc.build(story, onFirstPage=_page_footer, onLaterPages=_page_footer)
    return buf.getvalue()
