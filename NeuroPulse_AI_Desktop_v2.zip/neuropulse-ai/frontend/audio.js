/**
 * NeuroPulse AI — Optional Ambient Soundscape & UI Chimes (Web Audio API)
 * Strictly OFF by default (no autoplay without explicit user interaction).
 */
class NeuroPulseAudio {
  constructor() {
    this.enabled = false;
    this.ctx = null;
    this.droneNodes = [];
    this.masterGain = null;
  }

  toggle() {
    if (this.enabled) {
      this.disable();
    } else {
      this.enable();
    }
    return this.enabled;
  }

  enable() {
    const AudioCtx = window.AudioContext || window.webkitAudioContext;
    if (!AudioCtx) return;
    if (!this.ctx) {
      this.ctx = new AudioCtx();
      this.masterGain = this.ctx.createGain();
      this.masterGain.gain.value = 0.0;
      this.masterGain.connect(this.ctx.destination);
    }
    if (this.ctx.state === "suspended") {
      this.ctx.resume();
    }
    this.enabled = true;
    this._startAmbientPad();
    this.playStepChime(528);
  }

  disable() {
    this.enabled = false;
    if (this.masterGain && this.ctx) {
      this.masterGain.gain.setTargetAtTime(0.0, this.ctx.currentTime, 0.15);
    }
    setTimeout(() => this._stopAmbientPad(), 350);
  }

  _startAmbientPad() {
    this._stopAmbientPad();
    if (!this.ctx || !this.masterGain) return;
    const freqs = [110, 164.81, 220]; // Warm soft A2/E3/A3 ambient chord
    freqs.forEach((f, idx) => {
      const osc = this.ctx.createOscillator();
      const gain = this.ctx.createGain();
      osc.type = idx === 0 ? "sine" : "triangle";
      osc.frequency.value = f;
      gain.gain.value = idx === 0 ? 0.03 : 0.012;
      osc.connect(gain);
      gain.connect(this.masterGain);
      osc.start();
      this.droneNodes.push(osc);
    });
    this.masterGain.gain.setTargetAtTime(0.45, this.ctx.currentTime, 0.6);
  }

  _stopAmbientPad() {
    this.droneNodes.forEach((n) => {
      try { n.stop(); n.disconnect(); } catch (_) {}
    });
    this.droneNodes = [];
  }

  playStepChime(freq = 440) {
    if (!this.enabled || !this.ctx) return;
    const now = this.ctx.currentTime;
    const osc = this.ctx.createOscillator();
    const g = this.ctx.createGain();
    osc.type = "sine";
    osc.frequency.setValueAtTime(freq, now);
    osc.frequency.exponentialRampToValueAtTime(freq * 1.12, now + 0.14);
    g.gain.setValueAtTime(0.001, now);
    g.gain.linearRampToValueAtTime(0.06, now + 0.02);
    g.gain.exponentialRampToValueAtTime(0.0008, now + 0.24);
    osc.connect(g);
    g.connect(this.ctx.destination);
    osc.start(now);
    osc.stop(now + 0.26);
  }
}

window.neuroAudio = new NeuroPulseAudio();
