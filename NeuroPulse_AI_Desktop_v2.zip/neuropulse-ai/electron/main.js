const { app, BrowserWindow, ipcMain, dialog } = require("electron");
const path = require("path");
const fs = require("fs");
const http = require("http");
const { spawn } = require("child_process");

const PORT = process.env.NEUROPULSE_PORT || "8765";
const BASE_URL = `http://127.0.0.1:${PORT}`;

let mainWindow = null;
let backendProc = null;

function resolveProjectRoot() {
  if (app.isPackaged) {
    return process.resourcesPath;
  }
  return path.resolve(__dirname, "..");
}

function findPythonExecutable(rootDir) {
  const candidates =
    process.platform === "win32"
      ? [
          path.join(rootDir, ".venv", "Scripts", "python.exe"),
          "python",
          "py",
        ]
      : [
          path.join(rootDir, ".venv", "bin", "python3"),
          path.join(rootDir, ".venv", "bin", "python"),
          "python3",
          "python",
        ];

  for (const c of candidates) {
    if (c.includes(path.sep) && fs.existsSync(c)) return c;
    if (!c.includes(path.sep)) return c;
  }
  return "python3";
}

function startLocalBackend() {
  const rootDir = resolveProjectRoot();
  const pythonBin = findPythonExecutable(rootDir);
  const dataDir = path.join(app.getPath("userData"), "local_data");

  backendProc = spawn(pythonBin, ["-m", "backend.server"], {
    cwd: rootDir,
    env: {
      ...process.env,
      NEUROPULSE_HOST: "127.0.0.1",
      NEUROPULSE_PORT: String(PORT),
      NEUROPULSE_DATA_DIR: dataDir,
      PYTHONUNBUFFERED: "1",
    },
    stdio: "pipe",
  });

  backendProc.stdout.on("data", (d) => process.stdout.write(d));
  backendProc.stderr.on("data", (d) => process.stderr.write(d));
  backendProc.on("exit", (code) => {
    console.log(`[NeuroPulse Desktop] Local backend exited with code ${code}`);
    backendProc = null;
  });
}

function waitForBackend(timeoutMs = 25000) {
  const start = Date.now();
  return new Promise((resolve, reject) => {
    function ping() {
      const req = http.get(`${BASE_URL}/api/health`, (res) => {
        if (res.statusCode === 200) return resolve();
        retry();
      });
      req.on("error", retry);
      req.setTimeout(1500, () => {
        req.destroy();
        retry();
      });
    }
    function retry() {
      if (Date.now() - start > timeoutMs) {
        return reject(new Error("Local NeuroPulse AI backend did not respond in time."));
      }
      setTimeout(ping, 400);
    }
    ping();
  });
}

function createWindow() {
  const rootDir = resolveProjectRoot();
  const iconPath = path.join(rootDir, "assets", "icon.png");

  mainWindow = new BrowserWindow({
    width: 1360,
    height: 880,
    minWidth: 1024,
    minHeight: 700,
    backgroundColor: "#060B18",
    title: "NeuroPulse AI — Autonomous Stress Monitoring System",
    icon: fs.existsSync(iconPath) ? iconPath : undefined,
    webPreferences: {
      preload: path.join(__dirname, "preload.js"),
      contextIsolation: true,
      nodeIntegration: false,
    },
  });

  mainWindow.setMenuBarVisibility(false);
  mainWindow.loadURL(BASE_URL);
  mainWindow.on("closed", () => {
    mainWindow = null;
  });
}

function stopBackend() {
  if (backendProc && !backendProc.killed) {
    try {
      backendProc.kill("SIGTERM");
    } catch (_) {}
  }
}

ipcMain.handle("neuropulse:save-pdf", async (_event, byteArray, defaultFileName) => {
  const { canceled, filePath } = await dialog.showSaveDialog(mainWindow, {
    title: "Save NeuroPulse AI Stress Assessment Report",
    defaultPath: path.join(app.getPath("documents"), defaultFileName || "NeuroPulse_AI_Report.pdf"),
    filters: [{ name: "PDF Research Report", extensions: ["pdf"] }],
  });
  if (canceled || !filePath) {
    return { saved: false };
  }
  fs.writeFileSync(filePath, Buffer.from(byteArray));
  return { saved: true, filePath };
});

app.whenReady().then(async () => {
  startLocalBackend();
  try {
    await waitForBackend(25000);
    createWindow();
  } catch (err) {
    dialog.showErrorBox(
      "NeuroPulse AI — Local Backend Startup Error",
      `${err.message}\n\nPlease verify Python 3.9+ and backend/requirements.txt are installed.`
    );
    stopBackend();
    app.quit();
  }
});

app.on("window-all-closed", () => {
  stopBackend();
  if (process.platform !== "darwin") app.quit();
});

app.on("before-quit", () => {
  stopBackend();
});

app.on("activate", () => {
  if (mainWindow === null) createWindow();
});
