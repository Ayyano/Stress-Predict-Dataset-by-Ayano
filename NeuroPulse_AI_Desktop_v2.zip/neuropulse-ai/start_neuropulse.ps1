# NeuroPulse AI — Windows PowerShell One-Click Launcher
$ErrorActionPreference = "Stop"
Set-Location -Path $PSScriptRoot

Write-Host "==============================================================" -ForegroundColor Cyan
Write-Host "  NeuroPulse AI — Autonomous Stress Monitoring System (ASMS)" -ForegroundColor Cyan
Write-Host "==============================================================" -ForegroundColor Cyan

if (-not (Test-Path ".venv\Scripts\python.exe")) {
    Write-Host "[1/3] Creating local Python virtual environment..." -ForegroundColor Yellow
    python -m venv .venv
    Write-Host "[2/3] Installing backend dependencies..." -ForegroundColor Yellow
    .\.venv\Scripts\python.exe -m pip install --upgrade pip
    .\.venv\Scripts\python.exe -m pip install -r backend\requirements.txt
}

if (Test-Path "electron\node_modules\.bin\electron.cmd") {
    Write-Host "[3/3] Launching NeuroPulse AI Electron Desktop App..." -ForegroundColor Green
    Set-Location electron
    npm start
} else {
    Write-Host "[3/3] Starting local NeuroPulse AI server at http://127.0.0.1:8765 ..." -ForegroundColor Green
    Start-Job -ScriptBlock { Start-Sleep -Seconds 3; Start-Process "http://127.0.0.1:8765" } | Out-Null
    .\.venv\Scripts\python.exe -m backend.server
}
