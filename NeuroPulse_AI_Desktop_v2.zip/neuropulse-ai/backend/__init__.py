"""NeuroPulse AI — Autonomous Stress Monitoring System (ASMS) Local Backend."""
