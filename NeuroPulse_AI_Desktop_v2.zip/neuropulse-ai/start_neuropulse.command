#!/usr/bin/env bash
cd "$(dirname "$0")"
exec bash ./start_mac_linux.sh
