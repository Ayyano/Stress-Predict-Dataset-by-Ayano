# NeuroPulse AI — Autonomous Stress Monitoring System (ASMS)

> **Monitor Stress. Analyze Responses. Generate Insights.**

NeuroPulse AI is a 100% local, cross-platform desktop application for **macOS**, **Linux**, and **Windows** built directly around your existing `finally.ipynb` machine learning stress-analysis pipeline.

## Quick Start (Direct Double-Click)

### Windows
- Double-click **`start_windows.bat`** (requires Python 3.9+ in `PATH`).
- On first launch, it creates `.venv`, installs `backend/requirements.txt`, waits until the local ML backend is ready, and opens `http://127.0.0.1:8765` automatically.

### macOS
- Double-click **`start_neuropulse.command`** in Finder (or run `./start_mac_linux.sh` in Terminal).
- Supports macOS built-in **Python 3.9** as well as Python 3.10–3.12+ (automatically pins `reportlab==4.2.5` on Python 3.9 and polls `/api/health` before opening the browser so you never hit `ERR_CONNECTION_REFUSED`).

### Linux
- Double-click or run **`./start_mac_linux.sh`** in Terminal.

## Native Desktop Window & Installers (Electron)
1. Install **Node.js 18+**.
2. Run inside `electron/`:
   ```bash
   cd electron
   npm install
   npm start
   ```
3. Build standalone installers:
   - **Windows (`.exe` / `.msi`)**: `npm run build:win`
   - **macOS (`.dmg` / `.zip`)**: `npm run build:mac`

## Automated Verification
```bash
python3 tests/test_e2e.py
```

## A calmer interface
The default Sage theme uses warm ivory, muted sage, olive, and terracotta, with gently floating botanical details and soft transitions. The layout adapts to phone safe areas and touch targets, and respects the device's reduced-motion preference.

Ambient audio is optional and starts only when you choose it. Pick rain, ocean, felt piano, or singing bowls in the sound dock, then set the level to your comfort; audio is synthesized locally in the browser and is never sent anywhere.

## Privacy & Research Notice
All processing and SQLite record storage (`local_data/neuropulse_records.sqlite3`) happen 100% locally with zero cloud calls. Reports are intended for research and stress monitoring, not medical diagnosis.
