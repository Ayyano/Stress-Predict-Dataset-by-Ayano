/**
 * NeuroPulse AI — Rethought Whisper-Soft Acoustic Sound Identity (v9)
 * 100% Offline Web Audio API · Zero Harsh Beeps · Smooth 1.2s Crossfades
 *
 * Designed specifically for stressed or anxious patients:
 * - Separate low-gain felt-piano & water-drop micro-interaction cues
 * - 4 gentle, non-repetitive therapeutic atmospheres:
 *     "rain"  -> Soft warm rain on wooden eaves (velvet lowpass pink noise)
 *     "ocean" -> Slow coastal surf waves (0.08Hz sinusoidal breathing swell)
 *     "piano" -> Generative soft felt-piano pentatonic chords in lush warm hall reverb
 *     "bowls" -> Subtle distant singing bowl resonance (ultra-gentle decay)
 * - Strictly muted until user enables; respects volume slider & prefers-reduced-motion.
 */

class NeuroPulseAcousticIdentity {
  constructor() {
    this.enabled = false;
    this.mode = "rain";
    this.volume = 0.65;
    this.ctx = null;
    this.masterGain = null;
    this.reverbNode = null;
    this.analyser = null;
    this.activeNodes = [];
    this.timers = [];
    // Soft warm F-major / D-minor9 pentatonic frequencies (calm, grounding register)
    this.feltScale = [261.63, 293.66, 329.63, 392.0, 440.0, 523.25, 587.33];
  }

  _ensureContext() {
    const AudioCtx = window.AudioContext || window.webkitAudioContext;
    if (!AudioCtx) return false;
    if (!this.ctx) {
      this.ctx = new AudioCtx();
      this.masterGain = this.ctx.createGain();
      this.masterGain.gain.value = 0.0;

      this.analyser = this.ctx.createAnalyser();
      this.analyser.fftSize = 64;
      this.analyser.smoothingTimeConstant = 0.86;

      this.masterGain.connect(this.analyser);
      this.analyser.connect(this.ctx.destination);

      this.reverbNode = this._buildVelvetReverb(3.6, 2.8);
      this.reverbNode.connect(this.masterGain);
    }
    if (this.ctx.state === "suspended") {
      this.ctx.resume();
    }
    return true;
  }

  _buildVelvetReverb(seconds, decay) {
    const rate = this.ctx.sampleRate;
    const len = Math.floor(rate * seconds);
    const impulse = this.ctx.createBuffer(2, len, rate);
    for (let ch = 0; ch < 2; ch++) {
      const d = impulse.getChannelData(ch);
      let lp = 0;
      for (let i = 0; i < len; i++) {
        const env = Math.pow(1 - i / len, decay);
        const w = (Math.random() * 2 - 1) * env;
        lp = lp * 0.84 + w * 0.16; // Warm velvet damping (zero metallic ring)
        d[i] = lp * 0.65;
      }
    }
    const conv = this.ctx.createConvolver();
    conv.buffer = impulse;
    return conv;
  }

  _buildSoftPinkNoise(seconds = 8) {
    const rate = this.ctx.sampleRate;
    const len = rate * seconds;
    const buf = this.ctx.createBuffer(2, len, rate);
    for (let ch = 0; ch < 2; ch++) {
      const out = buf.getChannelData(ch);
      let b0 = 0, b1 = 0, b2 = 0, b3 = 0, b4 = 0, b5 = 0, b6 = 0;
      for (let i = 0; i < len; i++) {
        const w = Math.random() * 2 - 1;
        b0 = 0.99886 * b0 + w * 0.0555179;
        b1 = 0.99332 * b1 + w * 0.0750759;
        b2 = 0.96900 * b2 + w * 0.1538520;
        b3 = 0.86650 * b3 + w * 0.3104856;
        b4 = 0.55000 * b4 + w * 0.5329522;
        b5 = -0.7616 * b5 - w * 0.0168980;
        out[i] = (b0 + b1 + b2 + b3 + b4 + b5 + b6 + w * 0.5362) * 0.048;
        b6 = w * 0.115926;
      }
    }
    return buf;
  }

  setVolume(v) {
    this.volume = Math.max(0, Math.min(1, Number(v)));
    if (this.enabled && this.masterGain && this.ctx) {
      this.masterGain.gain.setTargetAtTime(this.volume, this.ctx.currentTime, 0.18);
    }
  }

  setMode(newMode) {
    this.mode = newMode;
    if (this.enabled) {
      this._stopAtmosphere();
      this._startAtmosphere();
      this.playWarmTap(3);
    }
  }

  toggle() {
    if (this.enabled) this.disable();
    else this.enable();
    return this.enabled;
  }

  enable() {
    if (!this._ensureContext()) return;
    this.enabled = true;
    this._startAtmosphere();
    this.masterGain.gain.cancelScheduledValues(this.ctx.currentTime);
    this.masterGain.gain.setTargetAtTime(this.volume, this.ctx.currentTime, 0.85);
    this.playCompletionChord();
  }

  disable() {
    this.enabled = false;
    if (this.masterGain && this.ctx) {
      this.masterGain.gain.cancelScheduledValues(this.ctx.currentTime);
      this.masterGain.gain.setTargetAtTime(0.0, this.ctx.currentTime, 0.25);
    }
    setTimeout(() => this._stopAtmosphere(), 600);
  }

  getVisualizerLevels(barCount = 6) {
    if (!this.enabled || !this.analyser) return new Array(barCount).fill(0.1);
    const data = new Uint8Array(this.analyser.frequencyBinCount);
    this.analyser.getByteFrequencyData(data);
    const out = [];
    const step = Math.max(1, Math.floor(data.length / barCount));
    for (let i = 0; i < barCount; i++) {
      out.push(Math.max(0.14, Math.min(1, (data[i * step] / 255) * 1.45)));
    }
    return out;
  }

  _stopAtmosphere() {
    this.timers.forEach((t) => clearInterval(t));
    this.timers = [];
    this.activeNodes.forEach((n) => {
      try { if (n.stop) n.stop(); } catch (_) {}
      try { if (n.disconnect) n.disconnect(); } catch (_) {}
    });
    this.activeNodes = [];
  }

  _startAtmosphere() {
    this._stopAtmosphere();
    if (!this.ctx) return;

    if (this.mode === "rain") this._startVelvetRain();
    else if (this.mode === "ocean") this._startCoastalWaves();
    else if (this.mode === "piano") this._startGenerativeFeltPiano();
    else this._startDistantBowls();
  }

  _startVelvetRain() {
    const src = this.ctx.createBufferSource();
    src.buffer = this._buildSoftPinkNoise(8);
    src.loop = true;

    const lpf = this.ctx.createBiquadFilter();
    lpf.type = "lowpass";
    lpf.frequency.value = 820;

    const lfo = this.ctx.createOscillator();
    const lfoG = this.ctx.createGain();
    lfo.frequency.value = 0.08;
    lfoG.gain.value = 190;
    lfo.connect(lfoG);
    lfoG.connect(lpf.frequency);
    lfo.start();

    const g = this.ctx.createGain();
    g.gain.value = 0.30;
    src.connect(lpf);
    lpf.connect(g);
    g.connect(this.masterGain);
    g.connect(this.reverbNode);
    src.start();
    this.activeNodes.push(src, lpf, lfo, lfoG, g);
  }

  _startCoastalWaves() {
    const src = this.ctx.createBufferSource();
    src.buffer = this._buildSoftPinkNoise(8);
    src.loop = true;

    const lpf = this.ctx.createBiquadFilter();
    lpf.type = "lowpass";
    lpf.frequency.value = 460;

    const swell = this.ctx.createOscillator();
    swell.frequency.value = 0.078; // Slow 12.8s ocean breath
    const fMod = this.ctx.createGain();
    fMod.gain.value = 280;
    swell.connect(fMod);
    fMod.connect(lpf.frequency);

    const g = this.ctx.createGain();
    g.gain.value = 0.25;
    const aMod = this.ctx.createGain();
    aMod.gain.value = 0.14;
    swell.connect(aMod);
    aMod.connect(g.gain);

    src.connect(lpf);
    lpf.connect(g);
    g.connect(this.reverbNode);
    g.connect(this.masterGain);
    swell.start();
    src.start();
    this.activeNodes.push(src, lpf, swell, fMod, g, aMod);
  }

  _startGenerativeFeltPiano() {
    // Soft ambient felt-piano chords spaced generously (every 4.8 seconds)
    const chords = [
      [261.63, 329.63, 392.0, 493.88],  // Cmaj7
      [220.0, 261.63, 329.63, 392.0],   // Am7
      [174.61, 220.0, 261.63, 329.63],  // Fmaj7
      [196.0, 246.94, 293.66, 392.0],   // G6
    ];
    let ci = 0;
    const playChord = () => {
      if (!this.enabled) return;
      const chord = chords[ci % chords.length];
      ci += 1;
      chord.forEach((f, idx) => {
        setTimeout(() => this._playFeltNote(f, 0.042, 3.8), idx * 165);
      });
    };
    playChord();
    this.timers.push(setInterval(playChord, 5200));
  }

  _startDistantBowls() {
    const notes = [174.61, 220.0, 261.63, 329.63];
    let ni = 0;
    const ring = () => {
      if (!this.enabled) return;
      this._playBowl(notes[ni % notes.length], 0.052);
      ni += 1;
    };
    ring();
    this.timers.push(setInterval(ring, 7600));
  }

  _playFeltNote(freq, peak = 0.05, dur = 2.6) {
    if (!this.ctx || !this.enabled) return;
    const now = this.ctx.currentTime;
    const osc = this.ctx.createOscillator();
    const lpf = this.ctx.createBiquadFilter();
    const g = this.ctx.createGain();

    osc.type = "triangle";
    osc.frequency.value = freq;
    lpf.type = "lowpass";
    lpf.frequency.setValueAtTime(freq * 2.4, now);
    lpf.frequency.exponentialRampToValueAtTime(freq * 1.1, now + dur * 0.7);

    g.gain.setValueAtTime(0.0001, now);
    g.gain.linearRampToValueAtTime(peak, now + 0.045); // Soft felt-hammer attack
    g.gain.exponentialRampToValueAtTime(0.0001, now + dur);

    osc.connect(lpf);
    lpf.connect(g);
    g.connect(this.reverbNode);
    g.connect(this.masterGain);
    osc.start(now);
    osc.stop(now + dur + 0.1);
  }

  _playBowl(freq, peak = 0.05) {
    if (!this.ctx || !this.enabled) return;
    const now = this.ctx.currentTime;
    [1, 2.756].forEach((mult, idx) => {
      const osc = this.ctx.createOscillator();
      const g = this.ctx.createGain();
      osc.type = "sine";
      osc.frequency.value = freq * mult;
      const amp = idx === 0 ? peak : peak * 0.2;
      g.gain.setValueAtTime(0.0001, now);
      g.gain.linearRampToValueAtTime(amp, now + 1.1);
      g.gain.exponentialRampToValueAtTime(0.0001, now + 7.0);
      osc.connect(g);
      g.connect(this.reverbNode);
      osc.start(now);
      osc.stop(now + 7.2);
    });
  }

  /* Whisper-soft felt-piano micro-interaction tap */
  playWarmTap(stepIndex = 0) {
    if (!this.enabled || !this.ctx) return;
    const freq = this.feltScale[Math.abs(stepIndex) % this.feltScale.length];
    this._playFeltNote(freq, 0.052, 0.75);
  }

  /* Gentle rising two-note resolution chime */
  playCompletionChord() {
    if (!this.enabled || !this.ctx) return;
    [261.63, 329.63, 392.0].forEach((f, i) => {
      setTimeout(() => this._playFeltNote(f, 0.055, 2.2), i * 130);
    });
  }

  playStepChime(idxOrFreq = 0) {
    const idx = idxOrFreq > 20 ? Math.round(idxOrFreq / 60) : idxOrFreq;
    this.playWarmTap(idx);
  }
}

window.neuroAudio = new NeuroPulseAcousticIdentity();
