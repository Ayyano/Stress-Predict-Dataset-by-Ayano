"""
NeuroPulse AI — Comprehensive Automated QA & End-to-End Verification Suite (v8).
Validates:
  1. Health endpoint & local-only status
  2. High-stress, borderline-moderate, and calm-normal inference
  3. Input validation (422 on out-of-range PSS / STAI / HR)
  4. 4-page Patient-Only Therapeutic PDF generation for BOTH high-stress & calm profiles
  5. Local SQLite Records CRUD + 404 error state
  6. Frontend HTML/CSS/JS static serving & cache-control headers
"""

import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))

from fastapi.testclient import TestClient  # noqa: E402
from backend.server import app  # noqa: E402


def run_tests():
    client = TestClient(app)

    # 1. Health Check
    r_health = client.get("/api/health")
    assert r_health.status_code == 200
    h = r_health.json()
    assert h["status"] == "ok" and h["local_only"] is True
    print(f"[PASS] /api/health -> mode={h['engine_mode']}, models={h['models_loaded']}")

    # 2. High-Stress Profile
    high_payload = {
        "participant_name": "Ayan_Stress_Check",
        "age": 29,
        "gender": "Female",
        "pss_score": 28,
        "stai_state": 60,
        "stai_trait": 49,
        "hr": 74.0,
        "stroop_hr": 87.5,
        "interview_hr": 97.0,
        "hypervent_hr": 92.0,
        "rr": 15.2,
        "stress_rr": 22.0,
        "mean_eda": 4.3,
        "skin_temp": 32.2,
        "save_record": True,
    }
    r_s = client.post("/api/analyze", json=high_payload)
    assert r_s.status_code == 200
    res_s = r_s.json()
    assert res_s["backend_predictions"]["is_stressed"] is True
    rec_id = res_s["meta"]["record_id"]
    print(f"[PASS] /api/analyze (High Stress) -> prob={res_s['backend_predictions']['stress_probability']}%")

    # 3. Calm / Normal Profile
    calm_payload = {
        "participant_name": "Ayan_Calm_Baseline",
        "age": 31,
        "gender": "Male",
        "pss_score": 9,
        "stai_state": 29,
        "stai_trait": 31,
        "hr": 68.0,
        "stroop_hr": 73.0,
        "interview_hr": 77.0,
        "hypervent_hr": 75.0,
        "rr": 14.2,
        "stress_rr": 16.5,
        "mean_eda": 1.15,
        "skin_temp": 33.7,
        "save_record": False,
    }
    r_n = client.post("/api/analyze", json=calm_payload)
    assert r_n.status_code == 200
    res_n = r_n.json()
    assert res_n["backend_predictions"]["is_stressed"] is False
    print(f"[PASS] /api/analyze (Calm Normal) -> prob={res_n['backend_predictions']['stress_probability']}%")

    # 4. Input Validation Error State (PSS > 40 must return 422)
    bad_payload = dict(calm_payload, pss_score=99)
    r_bad = client.post("/api/analyze", json=bad_payload)
    assert r_bad.status_code == 422
    print("[PASS] /api/analyze validation -> rejected out-of-range PSS=99 with HTTP 422")

    # 5. PDF Generation (Both High-Stress & Calm Profiles)
    for tag, res_obj in [("stress", res_s), ("calm", res_n)]:
        r_pdf = client.post("/api/report/pdf", json={"result": res_obj})
        assert r_pdf.status_code == 200
        assert r_pdf.content[:4] == b"%PDF"
        assert len(r_pdf.content) > 50000
        out_p = ROOT / "tests" / f"_verified_{tag}_report.pdf"
        out_p.write_bytes(r_pdf.content)
        print(f"[PASS] /api/report/pdf ({tag}) -> valid PDF ({len(r_pdf.content):,} bytes)")

    # 6. Local Records CRUD + 404 Error State
    assert any(r["id"] == rec_id for r in client.get("/api/records").json()["records"])
    assert client.get(f"/api/records/{rec_id}").status_code == 200
    assert client.delete(f"/api/records/{rec_id}").json()["deleted"] is True
    assert client.get(f"/api/records/{rec_id}").status_code == 404
    print(f"[PASS] /api/records CRUD & 404 handling verified ({rec_id})")

    # 7. Frontend Static Serving & No-Cache Headers
    r_idx = client.get("/")
    assert r_idx.status_code == 200 and "NeuroPulse" in r_idx.text
    assert "no-store" in r_idx.headers.get("cache-control", "")
    for asset in ["/static/styles.css", "/static/app.js", "/static/charts.js", "/static/audio.js"]:
        ra = client.get(asset)
        assert ra.status_code == 200, f"Failed loading {asset}"
    print("[PASS] Frontend SPA, assets & no-store cache headers verified")
    print("\nALL v8 QUALITY ASSURANCE CHECKS PASSED!")


if __name__ == "__main__":
    run_tests()
