"""
NeuroPulse AI — Deterministic 600-Participant Dataset & Cohort Baseline Engine.
Preserves the exact data generation logic, cohorts, distributions, and Unicode-safe
column resolution from the user's existing `finally.ipynb` backend.
"""

from __future__ import annotations

import datetime
from pathlib import Path
from typing import Dict, Optional, Tuple

import numpy as np
import pandas as pd


CANONICAL_COLUMNS = {
    "pid": "Participant_ID",
    "name": "Assigned Name",
    "age": "Age",
    "gender": "Gender",
    "pss": "PSS Score (0-40)",
    "stai_s": "STAI-State (20-80)",
    "stai_t": "STAI-Trait (20-80)",
    "hr": "HR",
    "stroop_hr": "Stroop HR (bpm)",
    "interview_hr": "Interview HR (bpm)",
    "hypervent_hr": "Hyperventilation HR (bpm)",
    "rr": "RR",
    "stress_rr": "Stress Resp Rate (brpm)",
    "eda": "Mean EDA (μS)",
    "temp": "Skin Temp (°C)",
    "label": "Label",
    "time": "Time",
}


def find_col(columns, *keywords) -> Optional[str]:
    """Unicode-safe fuzzy column matcher from finally.ipynb."""
    for c in columns:
        cl = str(c).lower()
        if all(k in cl for k in keywords):
            return c
    return None


def resolve_columns(df: pd.DataFrame) -> Dict[str, Optional[str]]:
    """Resolve canonical column names safely across Unicode micro-sign variants."""
    cols = [str(c).strip() for c in df.columns]
    df.columns = cols
    return {
        "pid": find_col(cols, "participant") or find_col(cols, "id"),
        "name": find_col(cols, "name"),
        "age": find_col(cols, "age"),
        "gender": find_col(cols, "gender"),
        "pss": find_col(cols, "pss"),
        "stai_s": find_col(cols, "stai", "state"),
        "stai_t": find_col(cols, "stai", "trait"),
        "hr": next((c for c in cols if c.lower() in ["hr", "heart_rate", "heart rate", "baseline hr"]), None),
        "stroop_hr": find_col(cols, "stroop"),
        "interview_hr": find_col(cols, "interview"),
        "hypervent_hr": find_col(cols, "hypervent"),
        "rr": next((c for c in cols if c.lower() in ["rr", "resp_rate", "respiratory_rate", "baseline rr"]), None),
        "stress_rr": find_col(cols, "stress", "resp") or find_col(cols, "stress", "rr"),
        "eda": find_col(cols, "eda"),
        "temp": find_col(cols, "temp"),
        "label": find_col(cols, "label") or find_col(cols, "target"),
    }


def generate_builtin_600_dataset(save_path: Optional[Path] = None) -> pd.DataFrame:
    """
    Exact deterministic 600-participant dataset generator from finally.ipynb.
    Uses np.random.default_rng(42) across 6 demographic cohorts (Man, Woman,
    Boy, Girl, Senior, Kid) with 100 participants each (50 Normal / 50 Stressed).
    """
    rng = np.random.default_rng(42)
    cohorts = [
        ("Man", 100, 20, 59, "Male", 71.0, 3.8, 14.8, 0.9, 1.00),
        ("Woman", 100, 20, 59, "Female", 73.0, 3.8, 15.2, 0.9, 1.00),
        ("Boy", 100, 13, 19, "Male", 77.5, 4.2, 16.4, 1.1, 1.05),
        ("Girl", 100, 13, 19, "Female", 79.5, 4.2, 16.8, 1.1, 1.05),
        ("Senior", 100, 60, 85, "Mixed", 69.0, 4.5, 15.5, 1.2, 0.80),
        ("Kid", 100, 6, 12, "Mixed", 90.0, 4.0, 20.0, 1.3, 1.10),
    ]
    rows = []
    start_time = datetime.datetime(2026, 11, 1, 9, 0, 0)
    pnum = 1
    for ckey, cnt, amin, amax, gmode, hrm, hrsd, rrm, rrsd, dscale in cohorts:
        labels = np.array([0] * (cnt // 2) + [1] * (cnt // 2))
        rng.shuffle(labels)
        if gmode == "Mixed":
            genders = np.array(["Male"] * (cnt // 2) + ["Female"] * (cnt // 2))
            rng.shuffle(genders)
        else:
            genders = np.array([gmode] * cnt)
        for i in range(cnt):
            lbl = int(labels[i])
            b_hr = float(np.clip(rng.normal(hrm, hrsd), hrm - 10, hrm + 10))
            b_rr = float(np.clip(rng.normal(rrm, rrsd), rrm - 3.5, rrm + 3.5))
            boost = 1.25 if lbl == 1 else 0.75
            stroop_hr = b_hr + float(rng.uniform(5.5, 11.5) * dscale * boost)
            inter_hr = b_hr + float(rng.uniform(11.0, 19.5) * dscale * boost)
            hyper_hr = b_hr + float(rng.uniform(8.0, 15.5) * dscale * boost)
            stress_rr = b_rr + float(rng.uniform(3.2, 6.8) * dscale * boost)
            if lbl == 1:
                pss = int(np.clip(round(rng.normal(24.0, 5.5)), 0, 40))
                stai_t = int(np.clip(round(rng.normal(48.0, 8.5)), 20, 80))
                stai_s = int(np.clip(round(stai_t + rng.normal(7.0, 5.0)), 20, 80))
                eda = float(np.clip(rng.normal(3.8, 1.1), 1.2, 8.5))
                temp = float(np.clip(rng.normal(32.6, 0.6), 30.8, 34.5))
            else:
                pss = int(np.clip(round(rng.normal(12.0, 4.5)), 0, 40))
                stai_t = int(np.clip(round(rng.normal(34.0, 6.5)), 20, 80))
                stai_s = int(np.clip(round(stai_t + rng.normal(-2.0, 4.0)), 20, 80))
                eda = float(np.clip(rng.normal(1.4, 0.5), 0.3, 3.2))
                temp = float(np.clip(rng.normal(33.3, 0.5), 31.5, 35.0))
            ts = (start_time + datetime.timedelta(minutes=15 * (pnum - 1))).strftime("%Y-%m-%d %H:%M:%S")
            rows.append(
                {
                    "Participant_ID": f"S{pnum:03d}",
                    "Assigned Name": f"Synthetic_{ckey}_{i+1:03d}",
                    "Age": int(rng.integers(amin, amax + 1)),
                    "Gender": str(genders[i]),
                    "PSS Score (0-40)": pss,
                    "STAI-State (20-80)": stai_s,
                    "STAI-Trait (20-80)": stai_t,
                    "HR": round(b_hr, 2),
                    "Stroop HR (bpm)": round(stroop_hr, 2),
                    "Interview HR (bpm)": round(inter_hr, 2),
                    "Hyperventilation HR (bpm)": round(hyper_hr, 2),
                    "RR": round(b_rr, 2),
                    "Stress Resp Rate (brpm)": round(stress_rr, 2),
                    "Mean EDA (μS)": round(eda, 3),
                    "Skin Temp (°C)": round(temp, 2),
                    "Label": lbl,
                    "Time": ts,
                }
            )
            pnum += 1
    out_df = pd.DataFrame(rows)
    if save_path is not None:
        save_path.parent.mkdir(parents=True, exist_ok=True)
        out_df.to_csv(save_path, index=False, encoding="utf-8-sig")
    return out_df


def load_or_create_dataset(data_dir: Path) -> Tuple[pd.DataFrame, str]:
    """
    Loads a user-supplied CSV from `data_dir` if present (matching `finally.ipynb`
    discovery), otherwise generates the deterministic 600-participant dataset.
    """
    data_dir.mkdir(parents=True, exist_ok=True)
    for csv_file in sorted(data_dir.glob("*.csv")):
        if "600" in csv_file.name.lower() or "stress" in csv_file.name.lower():
            df = pd.read_csv(csv_file)
            return df, csv_file.name
    default_csv = data_dir / "synthetic_stress_predict_600_participants.csv"
    df = generate_builtin_600_dataset(default_csv)
    return df, default_csv.name


def assign_age_cohort(age: float, gender: str) -> str:
    """Map participant age & gender to the 6 demographic cohorts in finally.ipynb."""
    g = str(gender).strip().lower()
    if age <= 12:
        return "Kid"
    if age <= 19:
        return "Boy" if g == "male" else "Girl"
    if age >= 60:
        return "Senior"
    return "Man" if g == "male" else "Woman"
