"""
NeuroPulse AI — Authentic Hospital Pathology & Autonomic Stress Report (v9).
100% STRICT PATIENT DATA ISOLATION — Zero other patients, zero external datasets.

Design & Layout Engineering:
  - Unified Cozy Warm Earthy Palette:
      Warm Ivory (#FAF6EF) · Soft Beige (#F2E9DB) · Muted Sage (#4E6E58)
      Gentle Olive (#738257) · Soft Terracotta (#C2704E) · Deep Forest Green (#213B30)
      Clinical Crimson (#A63A32) reserved STRICTLY for critical/high pathology flags.
  - Intelligent, balanced 3-page layout with ZERO half-empty pages or wasted voids:
      Page 1: Pathology Lab Header, Patient Demographics & Verification Strip,
              Critical-Value Alert Banner (when applicable), 4 KPI Cards,
              Heart Rate Protocol Chart + 6-Domain Stress Radar, Crisp Clinical Takeaways.
      Page 2: Complete Hospital Pathology Reference Table (Test & Medical Significance |
              Patient Result | Unit | Normal Reference Range | Previous Result | Status),
              Detailed Explanations of Abnormal Findings, Task-by-Task Reactivity Matrix.
      Page 3: Visual Pathology Range Strip, Respiratory/Psychometric Cutoffs (or Patient
              Longitudinal Trend when prior visit exists), Personalized Clinical
              Recommendations, Patient Conclusion & Medical Disclaimer.
"""

from __future__ import annotations

import io
from typing import Any, Dict, List, Optional, Tuple

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import matplotlib.patches as mpatches
import numpy as np
from reportlab.lib import colors
from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import ParagraphStyle, getSampleStyleSheet
from reportlab.lib.units import mm
from reportlab.platypus import (
    Image as RLImage,
    KeepTogether,
    PageBreak,
    Paragraph,
    SimpleDocTemplate,
    Spacer,
    Table,
    TableStyle,
)

# Unified Cozy Earthy Pathology Palette
FOREST = colors.HexColor("#213B30")
FOREST_MID = colors.HexColor("#335446")
SAGE = colors.HexColor("#4E6E58")
OLIVE = colors.HexColor("#738257")
TERRACOTTA = colors.HexColor("#C2704E")
BROWN = colors.HexColor("#6B5647")
CRIMSON = colors.HexColor("#A63A32")  # Reserved strictly for critical/high clinical alerts
AMBER = colors.HexColor("#B07A2A")

INK = colors.HexColor("#26221E")
INK_SOFT = colors.HexColor("#524942")
MUTED = colors.HexColor("#7E7268")

IVORY = colors.HexColor("#FAF6EF")
BEIGE = colors.HexColor("#F2E9DB")
SAGE_TINT = colors.HexColor("#EDF3EE")
ALERT_TINT = colors.HexColor("#FBEFEC")
BORDER = colors.HexColor("#DED2C0")


def _esc(text: Any) -> str:
    s = str(text)
    s = s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")
    for k, v in {
        "μ": "u",
        "µ": "u",
        "Δ": "Delta ",
        "°": " deg ",
        "—": " - ",
        "–": "-",
        "→": "->",
        "•": "*",
    }.items():
        s = s.replace(k, v)
    return s


def _classify_flag(val: float, low: float, high: float, crit_hi: Optional[float] = None, low_is_bad: bool = False) -> Tuple[str, str]:
    if low_is_bad and val < low:
        return ("LOW", "#A63A32")
    if val < low:
        return ("LOW", "#B07A2A")
    if crit_hi is not None and val > crit_hi:
        return ("HIGH *", "#A63A32")
    if val > high:
        return ("BORDERLINE", "#B07A2A")
    return ("NORMAL", "#4E6E58")


def _fmt_prev(prev: Optional[Dict[str, Any]], key: str, spec: str = ".1f") -> str:
    if not prev or prev.get(key) is None:
        return "First Visit"
    try:
        return format(float(prev[key]), spec)
    except Exception:
        return "First Visit"


def _make_hr_chart(result: Dict[str, Any]) -> io.BytesIO:
    m = result["measured_values"]
    d = result["derived_calculations"]

    labels = ["Resting\nBaseline", "Stroop\n(Cognitive)", "Interview\n(Social)", "Hypervent.\n(Resp.)"]
    vals = [m["hr"], m["stroop_hr"], m["interview_hr"], m["hypervent_hr"]]
    deltas = ["Base", f"{d['delta_stroop_hr']:+.1f}", f"{d['delta_interview_hr']:+.1f}", f"{d['delta_hypervent_hr']:+.1f}"]
    cols = ["#4E6E58", "#738257", "#A63A32" if d["delta_interview_hr"] >= 18 else "#C2704E", "#C2704E"]

    fig, ax = plt.subplots(figsize=(5.3, 3.05), dpi=210)
    fig.patch.set_facecolor("#FFFFFF")
    ax.set_facecolor("#FAF6EF")

    ax.axhspan(60, 80, color="#4E6E58", alpha=0.11, label="Normal Resting Band (60-80 bpm)")
    x = np.arange(len(labels))
    bars = ax.bar(x, vals, width=0.50, color=cols, edgecolor="#213B30", linewidth=0.5)
    for bar, val, dl in zip(bars, vals, deltas):
        ax.text(bar.get_x() + bar.get_width() / 2, val + 1.8, f"{val:.0f}", ha="center", va="bottom", fontsize=8.0, fontweight="bold", color="#26221E")
        if dl != "Base":
            ax.text(bar.get_x() + bar.get_width() / 2, val * 0.50, f"{dl}\nbpm", ha="center", va="center", fontsize=6.9, fontweight="bold", color="#FFFFFF")

    ax.set_title("Patient Heart Rate Across Protocol Phases", fontsize=9.3, fontweight="bold", color="#213B30", pad=9)
    ax.set_ylabel("Heart Rate (bpm)", fontsize=7.9, color="#524942")
    ax.set_xticks(x)
    ax.set_xticklabels(labels, fontsize=7.5, color="#26221E")
    ax.set_ylim(0, max(vals) + 22)
    ax.grid(axis="y", linestyle="--", color="#DED2C0", alpha=0.75)
    ax.spines["top"].set_visible(False)
    ax.spines["right"].set_visible(False)
    ax.legend(frameon=False, fontsize=7.1, loc="upper left")
    plt.tight_layout()

    buf = io.BytesIO()
    fig.savefig(buf, format="png", dpi=210)
    plt.close(fig)
    buf.seek(0)
    return buf


def _make_radar_chart(result: Dict[str, Any]) -> io.BytesIO:
    radar = result["cohort_comparison"]["radar_profile"]
    labels = ["Cardio\nReact.", "Resp.\nShift", "EDA\nArousal", "Thermal\nDrop", "PSS\nStress", "STAI-S\nAnxiety"]
    p_vals = radar["participant"]
    ref_vals = [40.0, 40.0, 35.0, 35.0, 33.0, 30.0]

    angles = np.linspace(0, 2 * np.pi, len(labels), endpoint=False).tolist()
    p_plot = p_vals + [p_vals[0]]
    r_plot = ref_vals + [ref_vals[0]]
    angles_plot = angles + [angles[0]]

    fig = plt.figure(figsize=(4.7, 3.1), dpi=210)
    fig.patch.set_facecolor("#FFFFFF")
    ax = fig.add_subplot(111, polar=True)
    ax.set_facecolor("#FAF6EF")

    ax.plot(angles_plot, r_plot, color="#4E6E58", linewidth=1.3, linestyle="--", label="Calm Clinical Limit")
    ax.fill(angles_plot, r_plot, color="#4E6E58", alpha=0.12)

    p_col = "#A63A32" if result["backend_predictions"]["is_stressed"] else "#4E6E58"
    ax.plot(angles_plot, p_plot, color=p_col, linewidth=2.2, label="Patient Profile")
    ax.fill(angles_plot, p_plot, color=p_col, alpha=0.22)

    ax.set_xticks(angles)
    ax.set_xticklabels(labels, fontsize=7.1, color="#26221E", fontweight="bold")
    ax.set_ylim(0, 100)
    ax.set_yticks([25, 50, 75, 100])
    ax.set_yticklabels(["25", "50", "75", "100"], fontsize=6.3, color="#7E7268")
    ax.grid(color="#DED2C0", linestyle="-", linewidth=0.6)
    ax.spines["polar"].set_color("#CBBCA6")
    ax.set_title("Patient 6-Domain Autonomic Profile", fontsize=9.0, fontweight="bold", color="#213B30", pad=15)
    ax.legend(loc="upper center", bbox_to_anchor=(0.5, -0.14), ncol=2, frameon=False, fontsize=7.1)
    plt.tight_layout()

    buf = io.BytesIO()
    fig.savefig(buf, format="png", dpi=210)
    plt.close(fig)
    buf.seek(0)
    return buf


def _make_gauge_strip(result: Dict[str, Any]) -> io.BytesIO:
    m = result["measured_values"]
    d = result["derived_calculations"]

    gauges = [
        ("Resting HR", m["hr"], 45, 115, 60, 80, "bpm"),
        ("Mean Task Delta HR", d["mean_task_hr_delta"], 0, 30, 0, 12, "bpm"),
        ("Resting Resp. Rate", m["rr"], 8, 28, 12, 18, "brpm"),
        ("Stress Resp. Rate", m["stress_rr"], 10, 34, 12, 20, "brpm"),
        ("Mean EDA", m["mean_eda"], 0, 7.0, 0.3, 2.5, "uS"),
        ("Skin Temperature", m["skin_temp"], 30.0, 36.0, 32.8, 35.0, "C"),
        ("PSS Score (0-40)", m["pss_score"], 0, 40, 0, 13, "pts"),
        ("STAI-State (20-80)", m["stai_state"], 20, 80, 20, 37, "pts"),
    ]

    fig, ax = plt.subplots(figsize=(9.6, 3.15), dpi=210)
    fig.patch.set_facecolor("#FFFFFF")
    ax.set_facecolor("#FFFFFF")

    y_pos = np.arange(len(gauges))
    for i, (lbl, val, lo, hi, n_lo, n_hi, unit) in enumerate(gauges):
        ax.barh(i, 1.0, height=0.38, color="#F2E9DB", edgecolor="#DED2C0", linewidth=0.5)
        x_start = (n_lo - lo) / (hi - lo)
        x_width = (n_hi - n_lo) / (hi - lo)
        ax.barh(i, x_width, left=x_start, height=0.38, color="#4E6E58", alpha=0.30)

        px = float(np.clip((val - lo) / (hi - lo), 0.02, 0.98))
        in_norm = n_lo <= val <= n_hi
        m_col = "#4E6E58" if in_norm else "#A63A32"
        ax.scatter([px], [i], s=92, marker="D", color=m_col, edgecolor="#213B30", linewidth=0.85, zorder=5)

        st = "NORMAL" if in_norm else ("LOW" if val < n_lo else "HIGH")
        ax.text(1.03, i, f"{val:.1f} {unit}  [{st}]", va="center", ha="left", fontsize=7.5, fontweight="bold", color=m_col)

    ax.set_yticks(y_pos)
    ax.set_yticklabels([g[0] for g in gauges], fontsize=7.9, fontweight="bold", color="#26221E")
    ax.invert_yaxis()
    ax.set_xlim(0, 1.34)
    ax.set_xticks([])
    for sp in ["top", "right", "bottom", "left"]:
        ax.spines[sp].set_visible(False)

    norm_p = mpatches.Patch(color="#4E6E58", alpha=0.30, label="Standard Laboratory Normal Range")
    ok_m = plt.Line2D([0], [0], marker="D", color="w", markerfacecolor="#4E6E58", markeredgecolor="#213B30", markersize=7, label="Patient Within Normal")
    hi_m = plt.Line2D([0], [0], marker="D", color="w", markerfacecolor="#A63A32", markeredgecolor="#213B30", markersize=7, label="Patient Outside Normal")
    ax.legend(handles=[norm_p, ok_m, hi_m], loc="upper center", bbox_to_anchor=(0.46, 1.08), ncol=3, frameon=False, fontsize=7.3)
    ax.set_title("Visual Pathology Reference Range Strip (Patient Position)", fontsize=9.6, fontweight="bold", color="#213B30", pad=26)
    plt.tight_layout()

    buf = io.BytesIO()
    fig.savefig(buf, format="png", dpi=210, bbox_inches="tight", pad_inches=0.12)
    plt.close(fig)
    buf.seek(0)
    return buf


def _make_rr_psych_or_trend_chart(result: Dict[str, Any]) -> io.BytesIO:
    """Left: Patient Respiratory & Psychometric Cutoffs. Right: Patient Longitudinal Trend if prior visits exist, else Psychometric Cutoffs."""
    m = result["measured_values"]
    hist = result.get("patient_history", {}).get("prior_visits", [])

    fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(9.6, 2.5), dpi=200)
    fig.patch.set_facecolor("#FFFFFF")

    # Left: Respiratory Shift
    ax1.set_facecolor("#FAF6EF")
    ax1.bar(["Resting RR", "Stress RR"], [m["rr"], m["stress_rr"]], width=0.44, color=["#4E6E58", "#C2704E"], edgecolor="#213B30", linewidth=0.45)
    ax1.axhline(18.0, color="#4E6E58", linestyle="--", linewidth=1.1, label="Normal Upper Limit (18 brpm)")
    ax1.text(0, m["rr"] + 0.6, f"{m['rr']:.1f}", ha="center", fontsize=8.0, fontweight="bold", color="#26221E")
    ax1.text(1, m["stress_rr"] + 0.6, f"{m['stress_rr']:.1f}", ha="center", fontsize=8.0, fontweight="bold", color="#26221E")
    ax1.set_title("A. Patient Breathing Shift (brpm)", fontsize=9.0, fontweight="bold", color="#213B30")
    ax1.set_ylim(0, max(m["stress_rr"], 22) + 6)
    ax1.grid(axis="y", linestyle="--", color="#DED2C0", alpha=0.8)
    ax1.spines["top"].set_visible(False)
    ax1.spines["right"].set_visible(False)
    ax1.legend(frameon=False, fontsize=7.0, loc="upper left")

    # Right: Patient Longitudinal Stress Trend (ONLY this patient's own visits!) OR Psychological Cutoffs
    ax2.set_facecolor("#FAF6EF")
    if hist:
        pts = list(reversed(hist)) + [{"date": result["meta"]["timestamp"], "stress_probability": result["backend_predictions"]["stress_probability"]}]
        xs = np.arange(len(pts))
        ys = [float(x["stress_probability"]) for x in pts]
        x_lbls = [str(x["date"])[5:10] for x in pts]
        x_lbls[-1] = "Current"
        ax2.plot(xs, ys, marker="o", linewidth=2.2, color="#C2704E", markerfacecolor="#213B30", markersize=6)
        ax2.fill_between(xs, ys, alpha=0.14, color="#C2704E")
        ax2.axhline(50, color="#4E6E58", linestyle="--", linewidth=1.0, label="Calm/Stress Threshold (50%)")
        for xi, yi in zip(xs, ys):
            ax2.text(xi, yi + 3.5, f"{yi:.0f}%", ha="center", fontsize=7.4, fontweight="bold", color="#26221E")
        ax2.set_xticks(xs)
        ax2.set_xticklabels(x_lbls, fontsize=7.6, color="#26221E")
        ax2.set_ylim(0, 112)
        ax2.set_title("B. Patient Longitudinal Stress Trend", fontsize=9.0, fontweight="bold", color="#213B30")
        ax2.grid(axis="y", linestyle="--", color="#DED2C0", alpha=0.8)
        ax2.spines["top"].set_visible(False)
        ax2.spines["right"].set_visible(False)
        ax2.legend(frameon=False, fontsize=7.0, loc="upper left")
    else:
        p_lbls = ["PSS\n(0-40)", "STAI-State\n(20-80)", "STAI-Trait\n(20-80)"]
        p_vals = [m["pss_score"], m["stai_state"], m["stai_trait"]]
        p_cols = ["#738257", "#A63A32" if m["stai_state"] >= 45 else "#4E6E58", "#C2704E"]
        ax2.bar(p_lbls, p_vals, width=0.44, color=p_cols, edgecolor="#213B30", linewidth=0.45)
        ax2.axhline(37.0, color="#4E6E58", linestyle="--", linewidth=1.1, label="Low Anxiety Limit (<= 37)")
        ax2.axhline(13.0, color="#738257", linestyle=":", linewidth=1.2, label="Low Stress Limit (<= 13)")
        for i, v in enumerate(p_vals):
            ax2.text(i, v + 1.8, f"{v:.0f}", ha="center", fontsize=8.0, fontweight="bold", color="#26221E")
        ax2.set_title("B. Patient Psychological Cutoffs", fontsize=9.0, fontweight="bold", color="#213B30")
        ax2.set_ylim(0, 92)
        ax2.grid(axis="y", linestyle="--", color="#DED2C0", alpha=0.8)
        ax2.spines["top"].set_visible(False)
        ax2.spines["right"].set_visible(False)
        ax2.legend(frameon=False, fontsize=6.9, loc="upper left")

    plt.tight_layout()
    buf = io.BytesIO()
    fig.savefig(buf, format="png", dpi=200)
    plt.close(fig)
    buf.seek(0)
    return buf


def _page_decor(canvas, doc):
    canvas.saveState()
    w = A4[0]
    h = A4[1]
    # Crisp thin forest-green top line on pages 2+
    if doc.page > 1:
        canvas.setFillColor(FOREST)
        canvas.rect(12 * mm, h - 8.5 * mm, w - 24 * mm, 1.3, fill=1, stroke=0)

    canvas.setStrokeColor(BORDER)
    canvas.setLineWidth(0.7)
    canvas.line(12 * mm, 12.5 * mm, w - 12 * mm, 12.5 * mm)
    canvas.setFont("Helvetica", 7.2)
    canvas.setFillColor(MUTED)
    canvas.drawString(12 * mm, 7.8 * mm, "NeuroPulse AI Clinical Pathology & Autonomic Laboratory  |  Confidential Patient-Only Report (Local Verification)")
    canvas.drawRightString(w - 12 * mm, 7.8 * mm, f"Page {doc.page} of 3")
    canvas.restoreState()


def generate_clinical_pdf_bytes(result: Dict[str, Any]) -> bytes:
    """Build a balanced, dense, zero-wasted-space 3-page Authentic Patient Pathology Report."""
    buf = io.BytesIO()
    doc = SimpleDocTemplate(
        buf,
        pagesize=A4,
        leftMargin=12 * mm,
        rightMargin=12 * mm,
        topMargin=11 * mm,
        bottomMargin=16 * mm,
        title="NeuroPulse AI - Patient Pathology & Autonomic Stress Report",
        author="NeuroPulse AI Local Clinical Laboratory",
    )

    styles = getSampleStyleSheet()
    s_ban_t = ParagraphStyle("BT", parent=styles["Heading1"], fontName="Helvetica-Bold", fontSize=14.0, leading=17.5, textColor=IVORY, spaceAfter=1.5)
    s_ban_s = ParagraphStyle("BS", parent=styles["Normal"], fontName="Helvetica", fontSize=8.0, leading=11.0, textColor=colors.HexColor("#D8E2DC"))
    s_h2 = ParagraphStyle("H2", parent=styles["Heading2"], fontName="Helvetica-Bold", fontSize=10.6, leading=13.5, textColor=FOREST, spaceBefore=7, spaceAfter=4)
    s_body = ParagraphStyle("BODY", parent=styles["Normal"], fontName="Helvetica", fontSize=8.3, leading=11.8, textColor=INK_SOFT, spaceAfter=3)
    s_bul = ParagraphStyle("BUL", parent=s_body, leftIndent=10, firstLineIndent=-6, spaceAfter=3.2)
    s_cell = ParagraphStyle("CELL", parent=styles["Normal"], fontName="Helvetica", fontSize=7.4, leading=9.8, textColor=INK_SOFT)
    s_cell_b = ParagraphStyle("CELLB", parent=s_cell, fontName="Helvetica-Bold", textColor=INK)
    s_hdr = ParagraphStyle("HDR", parent=s_cell, fontName="Helvetica-Bold", textColor=IVORY)
    s_kpi_v = ParagraphStyle("KV", parent=styles["Heading2"], fontName="Helvetica-Bold", fontSize=12.8, leading=15.5, alignment=1, textColor=FOREST, spaceAfter=1)
    s_kpi_l = ParagraphStyle("KL", parent=s_cell, fontSize=7.0, alignment=1, textColor=MUTED)
    s_disc = ParagraphStyle("DISC", parent=s_cell, fontSize=7.3, leading=10.0, textColor=MUTED)

    meta = result["meta"]
    m = result["measured_values"]
    d = result["derived_calculations"]
    p = result["backend_predictions"]
    obs = result["interpretive_observations"]
    prev = result.get("patient_history", {}).get("previous_visit")

    is_stressed = p["is_stressed"]
    is_critical = p["stress_probability"] >= 80.0
    verdict_bg = CRIMSON if is_critical else (TERRACOTTA if is_stressed else SAGE)
    verdict_tint = ALERT_TINT if is_stressed else SAGE_TINT
    w_full = A4[0] - 24 * mm  # ~527 pt (generous, balanced print width)
    story: List[Any] = []

    # ==================== PAGE 1: PATHOLOGY HEADER, ALERT, KPIs & VISUALS ====================
    banner = Table(
        [
            [Paragraph("NEUROPULSE AI  |  CLINICAL PATHOLOGY &amp; AUTONOMIC STRESS REPORT", s_ban_t)],
            [Paragraph(f"Local Biometric &amp; Psychometric Diagnostic Laboratory  |  Report Date: {_esc(meta['timestamp'])}  |  Status: Verified (Local)", s_ban_s)],
        ],
        colWidths=[w_full],
    )
    banner.setStyle(
        TableStyle(
            [
                ("BACKGROUND", (0, 0), (-1, -1), FOREST),
                ("LINEBELOW", (0, -1), (-1, -1), 3.0, TERRACOTTA),
                ("LEFTPADDING", (0, 0), (-1, -1), 12),
                ("RIGHTPADDING", (0, 0), (-1, -1), 12),
                ("TOPPADDING", (0, 0), (0, 0), 9),
                ("BOTTOMPADDING", (0, -1), (-1, -1), 8),
            ]
        )
    )
    story.append(banner)
    story.append(Spacer(1, 5))

    # Patient Identification & Verification Block
    v_sty = ParagraphStyle("VS", parent=s_cell_b, fontSize=9.0, alignment=1, textColor=colors.white)
    id_block = Table(
        [
            [
                Paragraph(f"<b>Patient Name / ID:</b> {_esc(m['participant_name'])}<br/><b>Patient Token:</b> {_esc(meta['anon_id'])}", s_cell),
                Paragraph(f"<b>Age / Gender:</b> {m['age']:.0f} yrs / {_esc(m['gender'])}<br/><b>Prior Local Visits:</b> {'1+ On File' if prev else 'First Recorded Visit'}", s_cell),
                Paragraph(f"<b>Test Date:</b> {_esc(meta['timestamp'][:10])}<br/><b>Verification:</b> Automated Local Pass", s_cell),
                Paragraph(f"<b>{_esc(p['verdict'])}</b><br/>{p['stress_probability']:.1f}% ({_esc(p['triage_severity'])})", v_sty),
            ]
        ],
        colWidths=[w_full * 0.25, w_full * 0.24, w_full * 0.23, w_full * 0.28],
    )
    id_block.setStyle(
        TableStyle(
            [
                ("BACKGROUND", (0, 0), (2, 0), IVORY),
                ("BACKGROUND", (3, 0), (3, 0), verdict_bg),
                ("BOX", (0, 0), (-1, -1), 0.7, BORDER),
                ("INNERGRID", (0, 0), (2, 0), 0.4, BORDER),
                ("VALIGN", (0, 0), (-1, -1), "MIDDLE"),
                ("PADDING", (0, 0), (-1, -1), 6.5),
            ]
        )
    )
    story.append(id_block)
    story.append(Spacer(1, 5))

    # Critical-Value Alert Banner (only when clinically elevated / critical)
    if is_critical:
        crit_sty = ParagraphStyle("CR", parent=s_cell, fontSize=8.0, textColor=CRIMSON)
        crit_bar = Table(
            [[Paragraph(
                f"<b>CRITICAL-VALUE ALERT:</b> Patient autonomic stress index reached <b>{p['stress_probability']:.1f}%</b> "
                f"(Peak HR {max(m['stroop_hr'], m['interview_hr'], m['hypervent_hr']):.0f} bpm during {_esc(d['peak_stressor_task'])}, "
                f"EDA {m['mean_eda']:.2f} uS, STAI-State {m['stai_state']:.0f}/80). Immediate parasympathetic recovery pacing is advised.",
                crit_sty,
            )]],
            colWidths=[w_full],
        )
        crit_bar.setStyle(
            TableStyle(
                [
                    ("BACKGROUND", (0, 0), (-1, -1), ALERT_TINT),
                    ("BOX", (0, 0), (-1, -1), 0.8, CRIMSON),
                    ("LINEBEFORE", (0, 0), (0, -1), 3.5, CRIMSON),
                    ("PADDING", (0, 0), (-1, -1), 6.5),
                ]
            )
        )
        story.append(crit_bar)
        story.append(Spacer(1, 5))

    # 4 Patient KPI Summary Cards
    peak_hr = max(m["stroop_hr"], m["interview_hr"], m["hypervent_hr"])
    kpi_tbl = Table(
        [
            [
                Paragraph(f"<b>{p['stress_probability']:.1f}%</b>", s_kpi_v),
                Paragraph(f"<b>{m['hr']:.0f} -> {peak_hr:.0f} bpm</b>", s_kpi_v),
                Paragraph(f"<b>{m['mean_eda']:.2f} uS / {m['skin_temp']:.1f} C</b>", s_kpi_v),
                Paragraph(f"<b>{m['pss_score']:.0f} / {m['stai_state']:.0f}</b>", s_kpi_v),
            ],
            [
                Paragraph("Patient Stress Index<br/>(Physiological Only: %.1f%%)" % p["wearable_only_probability"], s_kpi_l),
                Paragraph(f"Resting to Peak HR<br/>(Mean Delta: {d['mean_task_hr_delta']:+.1f} bpm)", s_kpi_l),
                Paragraph("Mean EDA / Skin Temp<br/>(Sympathetic Arousal)", s_kpi_l),
                Paragraph("PSS (0-40) / STAI-State<br/>(Psychological Load)", s_kpi_l),
            ],
        ],
        colWidths=[w_full / 4.0] * 4,
    )
    kpi_tbl.setStyle(
        TableStyle(
            [
                ("BACKGROUND", (0, 0), (-1, -1), verdict_tint),
                ("BOX", (0, 0), (-1, -1), 0.7, BORDER),
                ("INNERGRID", (0, 0), (-1, -1), 0.5, BORDER),
                ("TOPPADDING", (0, 0), (-1, 0), 6),
                ("BOTTOMPADDING", (0, 1), (-1, 1), 5.5),
                ("VALIGN", (0, 0), (-1, -1), "MIDDLE"),
            ]
        )
    )
    story.append(kpi_tbl)
    story.append(Spacer(1, 6))

    # Side-by-side HR Protocol & 6-Domain Autonomic Radar
    story.append(Paragraph("1. Executive Autonomic &amp; Cardiovascular Profile", s_h2))
    chart_row = Table(
        [[RLImage(_make_hr_chart(result), width=w_full * 0.52, height=156), RLImage(_make_radar_chart(result), width=w_full * 0.46, height=158)]],
        colWidths=[w_full * 0.53, w_full * 0.47],
    )
    chart_row.setStyle(TableStyle([("VALIGN", (0, 0), (-1, -1), "MIDDLE"), ("PADDING", (0, 0), (-1, -1), 2)]))
    story.append(chart_row)
    story.append(Spacer(1, 6))

    # Executive Patient Summary & Key Clinical Takeaways (fills Page 1 cleanly!)
    story.append(Paragraph("2. Executive Health Summary &amp; Patient-Specific Observations", s_h2))
    exec_bullets = [
        ("Overall Stress Determination", f"The patient's multimodal stress index is <b>{p['stress_probability']:.1f}%</b> ({_esc(p['triage_severity'])}), corroborated by a physiological-only reactivity score of <b>{p['wearable_only_probability']:.1f}%</b>."),
        ("Cardiovascular Reactivity", f"Resting heart rate measured <b>{m['hr']:.1f} bpm</b> and surged to <b>{peak_hr:.1f} bpm</b> during <b>{_esc(d['peak_stressor_task'])}</b> ({d['max_task_hr_delta']:+.1f} bpm; utilizing {d['hr_reserve_util_pct']:.1f}% of age-estimated heart-rate reserve)."),
        ("Ventilatory Acceleration", f"Respiratory rate increased from <b>{m['rr']:.1f} brpm</b> at rest to <b>{m['stress_rr']:.1f} brpm</b> under stress (delta of <b>{d['delta_rr']:+.1f} brpm</b> / {d['pct_rr']:+.1f}%)."),
        ("Sympathetic Electrodermal &amp; Thermal Coupling", f"Mean EDA recorded <b>{m['mean_eda']:.2f} uS</b> alongside peripheral skin temperature of <b>{m['skin_temp']:.2f} deg C</b> (EDA/Temp ratio: {d['eda_temp_ratio']:.4f} uS/C)."),
        ("Psychometric Assessment", f"PSS scored <b>{m['pss_score']:.0f}/40</b> ({_esc(d['pss_band'])}), STAI-State <b>{m['stai_state']:.0f}/80</b>, and STAI-Trait <b>{m['stai_trait']:.0f}/80</b> (acute State-Trait elevation: {d['stai_delta']:+.0f} pts)."),
    ]
    for lbl, txt in exec_bullets:
        story.append(Paragraph(f"*  <b>{lbl}:</b> {txt}", s_bul))

    story.append(Spacer(1, 5))
    # Quick Reference Legend Box at bottom of Page 1 (eliminates empty space & aids readability)
    leg_box = Table(
        [[Paragraph(
            "<b>Pathology Flag Legend:</b>  "
            "<font color='#4E6E58'><b>NORMAL</b></font> = Within standard clinical reference range  |  "
            "<font color='#B07A2A'><b>BORDERLINE</b></font> = Mildly elevated above resting norm  |  "
            "<font color='#A63A32'><b>HIGH * / LOW</b></font> = Clinically notable deviation requiring attention.",
            s_cell,
        )]],
        colWidths=[w_full],
    )
    leg_box.setStyle(
        TableStyle(
            [
                ("BACKGROUND", (0, 0), (-1, -1), BEIGE),
                ("BOX", (0, 0), (-1, -1), 0.6, BORDER),
                ("PADDING", (0, 0), (-1, -1), 7),
            ]
        )
    )
    story.append(leg_box)

    story.append(PageBreak())

    # ==================== PAGE 2: COMPLETE PATHOLOGY TABLE + ABNORMAL FINDINGS + TASK MATRIX ====================
    story.append(Paragraph("3. Complete Pathology Laboratory Panel (Patient Result vs. Reference Range)", s_h2))

    # (Test Name & Significance, Result, Unit, Normal Reference Range, Prev Value, Flag, Color)
    lab_specs = [
        ("Resting Heart Rate (HR)<br/><font size='6.4' color='#7E7268'>Baseline cardiovascular tone</font>", f"{m['hr']:.1f}", "bpm", "60.0 - 80.0", _fmt_prev(prev, "hr"), *_classify_flag(m["hr"], 60, 80, 90)),
        ("Stroop Test HR<br/><font size='6.4' color='#7E7268'>Cognitive stress reactivity</font>", f"{m['stroop_hr']:.1f}", "bpm", "65.0 - 88.0", _fmt_prev(prev, "stroop_hr"), *_classify_flag(m["stroop_hr"], 65, 88, 95)),
        ("Interview HR<br/><font size='6.4' color='#7E7268'>Social-evaluative stress response</font>", f"{m['interview_hr']:.1f}", "bpm", "70.0 - 92.0", _fmt_prev(prev, "interview_hr"), *_classify_flag(m["interview_hr"], 70, 92, 100)),
        ("Hyperventilation HR<br/><font size='6.4' color='#7E7268'>Autonomic respiratory load</font>", f"{m['hypervent_hr']:.1f}", "bpm", "68.0 - 90.0", _fmt_prev(prev, "hypervent_hr"), *_classify_flag(m["hypervent_hr"], 68, 90, 98)),
        ("Mean Task Delta HR<br/><font size='6.4' color='#7E7268'>Average sympathetic HR surge</font>", f"{d['mean_task_hr_delta']:+.1f}", "bpm", "0.0 - +12.0", "—", *_classify_flag(d["mean_task_hr_delta"], 0, 12, 16)),
        ("Resting Respiratory Rate (RR)<br/><font size='6.4' color='#7E7268'>Baseline ventilatory pace</font>", f"{m['rr']:.1f}", "brpm", "12.0 - 18.0", _fmt_prev(prev, "rr"), *_classify_flag(m["rr"], 12, 18, 20)),
        ("Stress Respiratory Rate<br/><font size='6.4' color='#7E7268'>Acute stress breathing pace</font>", f"{m['stress_rr']:.1f}", "brpm", "12.0 - 20.0", _fmt_prev(prev, "stress_rr"), *_classify_flag(m["stress_rr"], 12, 20, 23)),
        ("Mean Electrodermal Activity<br/><font size='6.4' color='#7E7268'>Sympathetic sweat-gland arousal</font>", f"{m['mean_eda']:.2f}", "uS", "0.30 - 2.50", _fmt_prev(prev, "mean_eda", ".2f"), *_classify_flag(m["mean_eda"], 0.30, 2.50, 3.20)),
        ("Peripheral Skin Temperature<br/><font size='6.4' color='#7E7268'>Vasoconstriction / thermal drop</font>", f"{m['skin_temp']:.2f}", "deg C", "32.80 - 35.00", _fmt_prev(prev, "skin_temp", ".2f"), *_classify_flag(m["skin_temp"], 32.80, 35.00, 36.50, low_is_bad=True)),
        ("Perceived Stress Scale (PSS)<br/><font size='6.4' color='#7E7268'>30-day subjective stress load</font>", f"{m['pss_score']:.0f}", "pts", "0 - 13 (Low)", _fmt_prev(prev, "pss_score", ".0f"), *_classify_flag(m["pss_score"], 0, 13, 26)),
        ("STAI-State Anxiety<br/><font size='6.4' color='#7E7268'>Current acute situational anxiety</font>", f"{m['stai_state']:.0f}", "pts", "20 - 37 (Low)", _fmt_prev(prev, "stai_state", ".0f"), *_classify_flag(m["stai_state"], 20, 37, 44)),
        ("STAI-Trait Anxiety<br/><font size='6.4' color='#7E7268'>Long-term anxiety disposition</font>", f"{m['stai_trait']:.0f}", "pts", "20 - 37 (Low)", _fmt_prev(prev, "stai_trait", ".0f"), *_classify_flag(m["stai_trait"], 20, 37, 44)),
        ("HR Reserve Utilization<br/><font size='6.4' color='#7E7268'>Interview surge vs age max HR</font>", f"{d['hr_reserve_util_pct']:.1f}", "%", "< 15.0%", "—", *_classify_flag(d["hr_reserve_util_pct"], 0, 15.0, 22.0)),
    ]

    lab_rows = [[
        Paragraph("Test / Parameter &amp; Significance", s_hdr),
        Paragraph("Patient Result", s_hdr),
        Paragraph("Unit", s_hdr),
        Paragraph("Normal Ref. Range", s_hdr),
        Paragraph("Previous", s_hdr),
        Paragraph("Status", s_hdr),
    ]]
    abnormal_notes: List[Tuple[str, str]] = []
    for name_html, val_s, unit_s, ref_s, prev_s, flag, fcol in lab_specs:
        fl_sty = ParagraphStyle("FL", parent=s_cell_b, textColor=colors.HexColor(fcol), alignment=1)
        val_sty = ParagraphStyle("VL", parent=s_cell_b, textColor=colors.HexColor(fcol) if flag != "NORMAL" else INK, alignment=1)
        lab_rows.append([
            Paragraph(name_html, s_cell_b),
            Paragraph(val_s, val_sty),
            Paragraph(unit_s, ParagraphStyle("UN", parent=s_cell, alignment=1)),
            Paragraph(ref_s, ParagraphStyle("RF", parent=s_cell, alignment=1)),
            Paragraph(prev_s, ParagraphStyle("PR", parent=s_cell, alignment=1)),
            Paragraph(flag, fl_sty),
        ])
        if flag != "NORMAL":
            clean_name = name_html.split("<br/>")[0]
            abnormal_notes.append((clean_name, f"{val_s} {unit_s} (Normal: {ref_s}) — {flag.replace(' *', '')}"))

    lab_table = Table(
        lab_rows,
        colWidths=[w_full * 0.34, w_full * 0.12, w_full * 0.08, w_full * 0.18, w_full * 0.13, w_full * 0.15],
        repeatRows=1,
    )
    lab_table.setStyle(
        TableStyle(
            [
                ("BACKGROUND", (0, 0), (-1, 0), FOREST),
                ("GRID", (0, 0), (-1, -1), 0.45, BORDER),
                ("VALIGN", (0, 0), (-1, -1), "MIDDLE"),
                ("ROWBACKGROUNDS", (0, 1), (-1, -1), [colors.white, IVORY]),
                ("PADDING", (0, 0), (-1, -1), 4.0),
            ]
        )
    )
    story.append(lab_table)
    story.append(Spacer(1, 7))

    # Detailed Explanations of Abnormal Findings (directly below table on Page 2!)
    story.append(Paragraph("4. Clinical Interpretation of Out-of-Range Findings", s_h2))
    if abnormal_notes:
        for cname, cdesc in abnormal_notes[:6]:
            story.append(Paragraph(f"*  <b>{_esc(cname)}:</b> {_esc(cdesc)} — indicates heightened autonomic or emotional load during the assessment.", s_bul))
    else:
        story.append(Paragraph("*  <b>All Biomarkers Within Normal Limits:</b> No abnormal physiological or psychometric elevations were detected on this visit.", s_bul))

    story.append(Spacer(1, 6))

    # Task-by-Task Reactivity Breakdown (completes Page 2 cleanly with zero bottom void!)
    story.append(Paragraph("5. Patient Task-by-Task Physiological Reactivity Breakdown", s_h2))

    def _tier(dv: float) -> str:
        return "High Surge" if dv >= 18 else ("Elevated" if dv >= 11 else ("Moderate" if dv >= 6 else "Calm / Mild"))

    task_rows = [
        [Paragraph("Protocol Phase", s_hdr), Paragraph("Stressor Type", s_hdr), Paragraph("Baseline", s_hdr), Paragraph("Patient Task", s_hdr), Paragraph("Change / % Surge", s_hdr), Paragraph("Reactivity", s_hdr)],
        [Paragraph("Stroop Test", s_cell_b), Paragraph("Cognitive Interference", s_cell), Paragraph(f"{m['hr']:.1f} bpm", s_cell), Paragraph(f"<b>{m['stroop_hr']:.1f} bpm</b>", s_cell), Paragraph(f"{d['delta_stroop_hr']:+.1f} bpm ({d['pct_stroop_hr']:+.1f}%)", s_cell), Paragraph(_tier(d["delta_stroop_hr"]), s_cell_b)],
        [Paragraph("Interview Phase", s_cell_b), Paragraph("Social-Evaluative", s_cell), Paragraph(f"{m['hr']:.1f} bpm", s_cell), Paragraph(f"<b>{m['interview_hr']:.1f} bpm</b>", s_cell), Paragraph(f"{d['delta_interview_hr']:+.1f} bpm ({d['pct_interview_hr']:+.1f}%)", s_cell), Paragraph(_tier(d["delta_interview_hr"]), s_cell_b)],
        [Paragraph("Hyperventilation", s_cell_b), Paragraph("Respiratory Load", s_cell), Paragraph(f"{m['hr']:.1f} bpm", s_cell), Paragraph(f"<b>{m['hypervent_hr']:.1f} bpm</b>", s_cell), Paragraph(f"{d['delta_hypervent_hr']:+.1f} bpm ({d['pct_hypervent_hr']:+.1f}%)", s_cell), Paragraph(_tier(d["delta_hypervent_hr"]), s_cell_b)],
        [Paragraph("Stress Breathing", s_cell_b), Paragraph("Ventilatory Shift", s_cell), Paragraph(f"{m['rr']:.1f} brpm", s_cell), Paragraph(f"<b>{m['stress_rr']:.1f} brpm</b>", s_cell), Paragraph(f"{d['delta_rr']:+.1f} brpm ({d['pct_rr']:+.1f}%)", s_cell), Paragraph("Elevated" if d["delta_rr"] >= 4.5 else "Normal Shift", s_cell_b)],
    ]
    t_tbl = Table(task_rows, colWidths=[w_full * 0.16, w_full * 0.18, w_full * 0.13, w_full * 0.15, w_full * 0.23, w_full * 0.15], repeatRows=1)
    t_tbl.setStyle(
        TableStyle(
            [
                ("BACKGROUND", (0, 0), (-1, 0), FOREST_MID),
                ("GRID", (0, 0), (-1, -1), 0.45, BORDER),
                ("VALIGN", (0, 0), (-1, -1), "MIDDLE"),
                ("ROWBACKGROUNDS", (0, 1), (-1, -1), [colors.white, IVORY]),
                ("PADDING", (0, 0), (-1, -1), 4.5),
            ]
        )
    )
    story.append(t_tbl)

    story.append(PageBreak())

    # ==================== PAGE 3: VISUAL GAUGES, TRENDS, RECOMMENDATIONS & CONCLUSION ====================
    story.append(Paragraph("6. Visual Pathology Reference Range Strip (Patient Biomarker Positions)", s_h2))
    story.append(RLImage(_make_gauge_strip(result), width=w_full, height=174))
    story.append(Spacer(1, 5))

    story.append(Paragraph("7. Breathing Shift &amp; Patient Trend / Psychological Cutoffs", s_h2))
    story.append(RLImage(_make_rr_psych_or_trend_chart(result), width=w_full, height=136))
    story.append(Spacer(1, 6))

    story.append(Paragraph("8. Clinically Appropriate Recommendations &amp; Personalized Recovery Plan", s_h2))
    rec_rows = [[Paragraph("Clinical Focus", s_hdr), Paragraph("Priority", s_hdr), Paragraph("Patient-Specific Action &amp; Guidance", s_hdr)]]
    for rec in obs["recommendations"]:
        rec_rows.append([Paragraph(_esc(rec["category"]), s_cell_b), Paragraph(_esc(rec["priority"]), s_cell_b), Paragraph(_esc(rec["detail"]), s_cell)])
    rec_tbl = Table(rec_rows, colWidths=[w_full * 0.24, w_full * 0.13, w_full * 0.63], repeatRows=1)
    rec_tbl.setStyle(
        TableStyle(
            [
                ("BACKGROUND", (0, 0), (-1, 0), SAGE),
                ("GRID", (0, 0), (-1, -1), 0.45, BORDER),
                ("VALIGN", (0, 0), (-1, -1), "TOP"),
                ("ROWBACKGROUNDS", (0, 1), (-1, -1), [colors.white, IVORY]),
                ("PADDING", (0, 0), (-1, -1), 4.6),
            ]
        )
    )
    story.append(rec_tbl)
    story.append(Spacer(1, 7))

    # Patient-Specific Conclusion + Verification Signature Strip + Medical Disclaimer
    conclusion_txt = (
        f"<b>Patient-Specific Conclusion:</b> {_esc(m['participant_name'])} demonstrates an overall stress index of "
        f"<b>{p['stress_probability']:.1f}% ({_esc(p['triage_severity'])})</b>, driven primarily by "
        f"{_esc(d['peak_stressor_task'])} cardiovascular reactivity ({d['max_task_hr_delta']:+.1f} bpm), "
        f"sympathetic EDA ({m['mean_eda']:.2f} uS), and psychometric stress markers (PSS {m['pss_score']:.0f}, STAI-State {m['stai_state']:.0f}). "
        "Follow the recovery guidance above and re-assess in 7-14 days to track personal progress."
    )
    conc_box = Table(
        [
            [Paragraph(conclusion_txt, s_cell)],
            [Paragraph(
                f"<b>MEDICAL DISCLAIMER &amp; VERIFICATION:</b> {_esc(obs['disclaimer'])} "
                f"Report verified locally on {_esc(meta['timestamp'])} | Patient Token: {_esc(meta['anon_id'])} | Strict Patient-Only Isolation Enforced.",
                s_disc,
            )],
        ],
        colWidths=[w_full],
    )
    conc_box.setStyle(
        TableStyle(
            [
                ("BACKGROUND", (0, 0), (0, 0), SAGE_TINT),
                ("BACKGROUND", (0, 1), (0, 1), BEIGE),
                ("BOX", (0, 0), (-1, -1), 0.7, BORDER),
                ("LINEBEFORE", (0, 0), (0, -1), 3.4, FOREST),
                ("PADDING", (0, 0), (-1, -1), 7.5),
            ]
        )
    )
    story.append(KeepTogether([conc_box]))

    doc.build(story, onFirstPage=_page_decor, onLaterPages=_page_decor)
    return buf.getvalue()
