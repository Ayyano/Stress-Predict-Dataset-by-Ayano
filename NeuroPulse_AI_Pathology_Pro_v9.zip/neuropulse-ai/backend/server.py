"""
NeuroPulse AI — Local FastAPI Backend Server (v9).
Enforces strict patient-level isolation, attaches ONLY the selected patient's
own prior assessments for pathology comparison, and disables static caching.
"""

from __future__ import annotations

import logging
import os
import re
from pathlib import Path
from typing import Any, Dict, Optional

from fastapi import FastAPI, HTTPException, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse, JSONResponse, Response
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel, Field

from .ml_engine import NeuroPulseEngine
from .pdf_report import generate_clinical_pdf_bytes
from .storage import LocalAssessmentStore

logging.basicConfig(level=logging.INFO, format="[NeuroPulse] %(asctime)s %(levelname)s: %(message)s")
logger = logging.getLogger("neuropulse")

ROOT_DIR = Path(__file__).resolve().parent.parent
FRONTEND_DIR = ROOT_DIR / "frontend"
LOCAL_DATA_DIR = Path(os.environ.get("NEUROPULSE_DATA_DIR", str(ROOT_DIR / "local_data")))
LOCAL_DATA_DIR.mkdir(parents=True, exist_ok=True)


class AssessmentRequest(BaseModel):
    participant_name: str = Field(..., min_length=1, max_length=120)
    age: float = Field(..., ge=5, le=120)
    gender: str = Field(..., min_length=1, max_length=40)
    pss_score: float = Field(..., ge=0, le=40)
    stai_state: float = Field(..., ge=20, le=80)
    stai_trait: float = Field(..., ge=20, le=80)
    hr: float = Field(..., ge=30, le=220)
    stroop_hr: float = Field(..., ge=30, le=240)
    interview_hr: float = Field(..., ge=30, le=240)
    hypervent_hr: float = Field(..., ge=30, le=240)
    rr: float = Field(..., ge=4, le=60)
    stress_rr: float = Field(..., ge=4, le=80)
    mean_eda: float = Field(..., ge=0.0, le=50.0)
    skin_temp: float = Field(..., ge=20.0, le=42.0)
    save_record: bool = True


class PdfRequest(BaseModel):
    result: Dict[str, Any]


app = FastAPI(
    title="NeuroPulse AI — Local Clinical Stress Sanctuary Backend",
    version="9.0.0",
    docs_url="/api/docs",
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=False,
    allow_methods=["*"],
    allow_headers=["*"],
)


@app.middleware("http")
async def disable_static_cache(request: Request, call_next):
    response = await call_next(request)
    if request.url.path == "/" or request.url.path.startswith("/static/"):
        response.headers["Cache-Control"] = "no-store, no-cache, must-revalidate, max-age=0"
        response.headers["Pragma"] = "no-cache"
    return response


engine = NeuroPulseEngine(data_dir=LOCAL_DATA_DIR / "dataset")
store = LocalAssessmentStore(db_path=LOCAL_DATA_DIR / "neuropulse_records.sqlite3")


@app.get("/api/health")
def health_check() -> Dict[str, Any]:
    return {
        "status": "ok",
        "version": "9.0.0-pathology-sanctuary",
        "app": "NeuroPulse AI — Autonomous Stress Monitoring System (ASMS)",
        "engine_mode": engine.engine_mode,
        "primary_model": engine.primary_model_name,
        "dataset_source": engine.dataset_source,
        "models_loaded": len(engine.models_full),
        "local_only": True,
    }


@app.post("/api/analyze")
def analyze(req: AssessmentRequest) -> JSONResponse:
    payload = req.model_dump() if hasattr(req, "model_dump") else req.dict()
    result = engine.analyze_participant(payload)

    # Fetch ONLY this patient's own previous visits BEFORE saving the new one
    prior_visits = store.get_patient_history(payload["participant_name"], limit=6)
    result["patient_history"] = {
        "previous_visit": prior_visits[0] if prior_visits else None,
        "prior_visits": prior_visits,
    }

    record_id: Optional[str] = None
    if req.save_record:
        record_id = store.save_assessment(payload, result)
        result["meta"]["record_id"] = record_id

    logger.info(
        "Completed local assessment | token=%s | prob=%.1f%% | prior_visits=%d | saved=%s",
        result["meta"]["anon_id"],
        result["backend_predictions"]["stress_probability"],
        len(prior_visits),
        bool(record_id),
    )
    return JSONResponse(content=result)


@app.post("/api/report/pdf")
def export_pdf(req: PdfRequest) -> Response:
    try:
        pdf_bytes = generate_clinical_pdf_bytes(req.result)
    except Exception as exc:
        logger.exception("PDF generation failed")
        raise HTTPException(status_code=500, detail=f"PDF generation error: {exc}")

    anon_id = str(req.result.get("meta", {}).get("anon_id", "Patient"))
    safe_id = re.sub(r"[^A-Za-z0-9_-]", "_", anon_id)
    filename = f"NeuroPulse_Pathology_Report_{safe_id}.pdf"
    return Response(
        content=pdf_bytes,
        media_type="application/pdf",
        headers={"Content-Disposition": f'attachment; filename="{filename}"'},
    )


@app.get("/api/records")
def list_records() -> Dict[str, Any]:
    return {"records": store.list_assessments(limit=100)}


@app.get("/api/records/{record_id}")
def get_record(record_id: str) -> Dict[str, Any]:
    rec = store.get_assessment(record_id)
    if rec is None:
        raise HTTPException(status_code=404, detail="Assessment record not found")
    # Ensure patient_history is populated strictly for this patient
    pname = rec["result"]["measured_values"]["participant_name"]
    prior_visits = store.get_patient_history(pname, exclude_id=record_id, limit=6)
    rec["result"]["patient_history"] = {
        "previous_visit": prior_visits[0] if prior_visits else None,
        "prior_visits": prior_visits,
    }
    return rec


@app.delete("/api/records/{record_id}")
def delete_record(record_id: str) -> Dict[str, Any]:
    deleted = store.delete_assessment(record_id)
    if not deleted:
        raise HTTPException(status_code=404, detail="Assessment record not found")
    return {"deleted": True, "id": record_id}


if FRONTEND_DIR.exists():
    app.mount("/static", StaticFiles(directory=str(FRONTEND_DIR)), name="static")


@app.get("/")
def serve_index():
    index_file = FRONTEND_DIR / "index.html"
    if not index_file.exists():
        return JSONResponse({"message": "NeuroPulse AI Backend Running. Frontend not found."}, status_code=200)
    return FileResponse(str(index_file))


def main() -> None:
    import uvicorn

    host = os.environ.get("NEUROPULSE_HOST", "127.0.0.1")
    port = int(os.environ.get("NEUROPULSE_PORT", "8765"))
    logger.info("Starting NeuroPulse AI Clinical Sanctuary v9 on http://%s:%d", host, port)
    uvicorn.run(app, host=host, port=port, log_level="warning")


if __name__ == "__main__":
    main()
