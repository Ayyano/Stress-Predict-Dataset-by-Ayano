/**
 * NeuroPulse AI — Main Frontend Controller
 * Handles Welcome -> 14-Step Guided Questionnaire -> Completion/Review ->
 * Analytical Results Dashboard -> Interactive Live Report -> PDF Export -> Local Records.
 */

const DRAFT_KEY = "neuropulse_ai_draft_v1";

const QUESTIONS = [
  {
    key: "participant_name",
    num: "01",
    category: "Participant Identification",
    title: "What is the participant's name or ID?",
    fullForm: "Participant Name / Anonymous Research Identifier",
    explanation: "Enter the participant's full name or an assigned anonymous research identification code (for example, S001 or SUBJ-204).",
    why: "This information helps identify and organize individual assessment records locally without requiring personally identifiable details.",
    instructions: "You may enter either a real name or an anonymous participant ID according to your research privacy protocol.",
    type: "text",
    placeholder: "e.g., S001 or Alex Morgan",
    unit: "",
    validate: (v) => (String(v || "").trim().length >= 1 ? null : "Please enter a participant name or anonymous ID."),
  },
  {
    key: "age",
    num: "02",
    category: "Demographic Context",
    title: "What is the participant's age?",
    fullForm: "Age (Completed Years)",
    explanation: "Enter the participant's age in completed years.",
    why: "Age provides essential physiological context because baseline heart rate and maximum heart-rate reserve vary significantly across age cohorts.",
    instructions: "Enter a numeric age between 6 and 110 years.",
    type: "number",
    step: "1",
    min: 6,
    max: 110,
    placeholder: "e.g., 28",
    unit: "years",
    validate: (v) => validateRange(v, 6, 110, "Age must be between 6 and 110 years."),
  },
  {
    key: "gender",
    num: "03",
    category: "Demographic Context",
    title: "Select the participant's gender",
    fullForm: "Gender Category",
    explanation: "Select the participant's gender category according to your research protocol.",
    why: "Used for demographic cohort alignment and physiological baseline organization.",
    instructions: "Choose one of the four protocol categories below.",
    type: "select",
    options: ["Male", "Female", "Other", "Prefer not to say"],
    validate: (v) => (v ? null : "Please select a gender option to continue."),
  },
  {
    key: "pss_score",
    num: "04",
    category: "Psychological Assessment",
    title: "Enter the Perceived Stress Scale (PSS) score",
    fullForm: "Perceived Stress Scale (PSS-10 · Range 0–40)",
    explanation: "The Perceived Stress Scale measures how frequently individuals perceive situations in their lives as stressful, unpredictable, or overwhelming.",
    why: "Provides standardized insight into the participant's perceived psychological stress level.",
    instructions: "Enter the total scored PSS value (0–40) from the completed questionnaire. Do not guess the score.",
    type: "number",
    step: "1",
    min: 0,
    max: 40,
    placeholder: "0 – 40",
    unit: "pts (0–40)",
    validate: (v) => validateRange(v, 0, 40, "PSS score must be between 0 and 40."),
  },
  {
    key: "stai_state",
    num: "05",
    category: "Psychological Assessment",
    title: "Enter the STAI-State Anxiety score",
    fullForm: "State-Trait Anxiety Inventory – State Anxiety (Range 20–80)",
    explanation: "State anxiety measures how anxious a person feels at a particular moment or during a specific assessment situation.",
    why: "Captures acute, moment-to-moment anxiety levels during the stress protocol.",
    instructions: "Enter the total scored State Anxiety value (20–80) from the completed STAI-State form.",
    type: "number",
    step: "1",
    min: 20,
    max: 80,
    placeholder: "20 – 80",
    unit: "pts (20–80)",
    validate: (v) => validateRange(v, 20, 80, "STAI-State score must be between 20 and 80."),
  },
  {
    key: "stai_trait",
    num: "06",
    category: "Psychological Assessment",
    title: "Enter the STAI-Trait Anxiety score",
    fullForm: "State-Trait Anxiety Inventory – Trait Anxiety (Range 20–80)",
    explanation: "Trait anxiety measures a person's general tendency to experience anxiety across different situations over time.",
    why: "Distinguishes baseline emotional disposition from acute situational reactivity (STAI-State minus STAI-Trait).",
    instructions: "Enter the total scored Trait Anxiety value (20–80) from the completed STAI-Trait form.",
    type: "number",
    step: "1",
    min: 20,
    max: 80,
    placeholder: "20 – 80",
    unit: "pts (20–80)",
    validate: (v) => validateRange(v, 20, 80, "STAI-Trait score must be between 20 and 80."),
  },
  {
    key: "hr",
    num: "07",
    category: "Cardiovascular Baseline",
    title: "Enter Baseline Heart Rate (HR)",
    fullForm: "Heart Rate (Resting / Baseline)",
    explanation: "Heart rate represents the number of times the heart beats in one minute at rest.",
    why: "Serves as the participant's personal cardiovascular anchor for computing age-invariant stress deltas across tasks.",
    instructions: "Enter the baseline or resting heart rate measurement in beats per minute (bpm).",
    type: "number",
    step: "0.1",
    min: 35,
    max: 190,
    placeholder: "e.g., 72.0",
    unit: "bpm",
    validate: (v) => validateRange(v, 35, 190, "Heart Rate must be between 35 and 190 bpm."),
  },
  {
    key: "stroop_hr",
    num: "08",
    category: "Task-Based Cardiovascular Reactivity",
    title: "Enter Heart Rate During the Stroop Test",
    fullForm: "Heart Rate During Stroop Color-Word Interference Test",
    explanation: "Represents the participant's heart rate during the Stroop Test, a cognitive task involving attention, processing speed, and interference control.",
    why: "Examines sympathetic cardiovascular reactivity under acute cognitive demand.",
    instructions: "Enter the recorded heart rate during the Stroop Test phase in bpm.",
    type: "number",
    step: "0.1",
    min: 40,
    max: 220,
    placeholder: "e.g., 83.5",
    unit: "bpm",
    validate: (v) => validateRange(v, 40, 220, "Stroop HR must be between 40 and 220 bpm."),
  },
  {
    key: "interview_hr",
    num: "09",
    category: "Task-Based Cardiovascular Reactivity",
    title: "Enter Heart Rate During the Interview",
    fullForm: "Heart Rate During Evaluative Interview Task",
    explanation: "Represents the participant's heart rate during a structured interview or socially evaluative task.",
    why: "Examines cardiovascular responses during social-evaluative stress, often the strongest autonomic stressor.",
    instructions: "Enter the recorded heart rate during the interview phase in bpm.",
    type: "number",
    step: "0.1",
    min: 40,
    max: 220,
    placeholder: "e.g., 91.0",
    unit: "bpm",
    validate: (v) => validateRange(v, 40, 220, "Interview HR must be between 40 and 220 bpm."),
  },
  {
    key: "hypervent_hr",
    num: "10",
    category: "Task-Based Cardiovascular Reactivity",
    title: "Enter Heart Rate During Hyperventilation",
    fullForm: "Heart Rate During Hyperventilation Challenge",
    explanation: "Represents the heart rate recorded during the controlled hyperventilation phase of the research protocol.",
    why: "Evaluates autonomic cardiovascular coupling under an acute respiratory challenge.",
    instructions: "Enter the recorded heart rate during the hyperventilation phase in bpm.",
    type: "number",
    step: "0.1",
    min: 40,
    max: 220,
    placeholder: "e.g., 87.0",
    unit: "bpm",
    validate: (v) => validateRange(v, 40, 220, "Hyperventilation HR must be between 40 and 220 bpm."),
  },
  {
    key: "rr",
    num: "11",
    category: "Respiratory Activity",
    title: "Enter Baseline Respiratory Rate (RR)",
    fullForm: "Respiratory Rate (Resting / Baseline)",
    explanation: "Respiratory rate represents the number of breaths a person takes in one minute at rest.",
    why: "Establishes the participant's normal ventilatory baseline before stress induction.",
    instructions: "Enter the baseline respiratory rate in breaths per minute (brpm).",
    type: "number",
    step: "0.1",
    min: 6,
    max: 45,
    placeholder: "e.g., 15.0",
    unit: "brpm",
    validate: (v) => validateRange(v, 6, 45, "Baseline RR must be between 6 and 45 brpm."),
  },
  {
    key: "stress_rr",
    num: "12",
    category: "Respiratory Activity",
    title: "Enter Stress Respiratory Rate",
    fullForm: "Respiratory Rate Under Stress Protocol",
    explanation: "Represents the participant's respiratory rate recorded during the stress-induction phase.",
    why: "Measures ventilatory acceleration (ΔRR), a key autonomic marker paired with HR reactivity in the ML engine.",
    instructions: "Enter the stress-phase respiratory rate in breaths per minute (brpm).",
    type: "number",
    step: "0.1",
    min: 6,
    max: 65,
    placeholder: "e.g., 21.5",
    unit: "brpm",
    validate: (v) => validateRange(v, 6, 65, "Stress Respiratory Rate must be between 6 and 65 brpm."),
  },
  {
    key: "mean_eda",
    num: "13",
    category: "Autonomic Electrodermal Signal",
    title: "Enter Mean Electrodermal Activity (EDA)",
    fullForm: "Mean Electrodermal Activity (Skin Conductance in μS)",
    explanation: "Electrodermal activity measures tiny changes in electrical skin conductance driven by sympathetic sweat-gland activation.",
    why: "EDA is one of the purest non-invasive indicators of sympathetic nervous system arousal.",
    instructions: "Enter the mean EDA measurement in microsiemens (μS), typically between 0.2 and 15.0 μS.",
    type: "number",
    step: "0.01",
    min: 0.05,
    max: 30,
    placeholder: "e.g., 3.85",
    unit: "μS",
    validate: (v) => validateRange(v, 0.05, 30, "Mean EDA must be between 0.05 and 30 μS."),
  },
  {
    key: "skin_temp",
    num: "14",
    category: "Autonomic Thermal Signal",
    title: "Enter Peripheral Skin Temperature",
    fullForm: "Peripheral Skin Temperature (°C)",
    explanation: "Skin temperature reflects peripheral blood flow; acute sympathetic stress often causes peripheral vasoconstriction and slight cooling.",
    why: "Combines with EDA (EDA/Temp ratio) to strengthen autonomic stress classification.",
    instructions: "Enter the recorded peripheral skin temperature in degrees Celsius (°C), typically 28.0–38.0 °C.",
    type: "number",
    step: "0.05",
    min: 24,
    max: 41,
    placeholder: "e.g., 32.5",
    unit: "°C",
    validate: (v) => validateRange(v, 24, 41, "Skin Temperature must be between 24 and 41 °C."),
  },
];

function validateRange(val, min, max, msg) {
  if (val === "" || val === null || val === undefined) return "This field is required.";
  const n = Number(val);
  if (Number.isNaN(n) || n < min || n > max) return msg;
  return null;
}

const state = {
  step: 0,
  answers: {},
  lastResult: null,
  previousView: "viewWelcome",
};

const $ = (id) => document.getElementById(id);

function showView(viewId) {
  document.querySelectorAll(".view").forEach((v) => v.classList.remove("active"));
  const target = $(viewId);
  if (target) target.classList.add("active");
  window.scrollTo({ top: 0, behavior: "smooth" });
}

function showToast(msg) {
  const t = $("toast");
  t.textContent = msg;
  t.classList.add("show");
  clearTimeout(window._toastTimer);
  window._toastTimer = setTimeout(() => t.classList.remove("show"), 3200);
}

function setLoading(show, title = "Running Local Stress Analysis...", sub = "Computing 23 baseline-delta features & ensemble consensus") {
  $("loadingTitle").textContent = title;
  $("loadingSub").textContent = sub;
  $("loadingOverlay").classList.toggle("show", show);
}

function saveDraft() {
  try {
    localStorage.setItem(DRAFT_KEY, JSON.stringify({ step: state.step, answers: state.answers }));
  } catch (_) {}
}

function loadDraft() {
  try {
    const raw = localStorage.getItem(DRAFT_KEY);
    if (!raw) return false;
    const parsed = JSON.parse(raw);
    if (parsed && parsed.answers && Object.keys(parsed.answers).length > 0) {
      state.answers = parsed.answers;
      state.step = Math.min(QUESTIONS.length - 1, Math.max(0, Number(parsed.step) || 0));
      return true;
    }
  } catch (_) {}
  return false;
}

/* ==================== BACKEND HEALTH CHECK ==================== */
async function checkBackendHealth() {
  const pill = $("backendStatusPill");
  const txt = $("backendStatusText");
  try {
    const res = await fetch("/api/health");
    if (!res.ok) throw new Error("Offline");
    const data = await res.json();
    pill.classList.add("online");
    txt.textContent = `Local Engine Ready (${data.models_loaded} Models)`;
  } catch (_) {
    pill.classList.remove("online");
    txt.textContent = "Backend Offline — Start Local Server";
  }
}

/* ==================== QUESTIONNAIRE RENDERER ==================== */
function renderQuestion() {
  const q = QUESTIONS[state.step];
  const pct = ((state.step + 1) / QUESTIONS.length) * 100;

  $("qStepBadge").textContent = `QUESTION ${q.num} / 14`;
  $("qCategory").textContent = q.category;
  $("qProgressFill").style.width = `${pct}%`;
  $("qNumLabel").textContent = `QUESTION ${q.num}`;
  $("qTitle").textContent = q.title;
  $("qFullForm").textContent = `Full Form: ${q.fullForm}`;
  $("qExplanation").textContent = q.explanation;
  $("qWhy").textContent = q.why;
  $("qInstructions").textContent = q.instructions;
  $("qError").textContent = "";

  $("btnPrev").style.visibility = state.step === 0 ? "hidden" : "visible";
  $("btnNextText").textContent = state.step === QUESTIONS.length - 1 ? "COMPLETE ASSESSMENT" : "CONTINUE";

  const area = $("qInputArea");
  area.innerHTML = "";
  const curVal = state.answers[q.key] ?? "";

  if (q.type === "select") {
    const grid = document.createElement("div");
    grid.className = "choice-grid";
    q.options.forEach((opt) => {
      const btn = document.createElement("button");
      btn.type = "button";
      btn.className = "choice-btn" + (curVal === opt ? " selected" : "");
      btn.textContent = opt;
      btn.addEventListener("click", () => {
        state.answers[q.key] = opt;
        saveDraft();
        grid.querySelectorAll(".choice-btn").forEach((b) => b.classList.remove("selected"));
        btn.classList.add("selected");
        $("qError").textContent = "";
        window.neuroAudio.playStepChime(520);
      });
      grid.appendChild(btn);
    });
    area.appendChild(grid);
  } else {
    const wrap = document.createElement("div");
    wrap.className = "input-wrap";
    const inp = document.createElement("input");
    inp.className = "q-input";
    inp.id = "activeQuestionInput";
    inp.type = q.type;
    if (q.step) inp.step = q.step;
    if (q.min !== undefined) inp.min = q.min;
    if (q.max !== undefined) inp.max = q.max;
    inp.placeholder = q.placeholder || "";
    inp.value = curVal;
    inp.addEventListener("input", () => {
      state.answers[q.key] = inp.value;
      saveDraft();
      $("qError").textContent = "";
    });
    inp.addEventListener("keydown", (e) => {
      if (e.key === "Enter") {
        e.preventDefault();
        handleNext();
      }
    });
    wrap.appendChild(inp);

    if (q.unit) {
      const u = document.createElement("span");
      u.className = "q-unit";
      u.textContent = q.unit;
      wrap.appendChild(u);
    }
    area.appendChild(wrap);
    setTimeout(() => inp.focus(), 60);
  }
}

function handleNext() {
  const q = QUESTIONS[state.step];
  const val = state.answers[q.key];
  const err = q.validate(val);
  if (err) {
    $("qError").textContent = err;
    return;
  }
  window.neuroAudio.playStepChime(480 + state.step * 18);
  if (state.step < QUESTIONS.length - 1) {
    state.step += 1;
    saveDraft();
    renderQuestion();
  } else {
    renderReviewGrid();
    showView("viewReview");
  }
}

function handlePrev() {
  if (state.step > 0) {
    state.step -= 1;
    saveDraft();
    renderQuestion();
    window.neuroAudio.playStepChime(390);
  }
}

function renderReviewGrid() {
  const grid = $("reviewGrid");
  grid.innerHTML = "";
  QUESTIONS.forEach((q, idx) => {
    const item = document.createElement("div");
    item.className = "review-item";
    const raw = state.answers[q.key] ?? "—";
    const unit = q.unit ? ` ${q.unit.split(" ")[0]}` : "";
    item.innerHTML = `
      <div class="review-item-lbl">${q.num} · ${q.category}</div>
      <div class="review-item-val">${escapeHtml(String(raw))}${q.type === "number" ? unit : ""}</div>
      <div class="review-item-edit">Click to edit</div>
    `;
    item.addEventListener("click", () => {
      state.step = idx;
      renderQuestion();
      showView("viewQuestionnaire");
    });
    grid.appendChild(item);
  });
}

/* ==================== BACKEND ANALYSIS ==================== */
async function runBackendAnalysis() {
  for (let i = 0; i < QUESTIONS.length; i++) {
    const q = QUESTIONS[i];
    const err = q.validate(state.answers[q.key]);
    if (err) {
      state.step = i;
      renderQuestion();
      showView("viewQuestionnaire");
      $("qError").textContent = err;
      return;
    }
  }

  const payload = {
    participant_name: String(state.answers.participant_name).trim(),
    age: Number(state.answers.age),
    gender: String(state.answers.gender),
    pss_score: Number(state.answers.pss_score),
    stai_state: Number(state.answers.stai_state),
    stai_trait: Number(state.answers.stai_trait),
    hr: Number(state.answers.hr),
    stroop_hr: Number(state.answers.stroop_hr),
    interview_hr: Number(state.answers.interview_hr),
    hypervent_hr: Number(state.answers.hypervent_hr),
    rr: Number(state.answers.rr),
    stress_rr: Number(state.answers.stress_rr),
    mean_eda: Number(state.answers.mean_eda),
    skin_temp: Number(state.answers.skin_temp),
    save_record: true,
  };

  setLoading(true);
  try {
    const res = await fetch("/api/analyze", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(payload),
    });
    if (!res.ok) {
      const errJson = await res.json().catch(() => ({}));
      throw new Error(errJson.detail || `HTTP ${res.status}`);
    }
    const result = await res.json();
    state.lastResult = result;
    localStorage.removeItem(DRAFT_KEY);
    renderResultsDashboard(result);
    showView("viewResults");
    window.neuroAudio.playStepChime(660);
    showToast("Local stress analysis complete & saved.");
  } catch (err) {
    showToast(`Analysis error: ${err.message}`);
  } finally {
    setLoading(false);
  }
}

/* ==================== RESULTS DASHBOARD RENDERER ==================== */
function renderResultsDashboard(res) {
  const m = res.measured_values;
  const d = res.derived_calculations;
  const p = res.backend_predictions;
  const coh = res.cohort_comparison;
  const obs = res.interpretive_observations;

  $("resParticipantHeading").textContent = `${m.participant_name} — Autonomous Stress Analysis`;
  $("resMetaLine").textContent = `Cohort: ${res.meta.cohort} · Token: ${res.meta.anon_id} · Engine: ${res.meta.primary_model} · ${res.meta.timestamp}`;

  const vCard = $("kpiVerdictCard");
  vCard.classList.remove("stressed", "normal");
  vCard.classList.add(p.is_stressed ? "stressed" : "normal");
  $("kpiVerdictText").textContent = `${p.verdict} (${p.stress_probability.toFixed(1)}%)`;
  $("kpiVerdictSub").textContent = `${p.triage_severity} · Wearable-Only: ${p.wearable_only_probability.toFixed(1)}%`;

  $("kpiMeanHrDelta").textContent = `${d.mean_task_hr_delta >= 0 ? "+" : ""}${d.mean_task_hr_delta.toFixed(1)} bpm`;
  $("kpiPeakTask").textContent = `Peak Stressor: ${d.peak_stressor_task} (${d.max_task_hr_delta >= 0 ? "+" : ""}${d.max_task_hr_delta.toFixed(1)} bpm)`;

  $("kpiEdaTemp").textContent = `${m.mean_eda.toFixed(2)} μS · ${m.skin_temp.toFixed(1)} °C`;
  $("kpiEdaRatio").textContent = `EDA/Temp Ratio: ${d.eda_temp_ratio.toFixed(4)} μS/°C`;

  $("kpiPsychScores").textContent = `PSS ${m.pss_score} · STAI-S ${m.stai_state}`;
  $("kpiStaiDelta").textContent = `STAI-Trait: ${m.stai_trait} (Δ ${d.stai_delta >= 0 ? "+" : ""}${d.stai_delta})`;

  // Charts
  const nb = coh.normal_baselines;
  window.NeuroCharts.drawGroupedBar(
    "chartHrCompare",
    ["Resting", "Stroop", "Interview", "Hypervent."],
    [m.hr, m.stroop_hr, m.interview_hr, m.hypervent_hr],
    [nb.HR || 72, nb["Stroop HR (bpm)"] || 78.5, nb["Interview HR (bpm)"] || 83.5, nb["Hyperventilation HR (bpm)"] || 81],
    "bpm",
    "#00E5FF"
  );

  window.NeuroCharts.drawRadar("chartRadar", coh.radar_profile, p.is_stressed);

  window.NeuroCharts.drawGroupedBar(
    "chartRrCompare",
    ["Resting RR", "Stress RR"],
    [m.rr, m.stress_rr],
    [nb.RR || 15.2, nb["Stress Resp Rate (brpm)"] || 18.8],
    "brpm",
    "#14B8A6"
  );

  window.NeuroCharts.drawModelConsensus("chartModelConsensus", p.per_model_predictions);

  // Matrix Table
  const tbody = $("resMatrixTable").querySelector("tbody");
  tbody.innerHTML = "";
  coh.biometric_matrix.forEach((row) => {
    const low = row.status.toLowerCase();
    const cls = low.includes("high") || low.includes("elevated") || low.includes("cool")
      ? "badge-high"
      : low.includes("moderate") ? "badge-mod" : "badge-ok";
    const tr = document.createElement("tr");
    tr.innerHTML = `
      <td><strong>${escapeHtml(row.parameter)}</strong></td>
      <td>${escapeHtml(row.measured)}</td>
      <td>${escapeHtml(row.baseline)}</td>
      <td>${escapeHtml(row.deviation)}</td>
      <td><span class="badge-status ${cls}">${escapeHtml(row.status)}</span></td>
    `;
    tbody.appendChild(tr);
  });

  // Observations & Action Plan
  const obsList = $("resObservations");
  obsList.innerHTML = obs.summary_points.map((pt) => `<li>${escapeHtml(pt)}</li>`).join("");

  const recWrap = $("resRecommendations");
  recWrap.innerHTML = obs.recommendations
    .map(
      (r) => `
      <div class="rec-card">
        <div class="rec-card-head">
          <span>${escapeHtml(r.category)}</span>
          <span style="color: var(--cyan)">${escapeHtml(r.priority)}</span>
        </div>
        <p>${escapeHtml(r.detail)}</p>
      </div>`
    )
    .join("");

  $("resDisclaimer").textContent = obs.disclaimer;
}

/* ==================== INTERACTIVE LIVE REPORT ==================== */
function renderLiveReport(res) {
  const m = res.measured_values;
  const d = res.derived_calculations;
  const p = res.backend_predictions;
  const obs = res.interpretive_observations;

  $("liveReportBody").innerHTML = `
    <div class="lr-section">
      <h3>1. Executive Summary &amp; Backend Verdict</h3>
      <div class="lr-kv-grid">
        <div class="lr-kv"><span>Participant / ID</span><strong>${escapeHtml(m.participant_name)} (${escapeHtml(res.meta.anon_id)})</strong></div>
        <div class="lr-kv"><span>Age / Gender / Cohort</span><strong>${m.age} yrs · ${escapeHtml(m.gender)} · ${escapeHtml(res.meta.cohort)}</strong></div>
        <div class="lr-kv"><span>Backend ML Verdict</span><strong>${escapeHtml(p.verdict)} (${p.stress_probability.toFixed(1)}%)</strong></div>
        <div class="lr-kv"><span>Wearable-Only Track</span><strong>${p.wearable_only_probability.toFixed(1)}%</strong></div>
        <div class="lr-kv"><span>Triage Tier</span><strong>${escapeHtml(p.triage_severity)}</strong></div>
        <div class="lr-kv"><span>Primary Model</span><strong>${escapeHtml(res.meta.primary_model)}</strong></div>
      </div>
    </div>

    <div class="lr-section">
      <h3>2. Complete Measured Inputs (14 Protocol Parameters)</h3>
      <div class="lr-kv-grid">
        <div class="lr-kv"><span>PSS Score (0–40)</span><strong>${m.pss_score} (${escapeHtml(d.pss_band)})</strong></div>
        <div class="lr-kv"><span>STAI-State (20–80)</span><strong>${m.stai_state} (${escapeHtml(d.stai_state_band)})</strong></div>
        <div class="lr-kv"><span>STAI-Trait (20–80)</span><strong>${m.stai_trait} (${escapeHtml(d.stai_trait_band)})</strong></div>
        <div class="lr-kv"><span>Resting HR</span><strong>${m.hr} bpm</strong></div>
        <div class="lr-kv"><span>Stroop HR</span><strong>${m.stroop_hr} bpm (Δ ${d.delta_stroop_hr >= 0 ? "+" : ""}${d.delta_stroop_hr})</strong></div>
        <div class="lr-kv"><span>Interview HR</span><strong>${m.interview_hr} bpm (Δ ${d.delta_interview_hr >= 0 ? "+" : ""}${d.delta_interview_hr})</strong></div>
        <div class="lr-kv"><span>Hyperventilation HR</span><strong>${m.hypervent_hr} bpm (Δ ${d.delta_hypervent_hr >= 0 ? "+" : ""}${d.delta_hypervent_hr})</strong></div>
        <div class="lr-kv"><span>Resting RR → Stress RR</span><strong>${m.rr} → ${m.stress_rr} brpm (Δ ${d.delta_rr >= 0 ? "+" : ""}${d.delta_rr})</strong></div>
        <div class="lr-kv"><span>Mean EDA</span><strong>${m.mean_eda} μS</strong></div>
        <div class="lr-kv"><span>Peripheral Skin Temp</span><strong>${m.skin_temp} °C</strong></div>
      </div>
    </div>

    <div class="lr-section">
      <h3>3. Interpretive Analytical Observations</h3>
      <ul class="obs-list">${obs.summary_points.map((pt) => `<li>${escapeHtml(pt)}</li>`).join("")}</ul>
    </div>

    <div class="lr-section">
      <h3>4. Local Autonomous Pipeline Audit</h3>
      <div class="lr-kv-grid">
        ${obs.crew_audit
          .map(
            (c) => `<div class="lr-kv"><span>${escapeHtml(c.agent)} [${escapeHtml(c.status)}]</span><strong style="font-size:0.84rem;font-weight:500;">${escapeHtml(c.detail)}</strong></div>`
          )
          .join("")}
      </div>
    </div>

    <div class="lr-section">
      <h3>5. Research Methodology &amp; Disclaimer</h3>
      <p style="color:var(--text-soft);font-size:0.88rem;">${escapeHtml(obs.disclaimer)}</p>
    </div>
  `;
}

/* ==================== PDF EXPORT (ELECTRON SAVE-AS OR BROWSER DOWNLOAD) ==================== */
async function downloadPdfReport() {
  if (!state.lastResult) return;
  setLoading(true, "Generating Research PDF Report...", "Compiling Matplotlib clinical charts & ReportLab pages");
  try {
    const res = await fetch("/api/report/pdf", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ result: state.lastResult }),
    });
    if (!res.ok) throw new Error(`HTTP ${res.status}`);
    const arrayBuf = await res.arrayBuffer();
    const defaultName = `NeuroPulse_AI_Report_${state.lastResult.meta.anon_id}.pdf`;

    if (window.neuroPulseDesktop && typeof window.neuroPulseDesktop.savePdfBytes === "function") {
      const saved = await window.neuroPulseDesktop.savePdfBytes(Array.from(new Uint8Array(arrayBuf)), defaultName);
      if (saved && saved.saved) {
        showToast(`PDF saved to: ${saved.filePath}`);
      } else {
        showToast("PDF save canceled.");
      }
    } else {
      const blob = new Blob([arrayBuf], { type: "application/pdf" });
      const url = URL.createObjectURL(blob);
      const a = document.createElement("a");
      a.href = url;
      a.download = defaultName;
      document.body.appendChild(a);
      a.click();
      a.remove();
      setTimeout(() => URL.revokeObjectURL(url), 5000);
      showToast(`PDF report downloaded (${defaultName}).`);
    }
  } catch (err) {
    showToast(`PDF export failed: ${err.message}`);
  } finally {
    setLoading(false);
  }
}

/* ==================== LOCAL RECORDS MANAGER ==================== */
async function openRecordsManager() {
  try {
    const res = await fetch("/api/records");
    const data = await res.json();
    const tbody = $("recordsTable").querySelector("tbody");
    tbody.innerHTML = "";
    if (!data.records || data.records.length === 0) {
      tbody.innerHTML = `<tr><td colspan="7" style="text-align:center;padding:24px;color:var(--text-muted);">No local assessment records saved yet.</td></tr>`;
    } else {
      data.records.forEach((rec) => {
        const tr = document.createElement("tr");
        tr.innerHTML = `
          <td>${escapeHtml(rec.created_at)}</td>
          <td><strong>${escapeHtml(rec.participant_name)}</strong></td>
          <td>${escapeHtml(rec.anon_id)}</td>
          <td>${rec.age} / ${escapeHtml(rec.gender)}</td>
          <td><span class="badge-status ${rec.stress_probability >= 50 ? "badge-high" : "badge-ok"}">${escapeHtml(rec.verdict)}</span></td>
          <td><strong>${Number(rec.stress_probability).toFixed(1)}%</strong></td>
          <td>
            <button class="btn-secondary btn-sm btn-open-rec" data-id="${rec.id}">Open</button>
            <button class="btn-ghost btn-sm btn-del-rec" data-id="${rec.id}" style="color:#FDA4AF;">Delete</button>
          </td>
        `;
        tbody.appendChild(tr);
      });

      tbody.querySelectorAll(".btn-open-rec").forEach((btn) => {
        btn.addEventListener("click", async () => {
          const r = await fetch(`/api/records/${btn.dataset.id}`);
          const full = await r.json();
          state.lastResult = full.result;
          renderResultsDashboard(full.result);
          showView("viewResults");
        });
      });

      tbody.querySelectorAll(".btn-del-rec").forEach((btn) => {
        btn.addEventListener("click", async () => {
          await fetch(`/api/records/${btn.dataset.id}`, { method: "DELETE" });
          showToast("Local record permanently deleted.");
          openRecordsManager();
        });
      });
    }
    showView("viewRecords");
  } catch (err) {
    showToast(`Could not load records: ${err.message}`);
  }
}

function loadSampleCase() {
  state.answers = {
    participant_name: "S001_Research_Demo",
    age: 29,
    gender: "Female",
    pss_score: 27,
    stai_state: 58,
    stai_trait: 47,
    hr: 74,
    stroop_hr: 86,
    interview_hr: 96,
    hypervent_hr: 91,
    rr: 15.2,
    stress_rr: 21.8,
    mean_eda: 4.15,
    skin_temp: 32.3,
  };
  saveDraft();
  renderQuestion();
  showToast("Loaded sample high-stress research profile.");
}

function escapeHtml(s) {
  return String(s)
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;");
}

/* ==================== EVENT WIRING ==================== */
document.addEventListener("DOMContentLoaded", () => {
  window.NeuroCharts.startWelcomeAnimation("welcomeCanvas");
  checkBackendHealth();

  if (loadDraft()) {
    $("btnResumeDraft").style.display = "inline-flex";
  }

  $("btnHomeLogo").addEventListener("click", () => showView("viewWelcome"));

  $("btnSoundToggle").addEventListener("click", () => {
    const on = window.neuroAudio.toggle();
    $("soundIcon").textContent = on ? "🔊" : "🔇";
    $("soundLabel").textContent = on ? "Sound ON" : "Sound OFF";
    $("btnSoundToggle").classList.toggle("active", on);
  });

  $("btnGetStarted").addEventListener("click", () => {
    state.step = 0;
    state.answers = {};
    window.neuroAudio.playStepChime(528);
    renderQuestion();
    showView("viewQuestionnaire");
  });

  $("btnResumeDraft").addEventListener("click", () => {
    renderQuestion();
    showView("viewQuestionnaire");
  });

  $("btnNext").addEventListener("click", handleNext);
  $("btnPrev").addEventListener("click", handlePrev);
  $("btnSampleFill").addEventListener("click", loadSampleCase);

  $("btnAnalyzeData").addEventListener("click", runBackendAnalysis);
  $("btnToggleReviewGrid").addEventListener("click", () => {
    const wrap = $("reviewSummaryWrap");
    wrap.scrollIntoView({ behavior: "smooth" });
  });

  $("btnLiveReport").addEventListener("click", () => {
    if (!state.lastResult) return;
    renderLiveReport(state.lastResult);
    showView("viewLiveReport");
  });
  $("btnCloseLiveReport").addEventListener("click", () => showView("viewResults"));
  $("btnDownloadPdf").addEventListener("click", downloadPdfReport);
  $("btnLiveReportPdf").addEventListener("click", downloadPdfReport);

  $("btnNewAssessment").addEventListener("click", () => {
    state.step = 0;
    state.answers = {};
    renderQuestion();
    showView("viewQuestionnaire");
  });
  $("btnBackToReview").addEventListener("click", () => {
    renderReviewGrid();
    showView("viewReview");
  });

  $("btnRecords").addEventListener("click", openRecordsManager);
  $("btnCloseRecords").addEventListener("click", () => {
    showView(state.lastResult ? "viewResults" : "viewWelcome");
  });
});
