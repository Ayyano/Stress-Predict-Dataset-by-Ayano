"""
NeuroPulse AI — End-to-End Automated Verification Suite.
Verifies:
  1. Local FastAPI backend health & ML engine initialization
  2. High-stress & normal-baseline multimodal inference (/api/analyze)
  3. Multi-page PDF report generation (/api/report/pdf) + valid PDF header & size
  4. Local SQLite record persistence, retrieval & deletion (/api/records)
  5. Static frontend HTML/CSS/JS serving (/)
"""

import os
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))

from fastapi.testclient import TestClient  # noqa: E402
from backend.server import app  # noqa: E402


def run_tests():
    client = TestClient(app)

    # 1. Health Check
    r_health = client.get("/api/health")
    assert r_health.status_code == 200, f"Health check failed: {r_health.text}"
    h = r_health.json()
    assert h["status"] == "ok" and h["local_only"] is True
    print(f"[PASS] /api/health -> mode={h['engine_mode']}, models={h['models_loaded']}, primary={h['primary_model']}")

    # 2. High-Stress Profile Analysis
    high_stress_payload = {
        "participant_name": "TEST_STRESS_001",
        "age": 29,
        "gender": "Female",
        "pss_score": 28,
        "stai_state": 60,
        "stai_trait": 49,
        "hr": 74.0,
        "stroop_hr": 87.5,
        "interview_hr": 97.0,
        "hypervent_hr": 92.0,
        "rr": 15.2,
        "stress_rr": 22.0,
        "mean_eda": 4.3,
        "skin_temp": 32.2,
        "save_record": True,
    }
    r_s = client.post("/api/analyze", json=high_stress_payload)
    assert r_s.status_code == 200, f"High-stress analyze failed: {r_s.text}"
    res_s = r_s.json()
    assert res_s["backend_predictions"]["is_stressed"] is True
    assert res_s["backend_predictions"]["stress_probability"] >= 70.0
    rec_id = res_s["meta"]["record_id"]
    print(f"[PASS] /api/analyze (High Stress) -> prob={res_s['backend_predictions']['stress_probability']}%, verdict={res_s['backend_predictions']['verdict']}")

    # 3. Normal Baseline Profile Analysis
    normal_payload = {
        "participant_name": "TEST_NORMAL_002",
        "age": 31,
        "gender": "Male",
        "pss_score": 10,
        "stai_state": 30,
        "stai_trait": 33,
        "hr": 70.0,
        "stroop_hr": 75.0,
        "interview_hr": 79.0,
        "hypervent_hr": 76.5,
        "rr": 14.5,
        "stress_rr": 17.0,
        "mean_eda": 1.2,
        "skin_temp": 33.6,
        "save_record": False,
    }
    r_n = client.post("/api/analyze", json=normal_payload)
    assert r_n.status_code == 200, f"Normal analyze failed: {r_n.text}"
    res_n = r_n.json()
    assert res_n["backend_predictions"]["is_stressed"] is False
    print(f"[PASS] /api/analyze (Normal)      -> prob={res_n['backend_predictions']['stress_probability']}%, verdict={res_n['backend_predictions']['verdict']}")

    # 4. PDF Report Generation
    r_pdf = client.post("/api/report/pdf", json={"result": res_s})
    assert r_pdf.status_code == 200, f"PDF export failed: {r_pdf.text}"
    assert r_pdf.content[:4] == b"%PDF", "Returned bytes are not a valid PDF"
    assert len(r_pdf.content) > 25000, f"PDF unexpectedly small: {len(r_pdf.content)} bytes"
    sample_pdf = ROOT / "tests" / "_sample_verified_report.pdf"
    sample_pdf.write_bytes(r_pdf.content)
    print(f"[PASS] /api/report/pdf -> valid PDF ({len(r_pdf.content):,} bytes)")

    # 5. Local Records CRUD
    r_list = client.get("/api/records")
    assert r_list.status_code == 200
    assert any(r["id"] == rec_id for r in r_list.json()["records"])
    r_get = client.get(f"/api/records/{rec_id}")
    assert r_get.status_code == 200
    r_del = client.delete(f"/api/records/{rec_id}")
    assert r_del.status_code == 200 and r_del.json()["deleted"] is True
    print(f"[PASS] /api/records CRUD -> created, retrieved, and deleted {rec_id}")

    # 6. Frontend Static Serving
    r_idx = client.get("/")
    assert r_idx.status_code == 200 and "NeuroPulse" in r_idx.text
    for asset in ["/static/styles.css", "/static/app.js", "/static/charts.js", "/static/audio.js"]:
        r_a = client.get(asset)
        assert r_a.status_code == 200, f"Missing static asset: {asset}"
    print("[PASS] Frontend SPA & static assets served cleanly")

    print("\nALL END-TO-END VERIFICATION CHECKS PASSED!")


if __name__ == "__main__":
    run_tests()
