@echo off
setlocal EnableDelayedExpansion
title NeuroPulse AI - Therapy Sanctuary Edition (v4)
cd /d "%~dp0"

echo ==============================================================
echo   NeuroPulse AI - Therapy Sanctuary Edition (v4)
echo   Starting 100%% Local Desktop Application (Windows)...
echo ==============================================================

REM Clear any older instance holding port 8765
for /f "tokens=5" %%a in ('netstat -ano ^| findstr ":8765 " ^| findstr "LISTENING"') do (
    taskkill /F /PID %%a >nul 2>&1
)

if not exist ".venv\Scripts\python.exe" (
    echo [1/3] Creating local Python virtual environment...
    python -m venv .venv
    if errorlevel 1 (
        echo ERROR: Python 3.9+ is required. Please install Python and check "Add Python to PATH".
        pause
        exit /b 1
    )
    echo [2/3] Installing local dependencies (first launch only)...
    .venv\Scripts\python.exe -m pip install --upgrade pip
    .venv\Scripts\python.exe -m pip install -r backend\requirements.txt
) else (
    .venv\Scripts\python.exe -c "import reportlab" >nul 2>&1
    if errorlevel 1 (
        echo [Fix] Repairing ReportLab for your Python version...
        .venv\Scripts\python.exe -m pip install "reportlab==4.2.5"
    )
)

if exist "electron\node_modules\.bin\electron.cmd" (
    echo [3/3] Launching NeuroPulse AI Desktop Window...
    cd electron
    call npm start
) else (
    echo [3/3] Starting local NeuroPulse AI backend at http://127.0.0.1:8765 ...
    echo       Waiting for ML engine to finish initialization before opening browser...
    start "" /b powershell -NoProfile -Command "$u='http://127.0.0.1:8765/api/health'; for($i=0;$i -lt 60;$i++){ try { $r=Invoke-WebRequest -UseBasicParsing -Uri $u -TimeoutSec 2; if($r.StatusCode -eq 200){ Start-Process 'http://127.0.0.1:8765/?v=9'; break } } catch {} Start-Sleep -Seconds 1 }"
    .venv\Scripts\python.exe -m backend.server
)
endlocal
