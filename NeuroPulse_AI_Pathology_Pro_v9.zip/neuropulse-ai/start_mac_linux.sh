#!/usr/bin/env bash
set -e
cd "$(dirname "$0")"

echo "=============================================================="
echo "  NeuroPulse AI — Therapy Sanctuary Edition (v4)"
echo "  Starting 100% Local Application (macOS / Linux)..."
echo "=============================================================="

# Stop any older instance still holding port 8765 so the new UI always loads fresh
if command -v lsof >/dev/null 2>&1; then
  OLD_PIDS="$(lsof -ti :8765 2>/dev/null || true)"
  if [ -n "$OLD_PIDS" ]; then
    echo "[Clean] Stopping previous NeuroPulse server on port 8765..."
    kill -9 $OLD_PIDS 2>/dev/null || true
    sleep 1
  fi
fi

PYTHON_BIN=""
for cand in python3.12 python3.11 python3.10 python3; do
  if command -v "$cand" >/dev/null 2>&1; then
    PYTHON_BIN="$(command -v "$cand")"
    break
  fi
done

if [ -z "$PYTHON_BIN" ]; then
  echo "ERROR: Python 3.9+ was not found. Please install Python 3 and try again."
  exit 1
fi

echo "Using Python: $($PYTHON_BIN --version) ($PYTHON_BIN)"

if [ ! -f ".venv/bin/python3" ]; then
  echo "[1/3] Creating local Python virtual environment..."
  "$PYTHON_BIN" -m venv .venv
  echo "[2/3] Installing local dependencies (first launch only)..."
  .venv/bin/python3 -m pip install --upgrade pip
  .venv/bin/python3 -m pip install -r backend/requirements.txt
else
  if ! .venv/bin/python3 -c "import reportlab" >/dev/null 2>&1; then
    echo "[Fix] Repairing ReportLab for your Python version..."
    .venv/bin/python3 -m pip install "reportlab==4.2.5"
  fi
fi

if [ -d "electron/node_modules/electron" ]; then
  echo "[3/3] Launching NeuroPulse AI Desktop Window..."
  cd electron
  npm start
else
  URL="http://127.0.0.1:8765"
  echo "[3/3] Starting local NeuroPulse AI backend at $URL ..."
  echo "      Waiting for ML engine to finish initialization before opening browser..."

  (
    for _ in $(seq 1 60); do
      if curl -fsS "$URL/api/health" >/dev/null 2>&1; then
        if command -v open >/dev/null 2>&1; then
          open "$URL/?v=9"
        elif command -v xdg-open >/dev/null 2>&1; then
          xdg-open "$URL/?v=9" >/dev/null 2>&1 &
        fi
        exit 0
      fi
      sleep 1
    done
  ) &

  .venv/bin/python3 -m backend.server
fi
