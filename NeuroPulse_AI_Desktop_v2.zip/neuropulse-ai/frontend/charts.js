/**
 * NeuroPulse AI — Zero-Dependency Canvas Visualizations
 * 1. Welcome Screen Animated Neural Network & ECG Heartbeat Waveform
 * 2. Results Dashboard Charts (HR Reactivity, Autonomic Radar, RR Shift, Model Consensus)
 */

window.NeuroCharts = (() => {
  /* ==================== WELCOME ANIMATION ==================== */
  function startWelcomeAnimation(canvasId) {
    const canvas = document.getElementById(canvasId);
    if (!canvas) return;
    const ctx = canvas.getContext("2d");
    const W = canvas.width;
    const H = canvas.height;

    const nodes = Array.from({ length: 30 }, (_, i) => ({
      x: 40 + ((i * 73) % (W - 80)),
      y: 35 + ((i * 59) % (H - 150)),
      vx: (Math.sin(i * 1.7) * 0.35),
      vy: (Math.cos(i * 1.3) * 0.35),
      r: 2.2 + (i % 3) * 1.1,
    }));

    let phase = 0;

    function ecgWave(t) {
      const x = ((t % 1) + 1) % 1;
      if (x > 0.10 && x < 0.16) return 0.16 * Math.sin(((x - 0.10) / 0.06) * Math.PI);
      if (x >= 0.22 && x < 0.25) return -0.18 * ((x - 0.22) / 0.03);
      if (x >= 0.25 && x < 0.29) return 1.0 * Math.sin(((x - 0.25) / 0.04) * Math.PI);
      if (x >= 0.29 && x < 0.33) return -0.32 * Math.sin(((x - 0.29) / 0.04) * Math.PI);
      if (x >= 0.42 && x < 0.56) return 0.28 * Math.sin(((x - 0.42) / 0.14) * Math.PI);
      return 0;
    }

    function frame() {
      ctx.clearRect(0, 0, W, H);

      // Subtle medical grid
      ctx.strokeStyle = "rgba(0, 229, 255, 0.055)";
      ctx.lineWidth = 1;
      for (let gx = 0; gx < W; gx += 35) {
        ctx.beginPath(); ctx.moveTo(gx, 0); ctx.lineTo(gx, H); ctx.stroke();
      }
      for (let gy = 0; gy < H; gy += 35) {
        ctx.beginPath(); ctx.moveTo(0, gy); ctx.lineTo(W, gy); ctx.stroke();
      }

      // Neural nodes & synaptic links
      for (let i = 0; i < nodes.length; i++) {
        const n = nodes[i];
        n.x += n.vx;
        n.y += n.vy;
        if (n.x < 24 || n.x > W - 24) n.vx *= -1;
        if (n.y < 24 || n.y > H - 135) n.vy *= -1;

        for (let j = i + 1; j < nodes.length; j++) {
          const m = nodes[j];
          const dist = Math.hypot(n.x - m.x, n.y - m.y);
          if (dist < 115) {
            const alpha = (1 - dist / 115) * 0.32;
            ctx.strokeStyle = `rgba(139, 92, 246, ${alpha.toFixed(3)})`;
            ctx.lineWidth = 1.1;
            ctx.beginPath();
            ctx.moveTo(n.x, n.y);
            ctx.lineTo(m.x, m.y);
            ctx.stroke();
          }
        }
      }

      nodes.forEach((n, idx) => {
        const glow = 0.65 + 0.35 * Math.sin(phase * 2.5 + idx);
        ctx.fillStyle = idx % 3 === 0 ? `rgba(0, 229, 255, ${glow})` : `rgba(139, 92, 246, ${glow})`;
        ctx.beginPath();
        ctx.arc(n.x, n.y, n.r, 0, Math.PI * 2);
        ctx.fill();
      });

      // Heartbeat ECG waveform at lower third
      const baseY = H - 68;
      const grad = ctx.createLinearGradient(0, baseY - 50, W, baseY + 20);
      grad.addColorStop(0, "rgba(0, 229, 255, 0.2)");
      grad.addColorStop(0.55, "#00E5FF");
      grad.addColorStop(1, "#8B5CF6");

      ctx.strokeStyle = grad;
      ctx.lineWidth = 2.4;
      ctx.shadowColor = "rgba(0, 229, 255, 0.55)";
      ctx.shadowBlur = 10;
      ctx.beginPath();
      for (let x = 0; x <= W; x += 2) {
        const t = x / 185 - phase * 0.55;
        const y = baseY - ecgWave(t) * 46;
        if (x === 0) ctx.moveTo(x, y);
        else ctx.lineTo(x, y);
      }
      ctx.stroke();
      ctx.shadowBlur = 0;

      // Secondary respiratory sine wave
      ctx.strokeStyle = "rgba(20, 184, 166, 0.45)";
      ctx.lineWidth = 1.4;
      ctx.beginPath();
      for (let x = 0; x <= W; x += 3) {
        const y = baseY + 28 + Math.sin(x * 0.025 - phase * 1.6) * 8;
        if (x === 0) ctx.moveTo(x, y);
        else ctx.lineTo(x, y);
      }
      ctx.stroke();

      phase += 0.012;
      requestAnimationFrame(frame);
    }
    requestAnimationFrame(frame);
  }

  /* ==================== GROUPED BAR CHART HELPER ==================== */
  function drawGroupedBar(canvasId, labels, pVals, cVals, unit, pColor = "#00E5FF") {
    const canvas = document.getElementById(canvasId);
    if (!canvas) return;
    const ctx = canvas.getContext("2d");
    const W = canvas.width;
    const H = canvas.height;
    ctx.clearRect(0, 0, W, H);

    const padL = 46, padR = 18, padT = 30, padB = 42;
    const chartW = W - padL - padR;
    const chartH = H - padT - padB;
    const maxVal = Math.max(...pVals, ...cVals, 10) * 1.18;

    // Gridlines
    ctx.font = "11px -apple-system, sans-serif";
    ctx.fillStyle = "#94A3B8";
    ctx.strokeStyle = "rgba(148, 163, 184, 0.14)";
    ctx.lineWidth = 1;
    for (let i = 0; i <= 4; i++) {
      const y = padT + (chartH * i) / 4;
      const v = maxVal * (1 - i / 4);
      ctx.beginPath(); ctx.moveTo(padL, y); ctx.lineTo(W - padR, y); ctx.stroke();
      ctx.textAlign = "right";
      ctx.fillText(v.toFixed(0), padL - 8, y + 4);
    }

    // Legend
    ctx.textAlign = "left";
    ctx.fillStyle = pColor;
    ctx.fillRect(padL, 8, 12, 10);
    ctx.fillStyle = "#E2E8F0";
    ctx.fillText("Participant", padL + 17, 17);

    ctx.fillStyle = "rgba(148, 163, 184, 0.55)";
    ctx.fillRect(padL + 100, 8, 12, 10);
    ctx.fillStyle = "#94A3B8";
    ctx.fillText("Cohort Normal", padL + 117, 17);

    const groupW = chartW / labels.length;
    const barW = Math.min(34, groupW * 0.28);

    labels.forEach((lbl, idx) => {
      const cx = padL + idx * groupW + groupW / 2;
      const h1 = (pVals[idx] / maxVal) * chartH;
      const h2 = (cVals[idx] / maxVal) * chartH;

      // Participant bar
      const g1 = ctx.createLinearGradient(0, padT + chartH - h1, 0, padT + chartH);
      g1.addColorStop(0, pColor);
      g1.addColorStop(1, "rgba(59, 130, 246, 0.55)");
      ctx.fillStyle = g1;
      ctx.fillRect(cx - barW - 3, padT + chartH - h1, barW, h1);

      // Cohort bar
      ctx.fillStyle = "rgba(148, 163, 184, 0.45)";
      ctx.fillRect(cx + 3, padT + chartH - h2, barW, h2);

      // Value labels
      ctx.textAlign = "center";
      ctx.fillStyle = "#F8FAFC";
      ctx.font = "bold 11px -apple-system, sans-serif";
      ctx.fillText(pVals[idx].toFixed(1), cx - barW / 2 - 3, padT + chartH - h1 - 6);

      ctx.fillStyle = "#94A3B8";
      ctx.font = "10px -apple-system, sans-serif";
      ctx.fillText(cVals[idx].toFixed(1), cx + barW / 2 + 3, padT + chartH - h2 - 6);

      // X label
      ctx.fillStyle = "#CBD5E1";
      ctx.font = "11px -apple-system, sans-serif";
      ctx.fillText(lbl, cx, H - 16);
    });
  }

  /* ==================== RADAR CHART ==================== */
  function drawRadar(canvasId, radarData, isStressed) {
    const canvas = document.getElementById(canvasId);
    if (!canvas) return;
    const ctx = canvas.getContext("2d");
    const W = canvas.width;
    const H = canvas.height;
    ctx.clearRect(0, 0, W, H);

    const cx = W / 2;
    const cy = H / 2 + 6;
    const radius = Math.min(W, H) * 0.34;
    const labels = ["Cardio Δ", "Resp. Δ", "EDA", "Thermal", "PSS", "STAI-S"];
    const n = labels.length;

    // Concentric rings
    ctx.strokeStyle = "rgba(148, 163, 184, 0.18)";
    ctx.lineWidth = 1;
    [0.25, 0.5, 0.75, 1.0].forEach((r) => {
      ctx.beginPath();
      for (let i = 0; i <= n; i++) {
        const ang = (Math.PI * 2 * (i % n)) / n - Math.PI / 2;
        const x = cx + Math.cos(ang) * radius * r;
        const y = cy + Math.sin(ang) * radius * r;
        if (i === 0) ctx.moveTo(x, y); else ctx.lineTo(x, y);
      }
      ctx.stroke();
    });

    // Spokes & Labels
    ctx.font = "bold 11px -apple-system, sans-serif";
    ctx.fillStyle = "#CBD5E1";
    labels.forEach((lbl, i) => {
      const ang = (Math.PI * 2 * i) / n - Math.PI / 2;
      const x = cx + Math.cos(ang) * radius;
      const y = cy + Math.sin(ang) * radius;
      ctx.beginPath(); ctx.moveTo(cx, cy); ctx.lineTo(x, y); ctx.stroke();

      const lx = cx + Math.cos(ang) * (radius + 24);
      const ly = cy + Math.sin(ang) * (radius + 18);
      ctx.textAlign = "center";
      ctx.fillText(lbl, lx, ly + 4);
    });

    function plotPoly(vals, stroke, fill, dashed = false) {
      ctx.save();
      if (dashed) ctx.setLineDash([4, 4]);
      ctx.strokeStyle = stroke;
      ctx.fillStyle = fill;
      ctx.lineWidth = 2;
      ctx.beginPath();
      vals.forEach((v, i) => {
        const ang = (Math.PI * 2 * i) / n - Math.PI / 2;
        const r = (Math.max(0, Math.min(100, v)) / 100) * radius;
        const x = cx + Math.cos(ang) * r;
        const y = cy + Math.sin(ang) * r;
        if (i === 0) ctx.moveTo(x, y); else ctx.lineTo(x, y);
      });
      ctx.closePath();
      ctx.fill();
      ctx.stroke();
      ctx.restore();
    }

    plotPoly(radarData.normal_cohort, "rgba(148,163,184,0.8)", "rgba(148,163,184,0.14)", true);
    const pStroke = isStressed ? "#F43F5E" : "#14B8A6";
    const pFill = isStressed ? "rgba(244,63,94,0.28)" : "rgba(20,184,166,0.28)";
    plotPoly(radarData.participant, pStroke, pFill, false);
  }

  /* ==================== HORIZONTAL MODEL CONSENSUS ==================== */
  function drawModelConsensus(canvasId, preds) {
    const canvas = document.getElementById(canvasId);
    if (!canvas) return;
    const ctx = canvas.getContext("2d");
    const W = canvas.width;
    const H = canvas.height;
    ctx.clearRect(0, 0, W, H);

    const items = preds.slice(0, 6);
    const padL = 175, padR = 54, padT = 18, padB = 22;
    const chartW = W - padL - padR;
    const rowH = (H - padT - padB) / Math.max(items.length, 1);

    // 50% threshold line
    const x50 = padL + chartW * 0.5;
    ctx.save();
    ctx.setLineDash([4, 4]);
    ctx.strokeStyle = "rgba(148, 163, 184, 0.45)";
    ctx.beginPath(); ctx.moveTo(x50, padT); ctx.lineTo(x50, H - padB); ctx.stroke();
    ctx.restore();

    items.forEach((item, idx) => {
      const y = padT + idx * rowH + rowH * 0.22;
      const bh = Math.min(18, rowH * 0.54);
      const bw = (item.stress_probability / 100) * chartW;

      ctx.fillStyle = "#CBD5E1";
      ctx.font = "11px -apple-system, sans-serif";
      ctx.textAlign = "right";
      const shortName = item.model.replace("Proposed ", "");
      ctx.fillText(shortName, padL - 10, y + bh * 0.78);

      // Track
      ctx.fillStyle = "rgba(255,255,255,0.06)";
      ctx.fillRect(padL, y, chartW, bh);

      // Fill
      ctx.fillStyle = item.stress_probability >= 50 ? "#F43F5E" : "#14B8A6";
      ctx.fillRect(padL, y, bw, bh);

      ctx.fillStyle = "#F8FAFC";
      ctx.font = "bold 11px -apple-system, sans-serif";
      ctx.textAlign = "left";
      ctx.fillText(`${item.stress_probability.toFixed(1)}%`, padL + bw + 8, y + bh * 0.78);
    });
  }

  return {
    startWelcomeAnimation,
    drawGroupedBar,
    drawRadar,
    drawModelConsensus,
  };
})();
