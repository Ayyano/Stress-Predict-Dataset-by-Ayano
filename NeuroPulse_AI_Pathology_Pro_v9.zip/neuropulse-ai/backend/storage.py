"""
NeuroPulse AI — Local SQLite Assessment Storage with Strict Patient-Level Isolation.
100% local, zero cloud sync, zero external telemetry.
Supports retrieving ONLY the selected patient's own prior visits for longitudinal
pathology comparison (never leaks or mixes other patients' records).
"""

from __future__ import annotations

import json
import sqlite3
import uuid
from pathlib import Path
from typing import Any, Dict, List, Optional


class LocalAssessmentStore:
    def __init__(self, db_path: Path):
        self.db_path = db_path
        self.db_path.parent.mkdir(parents=True, exist_ok=True)
        self._init_db()

    def _connect(self) -> sqlite3.Connection:
        conn = sqlite3.connect(str(self.db_path))
        conn.row_factory = sqlite3.Row
        return conn

    def _init_db(self) -> None:
        with self._connect() as conn:
            conn.execute(
                """
                CREATE TABLE IF NOT EXISTS assessments (
                    id TEXT PRIMARY KEY,
                    created_at TEXT NOT NULL,
                    participant_name TEXT NOT NULL,
                    anon_id TEXT NOT NULL,
                    age REAL NOT NULL,
                    gender TEXT NOT NULL,
                    verdict TEXT NOT NULL,
                    stress_probability REAL NOT NULL,
                    triage_severity TEXT NOT NULL,
                    payload_json TEXT NOT NULL,
                    result_json TEXT NOT NULL
                )
                """
            )
            conn.commit()

    def save_assessment(self, payload: Dict[str, Any], result: Dict[str, Any]) -> str:
        rec_id = f"REC-{uuid.uuid4().hex[:10].upper()}"
        meta = result["meta"]
        measured = result["measured_values"]
        pred = result["backend_predictions"]
        with self._connect() as conn:
            conn.execute(
                """
                INSERT INTO assessments (
                    id, created_at, participant_name, anon_id, age, gender,
                    verdict, stress_probability, triage_severity, payload_json, result_json
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                """,
                (
                    rec_id,
                    meta["timestamp"],
                    measured["participant_name"],
                    meta["anon_id"],
                    float(measured["age"]),
                    str(measured["gender"]),
                    str(pred["verdict"]),
                    float(pred["stress_probability"]),
                    str(pred["triage_severity"]),
                    json.dumps(payload),
                    json.dumps(result),
                ),
            )
            conn.commit()
        return rec_id

    def get_patient_history(
        self,
        participant_name: str,
        exclude_id: Optional[str] = None,
        limit: int = 8,
    ) -> List[Dict[str, Any]]:
        """
        Strictly isolated lookup: returns ONLY prior assessments belonging to the
        exact same patient (case-insensitive trimmed match on participant_name).
        """
        norm_name = participant_name.strip().lower()
        with self._connect() as conn:
            if exclude_id:
                rows = conn.execute(
                    """
                    SELECT id, created_at, stress_probability, verdict, payload_json
                    FROM assessments
                    WHERE LOWER(TRIM(participant_name)) = ? AND id != ?
                    ORDER BY created_at DESC
                    LIMIT ?
                    """,
                    (norm_name, exclude_id, limit),
                ).fetchall()
            else:
                rows = conn.execute(
                    """
                    SELECT id, created_at, stress_probability, verdict, payload_json
                    FROM assessments
                    WHERE LOWER(TRIM(participant_name)) = ?
                    ORDER BY created_at DESC
                    LIMIT ?
                    """,
                    (norm_name, limit),
                ).fetchall()

        history = []
        for r in rows:
            p = json.loads(r["payload_json"])
            history.append(
                {
                    "id": r["id"],
                    "date": r["created_at"],
                    "stress_probability": float(r["stress_probability"]),
                    "verdict": r["verdict"],
                    "hr": p.get("hr"),
                    "stroop_hr": p.get("stroop_hr"),
                    "interview_hr": p.get("interview_hr"),
                    "hypervent_hr": p.get("hypervent_hr"),
                    "rr": p.get("rr"),
                    "stress_rr": p.get("stress_rr"),
                    "mean_eda": p.get("mean_eda"),
                    "skin_temp": p.get("skin_temp"),
                    "pss_score": p.get("pss_score"),
                    "stai_state": p.get("stai_state"),
                    "stai_trait": p.get("stai_trait"),
                }
            )
        return history

    def list_assessments(self, limit: int = 100) -> List[Dict[str, Any]]:
        with self._connect() as conn:
            rows = conn.execute(
                """
                SELECT id, created_at, participant_name, anon_id, age, gender,
                       verdict, stress_probability, triage_severity
                FROM assessments
                ORDER BY created_at DESC
                LIMIT ?
                """,
                (limit,),
            ).fetchall()
        return [dict(r) for r in rows]

    def get_assessment(self, rec_id: str) -> Optional[Dict[str, Any]]:
        with self._connect() as conn:
            row = conn.execute(
                "SELECT * FROM assessments WHERE id = ?",
                (rec_id,),
            ).fetchone()
        if row is None:
            return None
        return {
            "id": row["id"],
            "created_at": row["created_at"],
            "payload": json.loads(row["payload_json"]),
            "result": json.loads(row["result_json"]),
        }

    def delete_assessment(self, rec_id: str) -> bool:
        with self._connect() as conn:
            cur = conn.execute("DELETE FROM assessments WHERE id = ?", (rec_id,))
            conn.commit()
            return cur.rowcount > 0
