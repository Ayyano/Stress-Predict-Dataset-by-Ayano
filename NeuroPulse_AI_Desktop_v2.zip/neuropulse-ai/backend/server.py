"""
NeuroPulse AI — Local FastAPI Backend Server.
Connects the premium desktop frontend to the existing `finally.ipynb` ML backend,
provides REST endpoints for stress analysis, local record storage, and PDF report
generation, and serves the frontend locally on 127.0.0.1 (zero external calls).
"""

from __future__ import annotations

import logging
import os
import re
from pathlib import Path
from typing import Any, Dict, Optional

from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse, JSONResponse, Response
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel, Field

from .ml_engine import NeuroPulseEngine
from .pdf_report import generate_clinical_pdf_bytes
from .storage import LocalAssessmentStore

# Privacy-first logging: never log participant names or sensitive values
logging.basicConfig(level=logging.INFO, format="[NeuroPulse] %(asctime)s %(levelname)s: %(message)s")
logger = logging.getLogger("neuropulse")

ROOT_DIR = Path(__file__).resolve().parent.parent
FRONTEND_DIR = ROOT_DIR / "frontend"
LOCAL_DATA_DIR = Path(os.environ.get("NEUROPULSE_DATA_DIR", str(ROOT_DIR / "local_data")))
LOCAL_DATA_DIR.mkdir(parents=True, exist_ok=True)


class AssessmentRequest(BaseModel):
    participant_name: str = Field(..., min_length=1, max_length=120)
    age: float = Field(..., ge=5, le=120)
    gender: str = Field(..., min_length=1, max_length=40)
    pss_score: float = Field(..., ge=0, le=40)
    stai_state: float = Field(..., ge=20, le=80)
    stai_trait: float = Field(..., ge=20, le=80)
    hr: float = Field(..., ge=30, le=220)
    stroop_hr: float = Field(..., ge=30, le=240)
    interview_hr: float = Field(..., ge=30, le=240)
    hypervent_hr: float = Field(..., ge=30, le=240)
    rr: float = Field(..., ge=4, le=60)
    stress_rr: float = Field(..., ge=4, le=80)
    mean_eda: float = Field(..., ge=0.0, le=50.0)
    skin_temp: float = Field(..., ge=20.0, le=42.0)
    save_record: bool = True


class PdfRequest(BaseModel):
    result: Dict[str, Any]


app = FastAPI(
    title="NeuroPulse AI — Local Stress Monitoring Backend",
    version="1.0.0",
    docs_url="/api/docs",
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=False,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Initialize local ML engine and local SQLite database
engine = NeuroPulseEngine(data_dir=LOCAL_DATA_DIR / "dataset")
store = LocalAssessmentStore(db_path=LOCAL_DATA_DIR / "neuropulse_records.sqlite3")


@app.get("/api/health")
def health_check() -> Dict[str, Any]:
    return {
        "status": "ok",
        "app": "NeuroPulse AI — Autonomous Stress Monitoring System (ASMS)",
        "engine_mode": engine.engine_mode,
        "primary_model": engine.primary_model_name,
        "dataset_source": engine.dataset_source,
        "models_loaded": len(engine.models_full),
        "local_only": True,
    }


@app.post("/api/analyze")
def analyze(req: AssessmentRequest) -> JSONResponse:
    payload = req.model_dump() if hasattr(req, "model_dump") else req.dict()
    result = engine.analyze_participant(payload)
    record_id: Optional[str] = None
    if req.save_record:
        record_id = store.save_assessment(payload, result)
        result["meta"]["record_id"] = record_id
    logger.info(
        "Completed local assessment | token=%s | prob=%.1f%% | saved=%s",
        result["meta"]["anon_id"],
        result["backend_predictions"]["stress_probability"],
        bool(record_id),
    )
    return JSONResponse(content=result)


@app.post("/api/report/pdf")
def export_pdf(req: PdfRequest) -> Response:
    try:
        pdf_bytes = generate_clinical_pdf_bytes(req.result)
    except Exception as exc:
        logger.exception("PDF generation failed")
        raise HTTPException(status_code=500, detail=f"PDF generation error: {exc}")

    anon_id = str(req.result.get("meta", {}).get("anon_id", "Assessment"))
    safe_id = re.sub(r"[^A-Za-z0-9_-]", "_", anon_id)
    filename = f"NeuroPulse_AI_Report_{safe_id}.pdf"
    return Response(
        content=pdf_bytes,
        media_type="application/pdf",
        headers={"Content-Disposition": f'attachment; filename="{filename}"'},
    )


@app.get("/api/records")
def list_records() -> Dict[str, Any]:
    return {"records": store.list_assessments(limit=100)}


@app.get("/api/records/{record_id}")
def get_record(record_id: str) -> Dict[str, Any]:
    rec = store.get_assessment(record_id)
    if rec is None:
        raise HTTPException(status_code=404, detail="Assessment record not found")
    return rec


@app.delete("/api/records/{record_id}")
def delete_record(record_id: str) -> Dict[str, Any]:
    deleted = store.delete_assessment(record_id)
    if not deleted:
        raise HTTPException(status_code=404, detail="Assessment record not found")
    return {"deleted": True, "id": record_id}


# Serve local frontend assets
if FRONTEND_DIR.exists():
    app.mount("/static", StaticFiles(directory=str(FRONTEND_DIR)), name="static")


@app.get("/")
def serve_index():
    index_file = FRONTEND_DIR / "index.html"
    if not index_file.exists():
        return JSONResponse({"message": "NeuroPulse AI Backend Running. Frontend not found."}, status_code=200)
    return FileResponse(str(index_file))


def main() -> None:
    import uvicorn

    host = os.environ.get("NEUROPULSE_HOST", "127.0.0.1")
    port = int(os.environ.get("NEUROPULSE_PORT", "8765"))
    logger.info("Starting NeuroPulse AI local server on http://%s:%d", host, port)
    uvicorn.run(app, host=host, port=port, log_level="warning")


if __name__ == "__main__":
    main()
