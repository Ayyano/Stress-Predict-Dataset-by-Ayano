"""
NeuroPulse AI — Local SQLite Assessment Storage.
100% local, zero cloud sync, zero external telemetry, supports anonymous IDs,
and provides list / view / delete operations for research records.
"""

from __future__ import annotations

import json
import sqlite3
import uuid
from pathlib import Path
from typing import Any, Dict, List, Optional


class LocalAssessmentStore:
    def __init__(self, db_path: Path):
        self.db_path = db_path
        self.db_path.parent.mkdir(parents=True, exist_ok=True)
        self._init_db()

    def _connect(self) -> sqlite3.Connection:
        conn = sqlite3.connect(str(self.db_path))
        conn.row_factory = sqlite3.Row
        return conn

    def _init_db(self) -> None:
        with self._connect() as conn:
            conn.execute(
                """
                CREATE TABLE IF NOT EXISTS assessments (
                    id TEXT PRIMARY KEY,
                    created_at TEXT NOT NULL,
                    participant_name TEXT NOT NULL,
                    anon_id TEXT NOT NULL,
                    age REAL NOT NULL,
                    gender TEXT NOT NULL,
                    verdict TEXT NOT NULL,
                    stress_probability REAL NOT NULL,
                    triage_severity TEXT NOT NULL,
                    payload_json TEXT NOT NULL,
                    result_json TEXT NOT NULL
                )
                """
            )
            conn.commit()

    def save_assessment(self, payload: Dict[str, Any], result: Dict[str, Any]) -> str:
        rec_id = f"REC-{uuid.uuid4().hex[:10].upper()}"
        meta = result["meta"]
        measured = result["measured_values"]
        pred = result["backend_predictions"]
        with self._connect() as conn:
            conn.execute(
                """
                INSERT INTO assessments (
                    id, created_at, participant_name, anon_id, age, gender,
                    verdict, stress_probability, triage_severity, payload_json, result_json
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                """,
                (
                    rec_id,
                    meta["timestamp"],
                    measured["participant_name"],
                    meta["anon_id"],
                    float(measured["age"]),
                    str(measured["gender"]),
                    str(pred["verdict"]),
                    float(pred["stress_probability"]),
                    str(pred["triage_severity"]),
                    json.dumps(payload),
                    json.dumps(result),
                ),
            )
            conn.commit()
        return rec_id

    def list_assessments(self, limit: int = 100) -> List[Dict[str, Any]]:
        with self._connect() as conn:
            rows = conn.execute(
                """
                SELECT id, created_at, participant_name, anon_id, age, gender,
                       verdict, stress_probability, triage_severity
                FROM assessments
                ORDER BY created_at DESC
                LIMIT ?
                """,
                (limit,),
            ).fetchall()
        return [dict(r) for r in rows]

    def get_assessment(self, rec_id: str) -> Optional[Dict[str, Any]]:
        with self._connect() as conn:
            row = conn.execute(
                "SELECT * FROM assessments WHERE id = ?",
                (rec_id,),
            ).fetchone()
        if row is None:
            return None
        return {
            "id": row["id"],
            "created_at": row["created_at"],
            "payload": json.loads(row["payload_json"]),
            "result": json.loads(row["result_json"]),
        }

    def delete_assessment(self, rec_id: str) -> bool:
        with self._connect() as conn:
            cur = conn.execute("DELETE FROM assessments WHERE id = ?", (rec_id,))
            conn.commit()
            return cur.rowcount > 0
